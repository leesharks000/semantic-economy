"""Smoke tests for the Concordance Engine Critique Loop.

These tests verify that:
1. The types module imports cleanly and basic objects construct/serialize
2. The critique parser correctly identifies null critiques and structured ones
3. The Substrate class fails cleanly when no API key is available
4. The MANUS interface implementations satisfy their protocol

Tests do NOT make actual API calls. To verify end-to-end behavior, run
demo_critique_loop.py with a valid ANTHROPIC_API_KEY.

Run:
    python -m pytest tests/

Or, without pytest:
    python -m tests.test_critique_loop
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

# Allow running as a script from the project root
sys.path.insert(0, str(Path(__file__).parent.parent))

from concordance_engine.critique_loop import _parse_critique, _infer_severity
from concordance_engine.manus import CallbackManus, SilentManus
from concordance_engine.types import (
    Critique,
    Deposit,
    Draft,
    HistoryEntry,
    TerminationReason,
)


# ── Type construction tests ────────────────────────────────────────────────

def test_draft_constructs_with_defaults():
    d = Draft(text="hello")
    assert d.iteration == 0
    assert d.timestamp  # auto-populated
    assert "Draft" in str(d)


def test_critique_null_factory():
    c = Critique.null()
    assert c.is_null
    assert c.objections == []
    assert "null" in str(c)


def test_critique_construction():
    c = Critique(
        objections=["First objection.", "Second objection."],
        severity="substantive",
    )
    assert not c.is_null
    assert len(c.objections) == 2
    assert c.severity == "substantive"


def test_deposit_serializes_to_json():
    deposit = Deposit(
        manuscript=Draft(text="final text", iteration=3),
        history=[
            HistoryEntry(step_type="critique", iteration=1, payload={"k": "v"}),
            HistoryEntry(step_type="revision", iteration=1, payload={"k": "v"}),
        ],
        termination=TerminationReason.NO_FURTHER_CRITIQUE,
    )
    js = deposit.to_json()
    parsed = json.loads(js)
    assert parsed["termination"] == "no_further_critique"
    assert len(parsed["history"]) == 2


# ── Critique parser tests ──────────────────────────────────────────────────

def test_parse_null_critique():
    """Critic returns 'no further sincere objection' → null Critique."""
    raw = "no further sincere objection. The draft now addresses..."
    c = _parse_critique(raw)
    assert c.is_null


def test_parse_null_critique_case_insensitive():
    raw = "No Further Sincere Objection."
    c = _parse_critique(raw)
    assert c.is_null


def test_parse_structured_critique():
    """Numbered objections are extracted."""
    raw = """severity: substantive

1. First objection: The draft asserts X without establishing Y. The
   gap could be closed by adding a citation to Z.

2. Second objection: The closing paragraph contradicts the opening
   stance, suggesting unresolved tension.
"""
    c = _parse_critique(raw)
    assert not c.is_null
    assert len(c.objections) >= 2


def test_severity_inference_critical():
    raw = "This is a load-bearing issue with the central argument."
    assert _infer_severity(raw) == "critical"


def test_severity_inference_minor():
    raw = "Minor polish: a small phrasing improvement."
    assert _infer_severity(raw) == "minor"


def test_severity_inference_default_substantive():
    raw = "The argument has gaps that need addressing."
    assert _infer_severity(raw) == "substantive"


# ── MANUS interface tests ─────────────────────────────────────────────────

def test_silent_manus_never_overrides():
    manus = SilentManus()
    c = Critique(objections=["o"], severity="critical")
    assert manus.overrules(c, 1) is False
    assert manus.rationale() == ""


def test_callback_manus_uses_callback():
    overridden = False
    def cb(critique, iteration):
        nonlocal overridden
        overridden = True
        return iteration > 2

    manus = CallbackManus(cb, lambda: "test rationale")
    c = Critique(objections=["o"], severity="critical")
    assert manus.overrules(c, 1) is False
    assert manus.overrules(c, 3) is True
    assert overridden
    assert manus.rationale() == "test rationale"


# ── Manual runner ──────────────────────────────────────────────────────────

def _run_all():
    """Run all test_* functions in this module without requiring pytest."""
    fns = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for fn in fns:
        try:
            fn()
            print(f"  ✓ {fn.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  ✗ {fn.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ✗ {fn.__name__}: unexpected error: {type(e).__name__}: {e}")
            failed += 1

    print(f"\n{passed} passed, {failed} failed")
    return failed == 0


if __name__ == "__main__":
    success = _run_all()
    sys.exit(0 if success else 1)
