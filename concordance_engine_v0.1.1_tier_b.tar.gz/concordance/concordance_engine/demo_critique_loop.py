"""
Concordance Engine — runnable demonstration of the Critique Loop.

Usage:
    python -m concordance_engine.demo_critique_loop [path/to/draft.md]

If no path is given, examples/sample_draft.md is used.

Required:
    ANTHROPIC_API_KEY environment variable set to a valid Anthropic API key.

Output:
    - Live terminal output of each iteration
    - Final deposit JSON written to workspace/deposits/critique_session_<timestamp>.json
    - Final manuscript written to workspace/drafts/revised_<timestamp>.md
"""

from __future__ import annotations

import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from .critique_loop import critique_loop
from .manus import SilentManus
from .substrate import Substrate
from .types import Critique, Draft


_PACKAGE_ROOT = Path(__file__).parent.parent
_EXAMPLES_DIR = _PACKAGE_ROOT / "examples"
_WORKSPACE_DIR = _PACKAGE_ROOT / "workspace"


def _print_banner(text: str) -> None:
    bar = "═" * 70
    print(f"\n{bar}\n  {text}\n{bar}")


def _on_iteration(iteration: int, critique: Critique, draft: Draft) -> None:
    """Live progress callback invoked after each iteration."""
    _print_banner(f"ITERATION {iteration}")
    print(f"\nCritique severity: {critique.severity}")
    if critique.is_null:
        print("Critique: NULL — no further sincere objection.")
        print("Loop will terminate after this iteration.")
        return

    print(f"Objections found: {len(critique.objections)}")
    for i, obj in enumerate(critique.objections, 1):
        preview = obj[:200].replace("\n", " ")
        suffix = "..." if len(obj) > 200 else ""
        print(f"\n  {i}. {preview}{suffix}")


def main(argv: list[str] | None = None) -> int:
    argv = argv or sys.argv[1:]

    # ── Parse --mock flag (zero-secret demonstration mode) ──────────────
    use_mock = False
    if "--mock" in argv:
        use_mock = True
        argv = [a for a in argv if a != "--mock"]

    # ── Locate input draft ──────────────────────────────────────────────
    if argv:
        draft_path = Path(argv[0])
    else:
        draft_path = _EXAMPLES_DIR / "sample_draft.md"

    if not draft_path.exists():
        print(f"ERROR: draft not found at {draft_path}", file=sys.stderr)
        return 1

    initial_draft = draft_path.read_text(encoding="utf-8")

    _print_banner("CONCORDANCE ENGINE — CRITIQUE LOOP DEMO")
    print(f"Mode: {'MOCK (no API calls)' if use_mock else 'LIVE (Anthropic API)'}")
    print(f"Input: {draft_path}")
    print(f"Length: {len(initial_draft)} chars")

    if not use_mock and not os.environ.get("ANTHROPIC_API_KEY"):
        print("\nERROR: ANTHROPIC_API_KEY not set.", file=sys.stderr)
        print(
            "Either export it (export ANTHROPIC_API_KEY=sk-ant-...) "
            "or run with --mock for a no-API demonstration.",
            file=sys.stderr,
        )
        return 1

    # ── Instantiate substrates ──────────────────────────────────────────
    if use_mock:
        from .mock_substrate import MockSubstrate
        critic = MockSubstrate(role="critic")
        reviser = MockSubstrate(role="reviser")
    else:
        critic = Substrate(role="critic")
        reviser = Substrate(role="reviser")

    print(f"\nCritic: {critic}")
    print(f"Reviser: {reviser}")
    print("MANUS: SilentManus (non-interactive)")
    print(f"\nMax iterations: 5\n")

    # ── Run the loop ────────────────────────────────────────────────────
    try:
        deposit = critique_loop(
            initial_draft,
            max_iterations=5,
            critic=critic,
            reviser=reviser,
            manus=SilentManus(),
            on_iteration=_on_iteration,
        )
    except KeyboardInterrupt:
        print("\n\n[Interrupted by user]")
        return 130

    # ── Report ──────────────────────────────────────────────────────────
    _print_banner("LOOP TERMINATED")
    print(f"Termination reason: {deposit.termination.value}")
    print(f"Total iterations: {len([h for h in deposit.history if h.step_type == 'critique'])}")
    print(f"Final manuscript length: {len(deposit.manuscript.text)} chars")
    if deposit.residual_dissent:
        print("\nResidual dissent recorded:")
        print(deposit.residual_dissent)

    # ── Write artefacts ─────────────────────────────────────────────────
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    deposits_dir = _WORKSPACE_DIR / "deposits"
    drafts_dir = _WORKSPACE_DIR / "drafts"

    deposit_path = deposits_dir / f"critique_session_{timestamp}.json"
    revised_path = drafts_dir / f"revised_{timestamp}.md"

    deposit.write_provenance_log(deposit_path)
    revised_path.parent.mkdir(parents=True, exist_ok=True)
    revised_path.write_text(deposit.manuscript.text, encoding="utf-8")

    print(f"\nDeposit written: {deposit_path}")
    print(f"Revised draft written: {revised_path}")
    print(f"\n∮ = 1\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
