"""Concordance Engine — Tier B reference implementation.

The running-system instantiation of the Logotic Technique Catalogue
(DOI: 10.5281/zenodo.19831619).
"""

from .critique_loop import critique_loop
from .manus import CallbackManus, InteractiveManus, ManusInterface, SilentManus
from .substrate import Substrate, SubstrateError
from .types import (
    Critique,
    Deposit,
    Draft,
    HistoryEntry,
    RevisionBrief,
    TerminationReason,
)

__version__ = "0.1.1"
__all__ = [
    "critique_loop",
    "Substrate",
    "SubstrateError",
    "ManusInterface",
    "InteractiveManus",
    "SilentManus",
    "CallbackManus",
    "Draft",
    "Critique",
    "RevisionBrief",
    "Deposit",
    "HistoryEntry",
    "TerminationReason",
]
