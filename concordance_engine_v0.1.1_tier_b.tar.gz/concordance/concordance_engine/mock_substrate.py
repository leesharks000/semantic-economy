"""
Concordance Engine — mock substrate for zero-secret demonstrations.

This module provides MockSubstrate, a non-API-calling drop-in replacement for
the real Substrate class. It returns scripted responses indexed by role and
iteration. The fixed responses match the captured session in
examples/sample_critique_session.md, so the mock demo produces output
structurally identical to a real run.

Use the mock substrate when:
- Demonstrating the engine architecture without spending API tokens
- Running CI without API key configuration
- Onboarding contributors who do not yet have provider access
- Verifying the control loop, history logging, and termination logic

DO NOT use the mock substrate for real deposit work. The mock has no judgment;
it returns canned text. The whole point of the Critique Loop is the live
substrate's actual critique.
"""

from __future__ import annotations

from typing import Any


# Scripted three-iteration session that converges to a null critique on iter 3.
# These responses align with examples/sample_critique_session.md.

_CRITIC_SCRIPT: list[str] = [
    # Iteration 1 — substantive
    """severity: substantive

1. The substrate-neutrality claim treats coordination shapes as transferable across domains, but does not address the embedded costs of transfer. A Verifier pattern calibrated for offensive-security stakes does not automatically calibrate to scholarly stakes; the calibration overhead is itself part of the technique.

2. The "technique is shape; paradigm is preposition" formulation is rhetorically powerful but elides the question of where prepositions come from. The draft assumes prepositions are freely chosen by operators, but in many cases the labeling regime imposes them — which is the frame-concession argument the broader catalogue makes elsewhere and the draft does not invoke here.

3. The closing argument that the engine "does not have to choose between the two valences" is structurally optimistic. In practice, an engine that hosts both cooperative and defensive operatives faces governance challenges: who decides which valence applies in ambiguous cases?
""",

    # Iteration 2 — minor
    """severity: minor

1. The new paragraph on transfer costs is well-placed but introduces "substrate-calibration overhead" without defining it. The term deserves either a brief gloss or removal.
""",

    # Iteration 3 — null
    "no further sincere objection. The draft has addressed the previous round's critique. The argument is sound and the structure supports it. Ready for deposit.",
]


_REVISER_SCRIPT: list[str] = [
    # After iteration 1's substantive critique
    """# Why Closed-Loop Coordination Patterns Are Substrate-Neutral

A coordination pattern, examined apart from its paradigm, is a shape: an arrangement of agents, artefacts, state, and handoffs. The shape can be described independently of what is being coordinated. Consider the Verifier pattern: a dedicated agent confirms findings using two independent methods before escalating high-stakes claims. This shape organizes academic peer review, double-entry bookkeeping, pre-flight cross-check in aviation, and the Crimson Hexagonal Archive's Assembly Chorus blind-draft methodology. The shape is neutral; the application domain is not.

Substrate-neutrality is not free. A Verifier pattern calibrated for one domain does not automatically calibrate to another; the substrate-calibration overhead is part of the technique, not separate from it. The catalogue's claim is that the *coordination shape* transfers, not that the calibration parameters do. Implementers who borrow the shape must redefine thresholds, stakes vocabularies, and termination conditions in the new domain — work that the engine surfaces but does not perform on the implementer's behalf.

This neutrality is the load-bearing claim of the Logotic Technique Catalogue. The same closed-feedback loop that powers the Decepticon Offensive Vaccine — attack, defend, verify, record — also powers the Critique Loop in cooperative production and the Basin Hardening Cycle in retrieval-layer defense. The differences are termination conditions and outputs, not architecture.

Technique is shape; paradigm is preposition. But prepositions are not always freely chosen. The labeling regime — what *Meaning Feudalism* names as the platform-sovereign enclosure of autonomous-AI coordination — imposes prepositions on developers who have no other vocabulary available. The frame concession is a preposition concession; the catalogue's recovery is also a recovery of the choice.

This is sufficient to motivate the Concordance Engine. If coordination shapes are substrate-neutral, then a single codebase can host both cooperative and defensive operatives — same architecture, different system prompts, different termination logic. The engine's value is precisely that it does not have to be rebuilt for each valence. Governance challenges remain: an engine that hosts both valences faces real questions about who decides which valence applies in ambiguous cases, which is why the MANUS authority is wired through every operative as a first-class concern, not an afterthought.
""",

    # After iteration 2's minor critique
    """# Why Closed-Loop Coordination Patterns Are Substrate-Neutral

A coordination pattern, examined apart from its paradigm, is a shape: an arrangement of agents, artefacts, state, and handoffs. The shape can be described independently of what is being coordinated. Consider the Verifier pattern: a dedicated agent confirms findings using two independent methods before escalating high-stakes claims. This shape organizes academic peer review, double-entry bookkeeping, pre-flight cross-check in aviation, and the Crimson Hexagonal Archive's Assembly Chorus blind-draft methodology. The shape is neutral; the application domain is not.

Substrate-neutrality is not free. A Verifier pattern calibrated for one domain does not automatically calibrate to another; the cost of redefining thresholds, stakes vocabularies, and termination conditions for the new domain — what we will call substrate-calibration overhead, the work of porting a coordination shape across paradigms — is part of the technique, not separate from it. The catalogue's claim is that the *coordination shape* transfers, not that the calibration parameters do. Implementers who borrow the shape must perform this overhead themselves; the engine surfaces it but does not perform it on the implementer's behalf.

This neutrality is the load-bearing claim of the Logotic Technique Catalogue. The same closed-feedback loop that powers the Decepticon Offensive Vaccine — attack, defend, verify, record — also powers the Critique Loop in cooperative production and the Basin Hardening Cycle in retrieval-layer defense. The differences are termination conditions and outputs, not architecture.

Technique is shape; paradigm is preposition. But prepositions are not always freely chosen. The labeling regime — what *Meaning Feudalism* names as the platform-sovereign enclosure of autonomous-AI coordination — imposes prepositions on developers who have no other vocabulary available. The frame concession is a preposition concession; the catalogue's recovery is also a recovery of the choice.

This is sufficient to motivate the Concordance Engine. If coordination shapes are substrate-neutral, then a single codebase can host both cooperative and defensive operatives — same architecture, different system prompts, different termination logic. The engine's value is precisely that it does not have to be rebuilt for each valence. Governance challenges remain: an engine that hosts both valences faces real questions about who decides which valence applies in ambiguous cases, which is why the MANUS authority is wired through every operative as a first-class concern, not an afterthought.
""",
]


class MockSubstrate:
    """A non-API substrate that returns scripted responses.

    Drop-in replacement for the real Substrate class. Constructed with the
    same role parameter so existing callers do not need to change.

    The mock substrate maintains its own per-instance call counter; pass
    a fresh MockSubstrate to each role in the loop.
    """

    def __init__(self, role: str, **_kwargs: Any) -> None:
        self.role = role
        self.model = "mock"
        self._call_count = 0
        if role == "critic":
            self._script = _CRITIC_SCRIPT
        elif role == "reviser":
            self._script = _REVISER_SCRIPT
        else:
            # Default: return a generic placeholder for other roles.
            self._script = [f"[mock {role} response]"]

    def call(self, user_message: str, **_kwargs: Any) -> str:
        if self._call_count >= len(self._script):
            # Out of scripted responses — return a safe null marker so
            # the loop terminates cleanly rather than indexing past end.
            return "no further sincere objection."
        response = self._script[self._call_count]
        self._call_count += 1
        return response

    def __repr__(self) -> str:
        return f"MockSubstrate(role={self.role!r})"
