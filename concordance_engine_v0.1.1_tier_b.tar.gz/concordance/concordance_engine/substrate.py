"""
Concordance Engine — substrate access layer.

A thin wrapper around the Anthropic API that exposes substrate roles
(Critic, Reviser, etc.) as discrete callables, each loading its own
system prompt from agents/<role>.md.

This module is the seam between the engine's architectural shape and
the underlying LLM provider. Future implementation tiers can swap in
other providers (OpenAI, DeepSeek) by extending this class. The Critique
Loop and other operatives do not need to know which substrate answers them.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

try:
    import anthropic
    _HAS_ANTHROPIC = True
except ImportError:
    _HAS_ANTHROPIC = False


# Default model. Override per-role via config/substrates.yaml in future tiers.
DEFAULT_MODEL = "claude-sonnet-4-6"
DEFAULT_MAX_TOKENS = 4096

# Path to agent system prompts (relative to package root)
_AGENTS_DIR = Path(__file__).parent.parent / "agents"


class SubstrateError(RuntimeError):
    """Raised when substrate access fails in a way the loop should not retry."""


class Substrate:
    """A role-aware wrapper around the Anthropic API.

    Each role's system prompt lives at agents/<role>.md. The substrate
    loads the prompt once at instantiation and reuses it across calls.
    """

    def __init__(
        self,
        role: str,
        model: str = DEFAULT_MODEL,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        api_key: str | None = None,
    ) -> None:
        if not _HAS_ANTHROPIC:
            raise SubstrateError(
                "anthropic package not installed. Run: pip install anthropic"
            )

        self.role = role
        self.model = model
        self.max_tokens = max_tokens

        api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise SubstrateError(
                "ANTHROPIC_API_KEY not set. Export it or pass api_key explicitly."
            )

        self.client = anthropic.Anthropic(api_key=api_key)
        self.system_prompt = self._load_prompt(role)

    @staticmethod
    def _load_prompt(role: str) -> str:
        prompt_path = _AGENTS_DIR / f"{role}.md"
        if not prompt_path.exists():
            raise SubstrateError(
                f"Agent prompt not found: {prompt_path}. "
                f"Available roles: {[p.stem for p in _AGENTS_DIR.glob('*.md')]}"
            )
        return prompt_path.read_text(encoding="utf-8")

    def call(self, user_message: str, **kwargs: Any) -> str:
        """Send a user message to the substrate. Return the text response.

        Raises SubstrateError on API failures the loop should not retry.
        """
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                system=self.system_prompt,
                messages=[{"role": "user", "content": user_message}],
                **kwargs,
            )
        except anthropic.APIError as e:
            raise SubstrateError(f"Anthropic API call failed: {e}") from e

        # Extract text from the response. The Anthropic API returns a list of
        # content blocks; we concatenate the text-type blocks.
        text_parts = []
        for block in response.content:
            if hasattr(block, "text"):
                text_parts.append(block.text)
        return "\n".join(text_parts)

    def __repr__(self) -> str:
        return f"Substrate(role={self.role!r}, model={self.model!r})"
