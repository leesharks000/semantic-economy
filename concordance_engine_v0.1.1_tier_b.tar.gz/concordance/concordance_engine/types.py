"""
Concordance Engine — type definitions.

These types implement the load-bearing data structures for the Critique Loop
specified in §V.12 of the Logotic Technique Catalogue
(DOI: 10.5281/zenodo.19831619).

The types are deliberately minimal. The Tier B reference implementation
prioritizes legibility over feature completeness. Future implementation tiers
may extend these classes; they should not break the contracts established here.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any


class TerminationReason(Enum):
    """Why a Critique Loop terminated.

    Per the Logotic Technique Catalogue §V.12, the Critique Loop terminates
    when no sincere objection remains, OR when MANUS overrules and accepts
    a residual disagreement. Both conditions are R3 — both bear cost,
    enrich commons, and preserve the structure of the disagreement in the
    durable record.
    """

    NO_FURTHER_CRITIQUE = "no_further_critique"
    MANUS_OVERRIDE = "manus_override"
    MAX_ITERATIONS_REACHED = "max_iterations_reached"


@dataclass
class Draft:
    """A draft manuscript at any iteration of the loop."""

    text: str
    iteration: int = 0
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def __str__(self) -> str:
        preview = self.text[:120].replace("\n", " ")
        return f"Draft(iter={self.iteration}, len={len(self.text)}, preview={preview!r}...)"


@dataclass
class Critique:
    """The strongest sincere critique a Critic-substrate produces against a draft.

    Critiques are not adversarial. They are diagnostic. The Critic's role is to
    produce the strongest legitimate objection consistent with sincere engagement
    — not to win, not to demolish, but to surface the gap that the draft has not
    yet addressed.

    A Critique with `is_null=True` indicates the Critic finds no remaining sincere
    objection. This terminates the loop.
    """

    objections: list[str]
    severity: str  # "critical" | "substantive" | "minor"
    is_null: bool = False
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    @classmethod
    def null(cls) -> Critique:
        """Return a null critique (loop termination signal)."""
        return cls(objections=[], severity="minor", is_null=True)

    def __str__(self) -> str:
        if self.is_null:
            return "Critique(null — no further objection)"
        return f"Critique(severity={self.severity}, objections={len(self.objections)})"


@dataclass
class RevisionBrief:
    """An actionable summary of what the revision must address.

    Generated from a Critique. The Reviser uses this brief — not the full
    Critique text — as the operative input to its revision.
    """

    summary: str
    required_addresses: list[str]
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class HistoryEntry:
    """One step in the loop's provenance chain."""

    step_type: str  # "critique" | "revision" | "manus_override"
    iteration: int
    payload: dict[str, Any]
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class Deposit:
    """The final artefact emitted by a completed Critique Loop.

    Includes the manuscript and the full provenance chain. The provenance
    chain itself is part of the deposit — it is what makes the deposit
    R3 rather than R1 (cost is borne and visible; the work shows its work).
    """

    manuscript: Draft
    history: list[HistoryEntry]
    termination: TerminationReason
    residual_dissent: str | None = None
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["termination"] = self.termination.value
        return d

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def write_provenance_log(self, path: Path) -> None:
        """Write the full provenance chain to a deposit file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.to_json(), encoding="utf-8")

    def __str__(self) -> str:
        return (
            f"Deposit(iter_count={len(self.history)}, "
            f"termination={self.termination.value}, "
            f"manuscript_len={len(self.manuscript.text)}, "
            f"residual_dissent={'yes' if self.residual_dissent else 'no'})"
        )
