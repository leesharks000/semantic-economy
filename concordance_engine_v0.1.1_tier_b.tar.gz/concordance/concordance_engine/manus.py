"""
Concordance Engine — MANUS interface.

In the Crimson Hexagonal Archive's witness-teaming methodology, MANUS is
the human principal whose authority governs the work. The Critique Loop
allows MANUS to override the loop — to accept a residual disagreement
when the Critic and Reviser have reached a substantive impasse and MANUS
judges the disagreement to be irreducible rather than unresolved.

This module provides a minimal MANUS interface for the Tier B reference
implementation. Production deployments would replace InteractiveManus
with a more elaborate interface (web UI, Slack integration, etc.) that
preserves the same contract.
"""

from __future__ import annotations

import sys
from typing import Protocol

from .types import Critique


class ManusInterface(Protocol):
    """The contract any MANUS implementation must satisfy."""

    def overrules(self, critique: Critique, iteration: int) -> bool:
        """Return True if MANUS chooses to override the loop and accept residual dissent."""
        ...

    def rationale(self) -> str:
        """Return MANUS's rationale for the most recent override."""
        ...


class InteractiveManus:
    """A human-in-the-loop MANUS that prompts via stdin.

    Use this for development, testing, and small-scale deposits. For
    automated runs, see SilentManus.
    """

    def __init__(self) -> None:
        self._last_rationale: str = ""

    def overrules(self, critique: Critique, iteration: int) -> bool:
        if critique.is_null:
            return False

        print(f"\n{'='*60}")
        print(f"MANUS DECISION POINT — iteration {iteration}")
        print(f"{'='*60}")
        print(f"Critique severity: {critique.severity}")
        print(f"Objections ({len(critique.objections)}):")
        for i, obj in enumerate(critique.objections, 1):
            print(f"  {i}. {obj}")

        choice = input(
            "\nOverride and accept residual dissent? [y/N]: "
        ).strip().lower()

        if choice == "y":
            self._last_rationale = input(
                "MANUS rationale (logged with provenance): "
            ).strip()
            return True
        return False

    def rationale(self) -> str:
        return self._last_rationale


class SilentManus:
    """A non-interactive MANUS that never overrides.

    Use this for automated runs where the loop should run to completion
    without human intervention. The loop will terminate when the Critic
    returns a null critique OR when max_iterations is reached.
    """

    def overrules(self, critique: Critique, iteration: int) -> bool:
        return False

    def rationale(self) -> str:
        return ""


class CallbackManus:
    """A MANUS configured with a Python callback.

    Use this when integrating the Critique Loop into a larger application
    (e.g., a Slack bot, a web app, an MCP server).
    """

    def __init__(self, override_callback, rationale_callback=None) -> None:
        self._override_cb = override_callback
        self._rationale_cb = rationale_callback or (lambda: "")

    def overrules(self, critique: Critique, iteration: int) -> bool:
        return bool(self._override_cb(critique, iteration))

    def rationale(self) -> str:
        return self._rationale_cb()
