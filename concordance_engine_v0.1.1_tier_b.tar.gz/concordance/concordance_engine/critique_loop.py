"""
Concordance Engine — Critique Loop reference implementation.

The Critique Loop is the cooperative inversion of the Decepticon Offensive
Vaccine (Logotic Technique Catalogue §V.12, DOI: 10.5281/zenodo.19831619).
The same closed-feedback shape — probe → respond → re-probe → record —
runs under the witness preposition with protocol-bound constraint, with
opposite termination conditions and opposite outputs.

The Vaccine Loop terminates when the defense holds against an adversary.
The Critique Loop terminates when no sincere objection remains.

Same shape; opposite termination condition; opposite output.

This implementation depends on:
- agents/critic.md — the Critic-substrate's system prompt
- agents/reviser.md — the Reviser-substrate's system prompt
- An ANTHROPIC_API_KEY environment variable
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

from .manus import ManusInterface, SilentManus
from .substrate import Substrate
from .types import (
    Critique,
    Deposit,
    Draft,
    HistoryEntry,
    RevisionBrief,
    TerminationReason,
)


# ── Critique parsing ────────────────────────────────────────────────────────

# The Critic prompt instructs use of the exact phrase "no further sincere
# objection" as the authoritative termination marker. We deliberately keep
# this marker list narrow to prevent false closure: a phrase like "the draft
# now addresses X, but still fails to address Y" would falsely terminate the
# loop if matched on its prefix. The canonical termination signal is the
# explicit phrase below.
_NULL_CRITIQUE_MARKERS = (
    "no further sincere objection",
)


def _parse_critique(raw_text: str) -> Critique:
    """Parse a Critic-substrate response into a Critique.

    The Critic is instructed (see agents/critic.md) to use a specific
    structured format. If the Critic indicates no further objection, we
    return a null Critique. Otherwise we extract the objections list.
    """
    text_lower = raw_text.lower()

    if any(marker in text_lower for marker in _NULL_CRITIQUE_MARKERS):
        return Critique.null()

    # Extract numbered objections (e.g., "1. The argument in §III...")
    objection_pattern = re.compile(
        r"^\s*(?:\d+[.)]\s*|\-\s+|\*\s+)(.+?)(?=\n\s*(?:\d+[.)]|\-\s|\*\s|$))",
        re.MULTILINE | re.DOTALL,
    )
    raw_objections = objection_pattern.findall(raw_text)
    objections = [obj.strip() for obj in raw_objections if obj.strip()]

    # Fallback: if no numbered structure, treat each non-empty paragraph as one
    # objection.
    if not objections:
        paragraphs = [p.strip() for p in raw_text.split("\n\n") if p.strip()]
        # Skip likely framing paragraphs (very short or starting with meta-words)
        objections = [
            p for p in paragraphs
            if len(p) > 40 and not p.lower().startswith(("here", "i ", "the following"))
        ]

    severity = _infer_severity(raw_text)
    return Critique(objections=objections, severity=severity)


def _infer_severity(raw_text: str) -> str:
    """Infer critique severity from textual cues. Conservative default."""
    text_lower = raw_text.lower()
    if any(w in text_lower for w in ("load-bearing", "critical", "fundamental", "central")):
        return "critical"
    if any(w in text_lower for w in ("minor", "small", "polish", "tightening", "perfective")):
        return "minor"
    return "substantive"


# ── Revision-brief generation ───────────────────────────────────────────────

def _generate_revision_brief(critique: Critique) -> RevisionBrief:
    """Convert a Critique into an actionable RevisionBrief.

    The brief is the operative input the Reviser receives. It is
    deliberately shorter and more actionable than the full Critique —
    the Reviser does not need to read the Critic's full reasoning;
    it needs a list of things to address.
    """
    summary_parts = [
        f"Critique severity: {critique.severity}",
        f"Number of objections to address: {len(critique.objections)}",
    ]
    return RevisionBrief(
        summary=" | ".join(summary_parts),
        required_addresses=list(critique.objections),
    )


# ── Reviser invocation ─────────────────────────────────────────────────────

def _format_revision_request(draft: Draft, brief: RevisionBrief) -> str:
    """Format the user message sent to the Reviser-substrate."""
    addresses_block = "\n".join(
        f"  {i}. {obj}" for i, obj in enumerate(brief.required_addresses, 1)
    )
    return (
        "Revise the draft below to address each numbered objection. "
        "Preserve the draft's voice, structure, and load-bearing claims. "
        "Make the minimum changes necessary to address the objections.\n\n"
        f"OBJECTIONS TO ADDRESS:\n{addresses_block}\n\n"
        f"CURRENT DRAFT:\n\n{draft.text}\n\n"
        "Return only the revised draft text. Do not include preamble, "
        "explanation, or commentary about your changes."
    )


def _format_critique_request(draft: Draft) -> str:
    """Format the user message sent to the Critic-substrate."""
    return (
        f"Produce the strongest sincere critique of the draft below. "
        f"Find the gap that the draft has not yet addressed. "
        f"If you find no remaining sincere objection, say so explicitly with "
        f"the phrase 'no further sincere objection'.\n\n"
        f"DRAFT (iteration {draft.iteration}):\n\n{draft.text}"
    )


# ── The loop ───────────────────────────────────────────────────────────────

def critique_loop(
    initial_draft: str,
    *,
    max_iterations: int = 5,
    critic: Substrate | None = None,
    reviser: Substrate | None = None,
    manus: ManusInterface | None = None,
    on_iteration=None,  # optional callback: (iteration, critique, draft) -> None
) -> Deposit:
    """Run the Critique Loop on a draft until termination.

    Args:
        initial_draft: The draft text to refine.
        max_iterations: Hard upper bound on iterations. Default 5.
        critic: Critic-substrate. Default: new Substrate("critic").
        reviser: Reviser-substrate. Default: new Substrate("reviser").
        manus: MANUS interface for override decisions. Default: SilentManus()
               (non-interactive; the loop runs to natural termination or
               max_iterations).
        on_iteration: Optional callback invoked after each iteration with
                      (iteration, critique, current_draft).

    Returns:
        A Deposit containing the final manuscript and the full provenance chain.

    The loop terminates when:
        1. The Critic returns a null critique (no further sincere objection), OR
        2. MANUS overrules and accepts the residual disagreement, OR
        3. max_iterations is reached.
    """
    critic = critic or Substrate(role="critic")
    reviser = reviser or Substrate(role="reviser")
    manus = manus or SilentManus()

    draft = Draft(text=initial_draft, iteration=0)
    history: list[HistoryEntry] = []
    termination = TerminationReason.MAX_ITERATIONS_REACHED
    residual_dissent: str | None = None

    for iteration in range(1, max_iterations + 1):
        # 1. Critic produces strongest sincere critique
        critique_text = critic.call(_format_critique_request(draft))
        critique = _parse_critique(critique_text)
        history.append(
            HistoryEntry(
                step_type="critique",
                iteration=iteration,
                payload={
                    "raw_text": critique_text,
                    "objections": critique.objections,
                    "severity": critique.severity,
                    "is_null": critique.is_null,
                },
            )
        )

        if on_iteration is not None:
            on_iteration(iteration, critique, draft)

        # 2. Termination check: null critique
        if critique.is_null:
            termination = TerminationReason.NO_FURTHER_CRITIQUE
            break

        # 3. Termination check: MANUS override
        if manus.overrules(critique, iteration):
            termination = TerminationReason.MANUS_OVERRIDE
            residual_dissent = (
                f"MANUS rationale: {manus.rationale()}\n\n"
                f"Residual objections (n={len(critique.objections)}):\n"
                + "\n".join(f"  - {obj}" for obj in critique.objections)
            )
            history.append(
                HistoryEntry(
                    step_type="manus_override",
                    iteration=iteration,
                    payload={
                        "rationale": manus.rationale(),
                        "residual_objections": critique.objections,
                    },
                )
            )
            break

        # 4. Reviser applies the revision
        brief = _generate_revision_brief(critique)
        revised_text = reviser.call(_format_revision_request(draft, brief))
        # Record content hashes alongside metadata for tamper-evident
        # provenance without storing full draft text in the history log.
        # Per-iteration full drafts are written to workspace/drafts/ separately
        # (see demo_critique_loop.py for the persistence path).
        previous_sha = hashlib.sha256(draft.text.encode("utf-8")).hexdigest()
        revised_sha = hashlib.sha256(revised_text.encode("utf-8")).hexdigest()
        draft = Draft(text=revised_text, iteration=iteration)
        history.append(
            HistoryEntry(
                step_type="revision",
                iteration=iteration,
                payload={
                    "revision_brief_summary": brief.summary,
                    "addresses_count": len(brief.required_addresses),
                    "draft_length": len(revised_text),
                    "previous_sha256": previous_sha,
                    "revised_sha256": revised_sha,
                },
            )
        )

    return Deposit(
        manuscript=draft,
        history=history,
        termination=termination,
        residual_dissent=residual_dissent,
    )
