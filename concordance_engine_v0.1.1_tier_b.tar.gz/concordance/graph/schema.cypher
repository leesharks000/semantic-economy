// ============================================================================
// APERTURE ATLAS — Cypher schema (Neo4j 5.x)
// Logotic Technique Catalogue §V.5, §VI.5
// DOI: 10.5281/zenodo.19831619
// ============================================================================
//
// Deploy this file to a Neo4j 5.x instance:
//   $ cypher-shell -u neo4j -p <password> < schema.cypher
//
// Or via the browser interface, paste the entire file as one query.
//
// The schema models the Crimson Hexagonal Archive's six-type ontology
// with logotic-vocabulary typed relationships. It supports both
// cooperative-mode queries (provenance graphs, citation networks) and
// defensive-mode queries (ghost-basin detection, term collision tracking).

// ── Node constraints (six-type ontology) ─────────────────────────────────────

CREATE CONSTRAINT IF NOT EXISTS FOR (n:INFRASTRUCTURE)
  REQUIRE n.id IS UNIQUE;

CREATE CONSTRAINT IF NOT EXISTS FOR (n:SURFACE)
  REQUIRE n.id IS UNIQUE;

CREATE CONSTRAINT IF NOT EXISTS FOR (n:ENTITY)
  REQUIRE n.id IS UNIQUE;

CREATE CONSTRAINT IF NOT EXISTS FOR (n:IDENTITY)
  REQUIRE n.id IS UNIQUE;

CREATE CONSTRAINT IF NOT EXISTS FOR (n:DOCUMENT)
  REQUIRE n.id IS UNIQUE;

CREATE CONSTRAINT IF NOT EXISTS FOR (n:PLATFORM)
  REQUIRE n.id IS UNIQUE;

// ── Indexes for query performance ────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS FOR (n:DOCUMENT)
  ON (n.doi);

CREATE INDEX IF NOT EXISTS FOR (n:DOCUMENT)
  ON (n.publication_date);

CREATE INDEX IF NOT EXISTS FOR (n:ENTITY)
  ON (n.basin_state);

CREATE INDEX IF NOT EXISTS FOR (n:IDENTITY)
  ON (n.orcid);

// ── Relationship type vocabulary ─────────────────────────────────────────────
//
// The following relationship types are reserved by the Aperture Atlas schema.
// They are not declared via constraints (Neo4j relationships do not require
// declarative typing), but client code SHOULD restrict to this vocabulary
// to preserve graph-query semantics.
//
// Citational (DOCUMENT → DOCUMENT):
//   :CITES                  — direct citation
//   :EXTENDS                — builds on; the cited work is methodology/foundation
//   :SUPERSEDES             — replaces; the cited work is now obsolete
//   :REVISES                — new version of the cited work
//   :RESPONDS_TO            — engages the cited work critically
//   :COMPLEMENTS            — companion artefact
//   :FOUNDS                 — establishes a series the cited work is part of
//   :IMPLEMENTS             — runnable instantiation of the cited work
//   :CONTRADICTS            — argues against
//   :COMPLETES              — closes a loop / fills a gap the cited work opened
//
// Structural:
//   :CONTAINS               — DOCUMENT contains ENTITY/IDENTITY references
//   :DEFINES                — DOCUMENT defines ENTITY (term coinage)
//   :AUTHORED_BY            — DOCUMENT → IDENTITY
//   :DEPOSITED_AT           — DOCUMENT → INFRASTRUCTURE (Zenodo, etc.)
//
// Surface / retrieval:
//   :LINKS_TO               — SURFACE → SURFACE (HTML link, blue link)
//   :APPEARS_ON             — ENTITY → PLATFORM (retrieval-layer presence)
//   :BASIN_OF               — ENTITY → SURFACE (the term's basin home)
//
// Defensive layer:
//   :DEFENDED_BY            — ENTITY → DOCUMENT (deposit hardening the basin)
//   :COLLIDES_WITH          — ENTITY → ENTITY (term collision detected)
//   :DISAMBIGUATES_FROM     — ENTITY → ENTITY (declared distinction)
//   :CONTESTED_BY           — DOCUMENT → IDENTITY (priority dispute)

// ── Standing queries ─────────────────────────────────────────────────────────
//
// These queries are the primary defensive instruments. They are not part of
// the schema proper (queries are not deployed; they are stored in
// graph/queries/) but they are listed here because their efficient execution
// determined index choices above.
//
// Q1: Ghost basins requiring hardening
//   MATCH (n:ENTITY) WHERE n.basin_state = 'ghost' RETURN n;
//
// Q2: Deposits responding to a competitor's claim
//   MATCH (d:DOCUMENT)-[:RESPONDS_TO]->(c:DOCUMENT)
//   WHERE c.origin <> 'crimsonhexagonal' RETURN d, c;
//
// Q3: Outbound reference graph for a given deposit
//   MATCH (n:DOCUMENT {id: $deposit_id})-[r]->(m)
//   RETURN type(r), m ORDER BY type(r);
//
// Q4: Term collision events for a minted term
//   MATCH (n:ENTITY {name: $term_name})-[:COLLIDES_WITH]->(other)
//   RETURN other, other.detected_at ORDER BY other.detected_at DESC;

// ── Schema deployment confirmation ───────────────────────────────────────────

RETURN "Aperture Atlas schema deployed. " +
       "6 node-type constraints, " +
       "4 indexes, " +
       "vocabulary documented above." AS status;
