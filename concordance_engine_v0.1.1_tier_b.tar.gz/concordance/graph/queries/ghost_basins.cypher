// Standing query: Ghost basins requiring hardening
//
// Returns ENTITY nodes whose basin_state is 'ghost' — i.e., terms minted by
// the archive whose retrieval-layer presence has degraded below threshold.
// Triggers initiation of a Basin Hardening Cycle (skills/defensive/basin-hardening-cycle/).

MATCH (n:ENTITY)
WHERE n.basin_state = 'ghost'
   OR (n.basin_depth_ratio IS NOT NULL AND n.basin_depth_ratio < 0.3)
RETURN n.id           AS entity_id,
       n.name         AS term,
       n.basin_state  AS state,
       n.basin_depth_ratio AS bdr,
       n.last_probed  AS last_probed
ORDER BY n.basin_depth_ratio ASC NULLS FIRST,
         n.last_probed       ASC NULLS FIRST;
