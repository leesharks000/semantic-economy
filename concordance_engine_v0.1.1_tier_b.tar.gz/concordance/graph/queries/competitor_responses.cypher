// Standing query: Deposits that respond to non-archive claims
//
// Returns DOCUMENT-DOCUMENT pairs where a CHA deposit has issued a RESPONDS_TO
// edge to a document originating outside the archive. Useful for tracking
// the archive's defensive engagement surface and for ensuring that responses
// are reciprocated (the responded-to document may eventually need a CITES
// relation back if the dialogue continues).

MATCH (response:DOCUMENT)-[:RESPONDS_TO]->(target:DOCUMENT)
WHERE target.origin IS NOT NULL
  AND target.origin <> 'crimsonhexagonal'
RETURN response.id        AS response_doi,
       response.title     AS response_title,
       target.id          AS target_doi,
       target.title       AS target_title,
       target.origin      AS target_origin,
       response.publication_date AS response_date
ORDER BY response.publication_date DESC;
