// Standing query: Outbound reference graph for a given deposit
//
// Parameter: $deposit_id — the DOI or local identifier of the source deposit
//
// Returns every typed relation outbound from the deposit, grouped by relation
// type. Used by the Archivist (agents/archivist.md) to verify that a deposit's
// declared related_identifiers match its actual citation environment, and by
// the depth-proof validator (skills/defensive/depth-proof-validator/) to
// compute first-party cross-reference counts.

MATCH (source:DOCUMENT {id: $deposit_id})-[r]->(target)
RETURN type(r)                AS relation_type,
       target.id              AS target_id,
       labels(target)         AS target_labels,
       coalesce(target.title, target.name, target.id) AS target_label
ORDER BY relation_type, target.id;
