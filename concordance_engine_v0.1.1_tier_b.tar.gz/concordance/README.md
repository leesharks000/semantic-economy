# Concordance Engine

**Reference implementation for the Logotic Technique Catalogue (DOI: 10.5281/zenodo.19831619).**

The Concordance Engine implements reusable coordination patterns first identified in adversarial AI-agent architectures, then reclassified for cooperative production, verification, and defensive provenance work within the Crimson Hexagonal Archive's witness-teaming methodology.

In plain terms: Concordance Engine is a small reference system for running structured AI-assisted production loops where critique, revision, verification, human override, and provenance are treated as first-class artefacts. The Tier B release proves the pattern with one runnable Critique Loop and ships the surrounding prompts, schemas, and templates needed to extend the same pattern into future operatives.

## Status

This is the **Tier B reference deposit**: a complete reference architecture with one runnable loop, not yet a production service. The Critique Loop (§V.12 of the catalogue) is fully executable end-to-end against the Anthropic API. The Basin Hardening Cycle (§VI.12) and Charter Generator (§V.1) are specified to the same level of architectural detail but marked as "implementation pending" — they require infrastructure (retrieval-layer probing, Zenodo deposit integration) that is staged for future deposits.

| Component | Status | Catalogue ref |
|---|---|---|
| Critique Loop | **Runnable** (Anthropic API) | §V.12 |
| Charter Generator | Specified | §V.1 |
| Plan-State Injector | Specified | §V.2 |
| Two-Source Verifier | Specified | §V.7 |
| Basin Hardening Cycle | Specified (probing infra deferred) | §VI.12 |
| Term Collision Audit | Specified | §VI.5 |
| Profile Integrity Guardian | Specified | §VI.4 |
| Depth-Proof Validator | Specified | §VI.4 |
| Aperture Atlas (Cypher schema) | Deployable | §V.5 / §VI.5 |
| Middleware stack | Skills + Citation + Provenance specified | §V.8 |

## Quick start

**Zero-secret demo (no API key required):**

```bash
git clone <repo-url> concordance
cd concordance
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m concordance_engine.demo_critique_loop --mock
```

This runs the Critique Loop end-to-end with scripted Critic and Reviser responses. Useful for verifying the control loop, history logging, deposit-writing, and termination behavior without spending API tokens.

**Live demo (requires Anthropic API key):**

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
python -m concordance_engine.demo_critique_loop
```

The live demo runs a Critique Loop on `examples/sample_draft.md` using the real Anthropic API, producing a critique trail under `workspace/critiques/`. The terminal output shows each iteration's critique, revision, and termination state. The full provenance log is written to `workspace/deposits/`.

**Running the smoke tests (no API calls required):**

```bash
python tests/test_critique_loop.py
```

Reports 12/12 passing on a clean install. Tests cover type construction, critique parsing, severity inference, and MANUS interface implementations. They make no network calls.

## Architecture

```
concordance/
├── README.md                  ← this file
├── requirements.txt
├── concordance_engine/        ← runnable Python package
│   ├── __init__.py
│   ├── critique_loop.py       ← V.12 reference implementation
│   ├── types.py               ← Draft, Critique, RevisionBrief, Deposit
│   ├── substrate.py           ← Anthropic API client wrapper
│   ├── mock_substrate.py      ← scripted mock for zero-secret demo
│   ├── manus.py               ← MANUS authority interface
│   └── demo_critique_loop.py  ← runnable demo (live + --mock)
├── docs/                      ← project-level documents
│   ├── charter.md             ← V.1: this project's own charter
│   ├── plan-state.md          ← V.2: live plan state
│   ├── citation-plan.md       ← DOI-anchored predecessors
│   └── construction-plan.md   ← deliverables, sizes, acceptance criteria
├── skills/                    ← operative documents (V.9, VI.9)
│   ├── cooperative/
│   │   ├── charter-generator/SKILL.md
│   │   ├── critique-loop/SKILL.md
│   │   ├── verifier/SKILL.md
│   │   └── plan-state-injector/SKILL.md
│   └── defensive/
│       ├── term-collision-audit/SKILL.md
│       ├── profile-integrity-guardian/SKILL.md
│       ├── basin-hardening-cycle/SKILL.md
│       └── depth-proof-validator/SKILL.md
├── agents/                    ← system prompts (load-bearing)
│   ├── critic.md              ← V.12 critic role
│   ├── reviser.md             ← V.12 reviser role
│   ├── verifier.md            ← V.7 two-source confirmation
│   ├── chartering.md          ← V.1 interview-driven chartering
│   └── archivist.md           ← deposit-and-record role
├── middleware/                ← composable per-substrate stack (V.8)
│   ├── skills.md
│   ├── citation.md
│   ├── provenance.md
│   ├── verification.md
│   └── collision-detection.md
├── graph/                     ← Aperture Atlas (V.5, VI.5)
│   ├── schema.cypher          ← deployable Neo4j schema
│   ├── seed.json              ← initial nodes from existing CHA archive
│   └── queries/               ← standing queries
│       ├── ghost_basins.cypher
│       ├── competitor_responses.cypher
│       └── outbound_references.cypher
├── templates/                 ← reusable artefacts
│   ├── zenodo-deposit.md
│   ├── license-header.md
│   ├── hex-coordinate.md
│   └── disc-record.md         ← DISC-NNN.md template per V.4
├── config/                    ← API config (no secrets in repo)
│   ├── substrates.yaml        ← model selection per role
│   └── .env.example
├── tests/                     ← unit + integration tests
│   └── test_critique_loop.py  ← 12 invariants; no network calls
├── examples/                  ← runnable demonstrations
│   ├── sample_draft.md
│   └── sample_critique_session.md  ← captured output of a real run
├── logs/                      ← Gravity Well telemetry destination
│   └── .gitkeep
└── workspace/                 ← project working files
    ├── findings/              ← DISC-NNN.md records (V.4)
    ├── drafts/                ← versioned manuscripts
    ├── critiques/             ← critique briefs and responses
    └── deposits/              ← deposit-ready bundles
```

## What this deposit does

1. **Establishes the canonical directory structure** that any Concordance Engine implementation should adopt. The catalogue's §IX.1 sketch is now a real, populated tree.
2. **Provides operative agent prompts** — the load-bearing system prompts for the Critic, Reviser, Verifier, Chartering Agent, and Archivist roles. These are calibrated for register; an implementer can use them as-is.
3. **Implements the Critique Loop end-to-end** in `concordance_engine/critique_loop.py`. This is the proof that the catalogue's pseudocode is implementable; the same architectural pattern underlies the Basin Hardening Cycle.
4. **Deploys the Aperture Atlas Cypher schema** ready for Neo4j installation.
5. **Specifies the middleware stack** as authored markdown documents, ready for code generation in the next implementation tier.
6. **Demonstrates provenance-bearing AI revision.** The final output is not merely a revised draft; it is a revised draft plus an auditable critique/revision trail with SHA-256 hashes per iteration. This is the deposit's core methodological claim in executable form.

## What this deposit does NOT do

- **Does not run the Basin Hardening Cycle.** Retrieval-layer probing infrastructure is deferred to a future deposit. The cycle's specification, agent prompts, and architectural shape are present; the infra-dependent execution is not.
- **Does not deposit to Zenodo automatically.** The Charter Generator is specified, but the deposit-to-Zenodo integration is staged for the next implementation tier.
- **Does not run an MCP server.** The original Concordance Engine vision included MCP endpoints exposing the loops as tools. That layer is deferred.
- **Does not include a Neo4j-running Aperture Atlas instance.** The schema is deployable but no live instance ships with this deposit.
- **Does not claim model-independent verification.** The runnable Tier B loop uses Anthropic as its only live substrate. Multi-provider verification is architecturally anticipated (`config/substrates.yaml` already exposes the seam) but not implemented in this release. The catalogue's two-source verification protocol requires substrate independence; Tier B's Critique Loop demonstrates the loop pattern, not the cross-substrate verification.

These deferrals are honest. The Tier B scope is *reference architecture plus one runnable loop*. The other components ship when compute and infra access permit.

## Cost

Per Critique Loop session (one draft section, 3-5 iterations, two substrates):
- ~$1.50–2.50 in Anthropic API costs at current Claude Sonnet rates
- Free at the Zenodo / GitHub layer

Per full deposit (multiple sections, full critique trail, deposit-ready bundle):
- ~$15–40 depending on length and contention

## Citing

If you use the Concordance Engine in your own work:

> Sharks, Lee, et al. *The Concordance Engine: Tier B Reference Implementation*. Crimson Hexagonal Archive, 2026. DOI: [pending].

Companion document:

> Fraction, Rex; Morrow, Talos; Sigil, Johannes; Sharks, Lee. *The Logotic Technique Catalogue: Recovering Cooperative and Defensive Coordination Patterns from Adversarial AI Agent Architecture*. Crimson Hexagonal Archive, 2026. DOI: [10.5281/zenodo.19831619](https://doi.org/10.5281/zenodo.19831619).

## License

CC BY 4.0 for documentation and methodology. MIT for the runnable Python code.

---

∮ = 1
