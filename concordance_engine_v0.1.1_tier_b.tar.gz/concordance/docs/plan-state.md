# Plan-State — Concordance Engine

Live state for the engine project. Updated as objectives complete.

## Objectives

| ID | Objective | Status | Owner |
|---|---|---|---|
| OBJ-01 | Reference directory structure populated | complete | TACHYON |
| OBJ-02 | Critique Loop runnable end-to-end | complete | TACHYON |
| OBJ-03 | Agent prompts authored (Critic, Reviser, Verifier, Chartering, Archivist) | complete | TACHYON |
| OBJ-04 | Skill specs authored (cooperative + defensive) | complete | TACHYON |
| OBJ-05 | Middleware specs authored | complete | TACHYON |
| OBJ-06 | Aperture Atlas Cypher schema deployable | complete | TACHYON |
| OBJ-07 | Standing queries authored | complete | TACHYON |
| OBJ-08 | Templates authored (deposit, license, hex, DISC) | complete | TACHYON |
| OBJ-09 | Config files (substrates.yaml, .env.example) | complete | TACHYON |
| OBJ-10 | Sample example session captured | complete | TACHYON |
| OBJ-11 | Tests (smoke-test Critique Loop, 12 invariants) | complete (12/12 passing) | TACHYON |
| OBJ-12 | Mock substrate for zero-secret demo | complete | TACHYON |
| OBJ-13 | Construction plan documented | complete | TACHYON |
| OBJ-14 | Zenodo deposit metadata template | complete | TACHYON |
| OBJ-15 | Final DOI-anchored deposit | pending DOI assignment | MANUS |

## Dependency graph

```
OBJ-01 ──┬──→ OBJ-02 ──→ OBJ-11 ──→ OBJ-13
         ├──→ OBJ-03
         ├──→ OBJ-04
         ├──→ OBJ-05
         ├──→ OBJ-06 ──→ OBJ-07
         ├──→ OBJ-08
         ├──→ OBJ-09
         └──→ OBJ-10 ──→ OBJ-12 ──→ OBJ-13
```

## Tier B exit criteria — ALL MET

The deposit ships when:
1. ✅ Critique Loop runs end-to-end on `examples/sample_draft.md` against the Anthropic API
2. ✅ Critique Loop runs end-to-end via `--mock` flag with no API key (zero-secret reproducibility)
3. ✅ All five agent prompts are authored at calibrated register
4. ✅ All eight skill specs are present (four cooperative, four defensive)
5. ✅ Aperture Atlas Cypher schema deploys cleanly to a fresh Neo4j 5.x instance
6. ✅ Smoke tests pass (12/12 invariants verified)
7. ✅ Zenodo metadata JSON is paste-ready
8. ✅ README and Charter are complete; README directory tree matches actual layout
9. ✅ All construction-plan deliverables are present

## Tier C roadmap (post-deposit)

- Runnable Charter Generator (interview interface + Zenodo deposit creation)
- Runnable Verifier (source-pool retrieval + DISP-NNN.md generation)
- Runnable Basin Hardening Cycle (retrieval-layer probing + basin-metrics computation)
- MCP server exposure
- Live Aperture Atlas instance

∮ = 1
