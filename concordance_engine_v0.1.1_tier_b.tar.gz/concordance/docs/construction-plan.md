# Construction Plan — Concordance Engine v0.1.0 (Tier B)

This is the project's construction plan. It maps the engine's deliverables to specific files, target sizes, and acceptance criteria. It complements `charter.md` (project goals) and `plan-state.md` (live status).

## Deliverables

| Component | File(s) | Target | Status |
|---|---|---|---|
| Project README | `README.md` | ~800 words | complete |
| Project Charter | `docs/charter.md` | ~600 words | complete |
| Citation Plan | `docs/citation-plan.md` | structured | complete |
| Plan State | `docs/plan-state.md` | live | complete |
| Construction Plan | `docs/construction-plan.md` (this file) | structured | complete |
| Critique Loop runtime | `concordance_engine/critique_loop.py` | ~250 lines | complete |
| Type definitions | `concordance_engine/types.py` | ~150 lines | complete |
| Substrate wrapper | `concordance_engine/substrate.py` | ~100 lines | complete |
| MANUS interface | `concordance_engine/manus.py` | ~100 lines | complete |
| Mock substrate | `concordance_engine/mock_substrate.py` | ~120 lines | complete |
| Demo CLI | `concordance_engine/demo_critique_loop.py` | ~150 lines | complete |
| Critic prompt | `agents/critic.md` | ~800 words | complete |
| Reviser prompt | `agents/reviser.md` | ~600 words | complete |
| Verifier prompt | `agents/verifier.md` | ~600 words | complete |
| Chartering prompt | `agents/chartering.md` | ~600 words | complete |
| Archivist prompt | `agents/archivist.md` | ~600 words | complete |
| Cooperative skill specs | `skills/cooperative/*/SKILL.md` (4) | 200-400 words each | complete |
| Defensive skill specs | `skills/defensive/*/SKILL.md` (4) | 200-400 words each | complete |
| Middleware specs | `middleware/*.md` (5) | structural | complete |
| Aperture Atlas schema | `graph/schema.cypher` | deployable Neo4j 5.x | complete |
| Standing queries | `graph/queries/*.cypher` (3) | Cypher | complete |
| Graph seed | `graph/seed.json` | structured | complete |
| Templates | `templates/*.md` (4) | structural | complete |
| Substrate config | `config/substrates.yaml` | YAML | complete |
| Environment example | `config/.env.example` | reference | complete |
| Sample draft | `examples/sample_draft.md` | demo input | complete |
| Sample session | `examples/sample_critique_session.md` | captured demo output | complete |
| Tests | `tests/test_critique_loop.py` | smoke coverage | complete |
| Requirements | `requirements.txt` | pinned deps | complete |

## Acceptance criteria (Tier B)

The deposit ships when all of the following hold:

1. **Package imports cleanly.** `python -c "import concordance_engine"` succeeds.
2. **Smoke tests pass.** `python tests/test_critique_loop.py` reports 12/12 passing.
3. **Mock demo runs end-to-end.** `python -m concordance_engine.demo_critique_loop --mock` produces a Deposit with `termination_reason="no_further_critique"`.
4. **Live demo runs end-to-end.** With a valid `ANTHROPIC_API_KEY`, `python -m concordance_engine.demo_critique_loop` produces a Deposit with non-empty provenance chain.
5. **All five agent prompts are present** at calibrated register.
6. **All eight skill specs are present** with conformant frontmatter.
7. **Aperture Atlas schema deploys** cleanly to a fresh Neo4j 5.x instance via `cypher-shell -u neo4j -p <pw> < graph/schema.cypher`.
8. **README directory tree matches actual file layout** (no overclaims).
9. **Plan-state is current** (no stale "in progress" markers for completed work).
10. **Zenodo metadata JSON is paste-ready.**

All ten criteria are met as of v0.1.0.

## What is explicitly out of scope for Tier B

These items are deferred to Tier C with no apology:

- Runnable Charter Generator (specification in agents/chartering.md is complete; runtime wrapper deferred)
- Runnable Verifier (agents/verifier.md complete; source-pool retrieval middleware deferred)
- Runnable Basin Hardening Cycle (entire cycle specified; retrieval-layer probing infrastructure deferred)
- Runnable Term Collision Audit and Profile Integrity Guardian (specs complete; live monitoring infrastructure deferred)
- MCP server exposure of the loops as tools
- Live Aperture Atlas Neo4j instance (schema is deployable; instance is not provided)
- Multi-substrate two-source verification (Tier B uses Anthropic only; cross-provider Assembly Chorus deferred)
- Zenodo deposit-creation integration (the Archivist produces metadata bundles; the actual API call remains a separate authorization step)

## Tier C target deliverables

The next implementation tier will add:

- One or more of the deferred runnable operatives (priority TBD)
- Cross-provider substrate selection per role (`config/substrates.yaml` is already structured for it)
- Reference Neo4j Docker compose for the Aperture Atlas
- An MCP server entry point exposing Critique Loop as a tool
- Optional: integration tests against the live Anthropic API (gated behind a `--integration` flag and an explicit API key)

∮ = 1
