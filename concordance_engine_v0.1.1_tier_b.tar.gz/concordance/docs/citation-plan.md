# Citation Plan — Concordance Engine

DOI-anchored predecessors this project must address.

## Required engagements

These deposits must be cited in the engine's metadata, and their structural roles must be acknowledged in the Charter and README.

| DOI | Document | Role in this project |
|---|---|---|
| 10.5281/zenodo.19831619 | Logotic Technique Catalogue | The specification this deposit implements. §IX directly forwards to "the Concordance Engine implementation deposit"; this is that deposit. |
| 10.5281/zenodo.19853157 | Relational Verification for AI Indexing | The Archivist agent emits MPAI-grammar metadata; the proposal extends MPAI into Schema.org / OAI-PMH / JSON-LD. |
| 10.5281/zenodo.19578086 | Metadata Packet for AI Indexing: A Formal Specification | The Archivist's metadata output uses MPAI's seven-component grammar. |
| 10.5281/zenodo.18735468 | Fortress or Room? | Methodology pillar predecessor. The Witness-Teaming Protocol (§XV of Fortress) is the master architecture into which the engine's operatives slot. |
| 10.5281/zenodo.19053469 | The Three Compressions v3.1 | The R1/R2/R3 classification underlies every operative's R3 disposition claim. |
| 10.5281/zenodo.19763365 | EA-HK-01: The Holographic Kernel in Semantic Economy | Compression-survival theory underlying the SIM (semantic-integrity marker) function the Archivist generates. |
| 10.5281/zenodo.19487009 | Meaning Feudalism | Diagnostic source for the engine's "no fourth layer" architectural choice — protocols expose, do not adjudicate. |

## Cite but not engage

These works are part of the citation environment but the engine does not directly extend them:

- W3C DID Core (Layer 1 baseline for the Archivist's metadata output)
- W3C Verifiable Credentials Data Model (companion baseline)
- W3C JSON-LD 1.1 (vocabulary serialization target)
- W3C PROV-O (complementary provenance standard)
- OAI-PMH v2.0 (target for the `oai_mpai` profile, not directly extended here)

## Adapts (with explicit rationale)

| Source | Adaptation |
|---|---|
| github.com/PurpleAILAB/Decepticon (Apache-2.0) | The catalogue extracts coordination patterns from Decepticon's architecture; this engine instantiates those patterns in code. No Decepticon source code is reproduced. The Apache-2.0 license permits this analytical use. |

## Forward references

These works are anticipated but do not yet exist:

- *Concordance Engine Tier C* — the next implementation tier with runnable Charter Generator, Verifier, and Basin Hardening Cycle (deferred pending compute access and retrieval-layer probing infrastructure)
- *MCP Server for the Concordance Engine* — exposure of the loops as MCP tools (deferred)
- *Aperture Atlas Live Instance* — Neo4j-backed graph with live updates (deferred)

∮ = 1
