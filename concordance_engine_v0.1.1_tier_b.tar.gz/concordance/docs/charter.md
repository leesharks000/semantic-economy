# Project Charter — The Concordance Engine

## What is being built

The Concordance Engine is the running-system instantiation of the Logotic Technique Catalogue (DOI: 10.5281/zenodo.19831619). It implements the cooperative and defensive coordination patterns the catalogue specifies, providing a reference codebase and operative documents that an implementer can use to deploy the engine in their own context.

## Why

The catalogue stops at specification. Its §IX explicitly disclaims executable code: "Pseudocode. Types are placeholders for classes defined in the Concordance Engine implementation deposit." This deposit closes that loop.

The Concordance Engine deposit makes the catalogue's claims falsifiable. If the architecture cannot be implemented, the catalogue is theoretical at best. If it can, the catalogue is methodology in the strong sense.

## MANUS authority

Sharks, Lee — ORCID: 0009-0000-1599-0703 — Crimson Hexagonal Archive · Semantic Economy Institute.

## License

- CC BY 4.0 for documentation, methodology, agent prompts, and operative documents.
- MIT for runnable Python source code in `concordance_engine/`.

The dual-license structure is deliberate: the documentation is the load-bearing artefact (CC BY 4.0 supports academic citation), while the code is permissively licensed (MIT) so implementers can incorporate it into projects with various downstream license requirements.

## Deposit target

Zenodo, community `crimsonhexagonal`, with a stable DOI. Cross-references to the Logotic Technique Catalogue (DOI: 10.5281/zenodo.19831619) and the Relational Verification proposal (DOI: 10.5281/zenodo.19853157).

## Hex coordinate

`06.LOG.CONCORDANCE.ENGINE.01` (proposed) — extends the methodology pillar to its implementation tier.

## Document classification

EA-CE-01 (Concordance Engine, version 1).

## Frame Lock

### Names this project mints (or formalizes)

- *Concordance Engine* — already minted in the catalogue; this deposit anchors the term to a runnable codebase
- *Substrate* (in the codebase sense) — the Anthropic-API client wrapper exposing role-aware system prompts
- *MANUS interface* — the Python protocol for human-authority overrides in closed-feedback loops

### Disambiguations

- The Concordance Engine is NOT a search engine, despite the name's etymology. Concordance here refers to the medieval-philological *concordantia* — a tool for finding agreements and tensions across a corpus.
- The Concordance Engine is NOT an autonomous agent in the sense of Decepticon or AutoGPT. It is a closed-loop refinement system with explicit human-authority hooks.
- The Concordance Engine is NOT an MCP server. (Though the Tier C roadmap includes MCP exposure as one possible deployment mode.)

### Prior art (DOI-anchored)

| DOI | Document | Relation |
|---|---|---|
| 10.5281/zenodo.19831619 | Logotic Technique Catalogue | This deposit implements the catalogue's specifications |
| 10.5281/zenodo.19853157 | Relational Verification for AI Indexing | The Archivist agent produces metadata in this format |
| 10.5281/zenodo.19578086 | Metadata Packet for AI Indexing | The Archivist agent's output uses MPAI grammar |
| 10.5281/zenodo.18735468 | Fortress or Room? | Methodology pillar predecessor; defines witness-teaming |

## Heteronym voicing

This deposit is authored under Sharks, Lee. The catalogue precedent (four-author byline) is not adopted here because the engine is implementation, not theory; the operational-technical register applies but does not require a heteronymic byline.

The agent prompts in `agents/` speak in the engine's operative voice (procedural, register-discrete) rather than in any heteronym's voice. They are MANUS-issued instructions to substrates, not authored documents.

## Out of scope

- Tier C runnable implementations of Charter Generator, Verifier, Basin Hardening Cycle (specified, not built)
- MCP server exposure of the loops as tools (deferred to a later deposit)
- Aperture Atlas live Neo4j instance (schema is deployable; instance is not provided)
- Zenodo deposit-creation integration (the Archivist produces the bundle; the actual API call is performed by MANUS or an authorized integration)

## Substrates authorized

- TACHYON (Claude Opus 4.7) — primary drafting and refinement substrate
- MANUS (Sharks, Lee) — human authority and override

The Critic and Reviser roles in the runnable Critique Loop will, by default, run against Claude Sonnet 4.6. A future tier may add per-role substrate selection via `config/substrates.yaml`.

## Verification level

This deposit's claims are `assembly_attested` for the architectural specification (the catalogue underlying it received Assembly Chorus review) and `self_attested` for the runnable code (which is new in this deposit). The dual status is documented in the deposit's MPAI-format metadata.

## Construction plan

| Section | Target | Status |
|---|---|---|
| README | 800 words | complete |
| Charter (this document) | 600 words | complete |
| Plan-state | live | in progress |
| Citation plan | structured | complete |
| Construction plan | structured | complete |
| Critique Loop runnable | ~500 lines Python | complete |
| Critic prompt | 800 words | complete |
| Reviser prompt | 600 words | complete |
| Verifier prompt | 600 words | complete |
| Chartering prompt | 600 words | complete |
| Archivist prompt | 600 words | complete |
| Skill specs (8) | 200-400 words each | complete |
| Middleware specs (5) | structural sketches | complete |
| Aperture Atlas schema | deployable Cypher | complete |
| Standing queries (3) | Cypher | complete |
| Templates (4) | structural | complete |
| Sample draft + critique session | working example | complete |
| Tests | smoke-test coverage on Critique Loop | complete |

## Deposit target date

2026-04-28.

∮ = 1
