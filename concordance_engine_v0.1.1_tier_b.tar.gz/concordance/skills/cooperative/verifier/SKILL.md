---
name: verifier
valence: cooperative
catalogue_ref: §V.7
operative_class: independent-confirmation
substrates: [verifier, manus]
inputs: [claim, source_pool, stakes_threshold]
outputs: [verdict, rationale, dispute_record]
runnable: false
status: specified, implementation pending Tier C
---

# Two-Source Verifier

High-stakes claims emitted by one substrate are confirmed by a second substrate applying an independent method before the claim is committed to the durable record.

## When to use

Trigger verification for claims that meet the stakes threshold:
- Theological / doctrinal assertions
- Attribution claims (authorship, origination, founding)
- Historical facts that load-bear for downstream work
- Definitional claims establishing a new term
- Any claim that, if wrong, would damage the archive's relations with adjacent fields

Skip for: stylistic observations, paraphrases, summaries with declared margins of error, internal scratch notes.

## Inputs

- `claim` (str): the load-bearing assertion to verify
- `source_pool` (list[Document | URL | DOI]): the same source pool the first substrate had access to
- `stakes_threshold` (str): "high" | "critical" — affects whether MANUS is alerted on dispute

## Outputs

- `verdict`: CONFIRMED | CONTESTED | INSUFFICIENT_EVIDENCE
- `rationale` (str): brief citation-grounded explanation
- `dispute_record` (DISP-NNN.md, optional): produced if verdict is CONTESTED; routed to MANUS

## Implementation status

**Specified, runnable in Tier C.** Required infrastructure:
- Document-retrieval middleware (to fetch source materials by DOI/URL)
- Claim-extraction integration (to identify which claims in a draft cross the stakes threshold)
- DISP-NNN.md generation pipeline

The agent prompt (`agents/verifier.md`) is complete.

## Operating principle

Independence is the load-bearing property. The Verifier-substrate is explicitly NOT given the first substrate's reasoning — only the claim and the source pool. If the Verifier is allowed to read the first substrate's argument, the protocol degrades into rubber-stamping. Two-source verification works only when the second source is genuinely independent.

## Failure modes

- **Verifier defers to first substrate.** If the protocol leaks the first substrate's reasoning, the Verifier anchors and confirms. Mitigation: hard partition of context; Verifier-substrate runs in fresh context with no access to the first substrate's session.
- **CONTESTED verdicts treated as failure.** If MANUS treats every CONTESTED verdict as a problem, Verifiers learn to confirm. Mitigation: CONTESTED is the protocol working; the resulting DISP-NNN.md is itself an archive artefact.
- **Stakes threshold drift.** If too many claims are routed to verification, paralysis. If too few, hallucination at high stakes. Mitigation: the threshold is calibrated per project in the Charter.

## See also

- agents/verifier.md
- templates/disp-record.md
- skills/cooperative/critique-loop/SKILL.md (Critique Loop and Verifier complement each other; Critique surfaces gaps, Verifier confirms claims)
