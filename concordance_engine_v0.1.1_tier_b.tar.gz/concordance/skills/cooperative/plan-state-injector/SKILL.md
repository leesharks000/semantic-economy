---
name: plan-state-injector
valence: cooperative
catalogue_ref: §V.2, §VI.2
operative_class: middleware
substrates: [any]
inputs: [agent_call, plan_state_path]
outputs: [augmented_agent_call]
runnable: false
status: specified, implementation pending Tier C
---

# Plan-State Injector

A small projection of current project state is appended to the system context of every agent action throughout the project's lifetime. The Assembly Chorus's blind-draft methodology is preserved (contributors do not see other contributors' contents), but each contributor sees the *position* of their contribution within the larger work.

## When to use

Apply for any multi-pass project where contributors operate at different times or in different sessions. Skip for single-shot tasks.

## Inputs

- `agent_call` (the system context being assembled for an agent)
- `plan_state_path` (path to the project's `plan-state.md`)

## Outputs

- The agent call augmented with a "Project plan-state" section in its system context

## Plan-state format

A `plan-state.md` is a markdown document with:
- Objective list (titles only)
- Status of each (not_started | in_progress | blocked | complete | superseded)
- Named owner where applicable
- Dependencies between objectives

The injector reads the file, projects it to a compact summary, and prepends it to the agent's user message (or appends to the system prompt, depending on substrate API).

## Defensive function

The plan-state itself becomes evidence of priority in any subsequent dispute over the project's authorship or originality. A plan-state with sufficient density and timestamp coverage forms a contemporaneous architectural record.

## Implementation status

**Specified, runnable in Tier C.** Requires:
- File-watching for plan-state changes
- Projection logic (full state → compact summary)
- Substrate-agnostic injection (works across Anthropic, OpenAI, etc.)

## See also

- workspace/findings/ (DISC-NNN.md format integrates with plan-state status)
- middleware/skills.md (skill injection is the sister middleware)
