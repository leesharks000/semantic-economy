---
name: charter-generator
valence: cooperative
catalogue_ref: §V.1, §VI.1
operative_class: project-preamble
substrates: [chartering, manus]
inputs: [project_brief, manus_orcid]
outputs: [charter, scope, citation_plan, construction_plan, frame_lock]
runnable: false
status: specified, implementation pending Tier C
---

# Charter Generator

Before any new deposit project begins, the Charter Generator interviews MANUS and produces the four governance artefacts that bind every subsequent agent action.

## When to use

Apply the Charter Generator at the start of any deposit project that meets at least one of:
- Multi-section deposit (>5K words)
- Multi-substrate Assembly Chorus involvement
- Mints new terminology (creates Frame Lock requirement)
- High-stakes attribution claims (operates in a defensive register)

Skip for: short responses, single-paragraph notes, internal scratch documents.

## Inputs

- `project_brief` (str | dict): MANUS's initial framing, may be a paragraph or a structured pre-supplied brief
- `manus_orcid` (str): ORCID of the project's authorial authority

## Outputs

Four artefacts, deposited together as a project preamble (with optional own DOI):

1. **Charter.md** — what is being built and why; MANUS authority; license; deposit target
2. **Scope.md** — in/out of scope; heteronym voicing; excluded materials
3. **CitationPlan.md** — DOI-anchored predecessors; adjacent works; cite-but-not-engage list
4. **ConstructionPlan.md** — sections, target word counts, target deposit date

For defensive deposits, the Charter additionally contains a **FrameLock** section listing minted terms, disambiguations, and prior-art DOI list.

## Implementation status

**Specified, runnable in Tier C.** This skill requires:
- Interactive interview interface (CLI, web, or chat-substrate)
- Zenodo deposit-creation integration (for the project preamble's own DOI)
- Optional: MANUS authorization confirmation step

The agent prompt (`agents/chartering.md`) is complete. The runnable Python wrapper is staged for the next implementation tier.

## Failure modes

- **Premature chartering.** If MANUS has not yet decided what the project is, chartering produces a vague charter that fails to bind. Mitigation: a separate scoping conversation precedes chartering for projects whose direction is unclear.
- **Boilerplate charter.** A Chartering Agent that recycles templates produces a charter that does not bind. Mitigation: each interview asks project-specific questions; templates are structural, not content.
- **Missing Frame Lock.** A defensive-register project chartered without a Frame Lock cannot anchor its minted terms. Mitigation: defensive register is detected during interview; Frame Lock is required for affirmative-response projects.

## See also

- agents/chartering.md
- templates/zenodo-deposit.md
- skills/cooperative/critique-loop/SKILL.md (typically follows chartering)
