---
name: critique-loop
valence: cooperative
catalogue_ref: §V.12
operative_class: closed-feedback
substrates: [critic, reviser, manus]
inputs: [draft]
outputs: [deposit, provenance_chain]
runnable: true
---

# Critique Loop

The cooperative inversion of the Decepticon Offensive Vaccine. Same closed-feedback shape; opposite termination condition; opposite output.

## When to use

Apply the Critique Loop when:
- A draft is approaching deposit-ready state but you want to surface gaps before publication
- A draft makes load-bearing claims that should be tested against sincere objection
- The deposit's value depends on demonstrably engaging counterargument

Do NOT apply the Critique Loop when:
- The draft is in early development and a full critique would be premature
- The draft is short enough that direct review is more efficient
- The author has not yet consolidated their own argument (the Critique Loop sharpens, it does not invent)

## Inputs

- `initial_draft` (str): the draft text to refine
- `max_iterations` (int, default 5): hard upper bound; production deposits typically converge in 2-4 iterations

## Outputs

- `Deposit` object containing:
  - Final manuscript
  - Full provenance chain (every critique, every revision, every termination decision)
  - Termination reason (no_further_critique | manus_override | max_iterations_reached)
  - Residual dissent (if MANUS overrode with logged disagreement)

## Termination conditions

The loop terminates when:
1. The Critic returns a null critique ("no further sincere objection") — preferred termination
2. MANUS overrides and accepts a residual disagreement (logged as part of provenance)
3. max_iterations is reached (rare; usually indicates a Critic that is not terminating cleanly)

## Acceptance criteria

A successfully completed Critique Loop produces:
- A manuscript that has addressed every objection raised at any iteration
- A provenance chain that a third reader can audit
- A termination decision that is honest about whether the Critic found nothing more, MANUS overrode, or the loop ran out of iterations

## Failure modes

- **Critic refuses to terminate.** Pads with manufactured objections. Mitigation: review the Critic prompt's termination instruction; the phrase "no further sincere objection" must be the explicit termination signal.
- **Reviser over-revises.** Generalizes from specific objections to global rewrites. Mitigation: the Reviser prompt explicitly forbids reorganizing or changing voice.
- **Loop converges on a local optimum.** The draft addresses every objection but the deposit's underlying frame is wrong. Mitigation: Critique Loop is not a substitute for chartering. If the frame is wrong, the Charter (§V.1) should have caught it; rerun chartering rather than continuing to iterate.

## Cost

- ~$1.50–2.50 per draft section per Critique Loop session at current Claude Sonnet rates
- ~$15–40 per full deposit depending on length and contention

## Related operatives

- **Verifier (§V.7)** — apply two-source verification to high-stakes claims that survive the Critique Loop
- **Charter (§V.1)** — the Critique Loop assumes the Charter has bound the project; do not run the loop on a draft whose project has not been chartered
- **Basin Hardening Cycle (§VI.12)** — the defensive sister pattern; same shape, opposite valence

## See also

- agents/critic.md
- agents/reviser.md
- concordance_engine/critique_loop.py
- examples/sample_critique_session.md
