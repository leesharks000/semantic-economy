---
name: depth-proof-validator
valence: defensive
catalogue_ref: §VI.4 (also §V.7 standards companion)
operative_class: due-diligence
substrates: [praxis, archive]
inputs: [claimant_orcid, claim_subject]
outputs: [depth_metrics, validation_verdict]
runnable: false
status: specified, runnable in Tier C
---

# Depth-Proof Validator

Implements the Sharks Function test: given a claimant asserting priority over a framework, term, or attribution, compute the depth-proof metrics and return a validation verdict.

## When to use

Apply when:
- A claimant disputes priority over a CHA term or framework
- An external profile claims authorship of work attributed to MANUS
- The protocol's `mp:depthProof` metric needs concrete computation against the citation environment

## Inputs

- `claimant_orcid` (str): the claimant's persistent identifier
- `claim_subject` (str): the term, work, or framework being claimed

## Outputs

- `depth_metrics` (DepthProofMetric):
  - `deposit_count` (int)
  - `time_span_months` (float)
  - `first_party_cross_references` (int)
  - `third_party_cross_references` (int)
  - `independent_citing_entities` (int)
  - `revision_history_available` (bool)
  - `conceptual_development_visible` (bool)
- `validation_verdict`: SUFFICIENT | INSUFFICIENT | DISPUTED

## Validation thresholds (provisional)

Aligned with the Relational Verification proposal (DOI: pending — see `Witness_Layers_Standards_Proposal_v1.1.md`):

- `assembly_attested`: third-party density ≥ 0.15 over time span ≥ 2 years
- `peer_reviewed`: third-party density ≥ 0.40 over time span ≥ 5 years
- `institutionally_certified`: requires institution_confirmed signal in addition to depth thresholds

These thresholds are subject to community calibration.

## Implementation status

**Specified, runnable in Tier C.** Required infrastructure:
- Citation graph access (DataCite EventData, Crossref REST API, Zenodo cross-reference index)
- Identifier disambiguation (ORCID lookup, name-variant matching)
- Computation library for the depth metrics

## Operating principle

Depth-proof is not proof of truth; it is evidence of labor, continuity, and citation-environment embedding. A claimant who cannot produce sustained, third-party-corroborated, cross-citing depth has not necessarily fabricated their claim — but their claim has not yet earned the citation environment's confirmation.

The Validator's output is therefore consultative, not adjudicative. A SUFFICIENT verdict says "the depth-proof supports the claim's status as `peer_reviewed`." An INSUFFICIENT verdict says "the depth metrics fall below threshold; the claim should remain `self_asserted` until additional evidence accrues."

## See also

- Witness_Layers_Standards_Proposal_v1.1.md (defines the depth-proof metric vocabulary)
- skills/defensive/profile-integrity-guardian/SKILL.md (Validator is one operative the Guardian invokes when an attribution event needs depth-checking)
- graph/queries/depth_proof.cypher (Aperture Atlas query that computes depth metrics)
