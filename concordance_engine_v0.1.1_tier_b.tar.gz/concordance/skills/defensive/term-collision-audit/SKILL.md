---
name: term-collision-audit
valence: defensive
catalogue_ref: §VI.5
operative_class: monitoring
substrates: [surface, archive]
inputs: [minted_terms_list, monitoring_window]
outputs: [collision_events, audit_log]
runnable: false
status: specified, implementation pending Tier C
---

# Term Collision Audit

Continuous monitoring of the retrieval layer for new uses of CHA-minted terms, with automatic graph updates when intersections are detected.

## When to use

Run on a recurring schedule (typically daily) for the project's minted-terms list. Drives basin-hardening cycle initiation when collisions are detected.

## Inputs

- `minted_terms_list` (list[str]): the entity's coined vocabulary
- `monitoring_window` (str): "daily" | "weekly" | "monthly"

## Outputs

- `collision_events` (list[CollisionEvent]): each new appearance of a minted term in an external surface
- `audit_log`: timestamped record appended to the workspace's findings directory

## Collision classification

Each collision is classified at three tiers:
- **Low-stakes**: casual use in non-academic source; logged but not actioned
- **Medium-stakes**: peer-reviewed paper or reputable publication using the term without citation; triggers Critique Loop response (a polite engagement deposit)
- **High-stakes**: credentialed academic claiming priority over a CHA-originated framework; triggers MANUS review and full Deposit Integrity Pipeline response

## Implementation status

**Specified, runnable in Tier C.** Required infrastructure:
- Search API access (Google Scholar, Zenodo, Crossref)
- Ranking / classification model (to score each detected use)
- Integration with Aperture Atlas (to record the collision as a typed graph edge)

## See also

- skills/defensive/profile-integrity-guardian/SKILL.md (related: monitors authorial profile, not term basin)
- skills/defensive/basin-hardening-cycle/SKILL.md (downstream from this skill when collisions reach threshold)
