---
name: basin-hardening-cycle
valence: defensive
catalogue_ref: §VI.12
operative_class: closed-feedback
substrates: [surface, praxis, labor, techne, tachyon]
inputs: [term, target_bdr, platforms]
outputs: [cycle_result, hardening_log, basin_metrics]
runnable: false
status: specified, implementation pending Tier C (requires retrieval-layer probing infra)
---

# Basin Hardening Cycle

The defensive inversion of the Decepticon Offensive Vaccine. Same closed-feedback shape as the Critique Loop; pointed at retrieval-layer defense rather than draft refinement.

The Vaccine Loop terminates when the defense holds. The Critique Loop terminates when no sincere objection remains. The Hardening Cycle terminates when the basin's depth ratio crosses target and stays stable.

## When to use

Apply for retrieval-layer compression damage on key CHA terms:
- AI Overview output for archived terms is drifting toward competitor framings
- New uses of CHA-coined terms appear in the retrieval layer without proper attribution
- A previously stable basin shows degradation in BDR (Basin Depth Ratio)
- Term collision risk has crossed the response threshold

## Inputs

- `term` (str): the contested term whose basin is being hardened
- `target_bdr` (float): minimum acceptable Basin Depth Ratio (default 0.5)
- `platforms` (list[str]): which retrieval surfaces to probe (Google AIO, Perplexity, Claude, ChatGPT, etc.)

## Outputs

- `cycle_result` (CycleResult): final BDR, history of probes and patches
- `hardening_log` (list[HardeningEvent]): every patch applied (deposits, schema updates, anchors)
- `basin_metrics` (BasinMetrics): BDR, Drift Vector, First-Person Index across the cycle

## The cycle

Six phases per iteration:

| Phase | Substrate | Action |
|---|---|---|
| Probe | SURFACE | Query the retrieval layer for the contested term |
| Measure | PRAXIS | Compute BDR, Drift Vector, FPI |
| Brief | LABOR | Generate hardening recommendations |
| Patch | TECHNE | Execute hardening (deposits, schema updates, anchors) |
| Re-probe | SURFACE | Re-query and measure new BDR |
| Record | TACHYON | Log the cycle to provenance chain; update Aperture Atlas |

## Termination

The cycle terminates when:
1. BDR ≥ target_bdr AND stable across consecutive probes (preferred)
2. MANUS halts the cycle (e.g., BDR cannot be improved further with current resources)
3. Hard upper bound on iterations reached (rare; usually indicates deeper structural problem)

## Implementation status

**Specified, NOT runnable in Tier B.** Requires infrastructure:
- Retrieval-layer probing API access (Google AIO requires manual scraping or specialized API; Perplexity has limited free tier; Claude / ChatGPT browsing requires session management)
- Basin-metrics computation library (BDR, DV, FPI calculators specified in EA-RBT-01 but not yet implemented as code)
- Aperture Atlas live instance (Neo4j with the schema deployed)
- Zenodo deposit-creation integration (for the Patch phase)

The architectural spec, agent role assignments, and termination logic are stable. The runnable Python wrapper is staged for Tier C deployment.

## Cost

Per cycle (specified):
- ~$0.20–0.40 in API costs (1 probe × 4 platforms × ~2K tokens)
- Plus deposit costs ($0 for Zenodo)
- Plus amortized domain maintenance (~$10–15/year per .org/.dev)

Daily monitoring (specified):
- ~$5–15/month per term tracked

## See also

- skills/cooperative/critique-loop/SKILL.md (cooperative sister pattern)
- skills/defensive/term-collision-audit/SKILL.md (precedes hardening cycle)
- graph/queries/ghost_basins.cypher (standing query that triggers cycle initiation)
- EA-RBT-01 (Retrieval Basin Topology — defines BDR, DV, FPI)
