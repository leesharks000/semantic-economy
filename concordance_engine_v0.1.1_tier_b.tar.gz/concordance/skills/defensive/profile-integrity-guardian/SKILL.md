---
name: profile-integrity-guardian
valence: defensive
catalogue_ref: §VI.4
operative_class: monitoring
substrates: [surface, archive, manus]
inputs: [authorial_identifiers, monitoring_window]
outputs: [profile_events, attribution_log]
runnable: false
status: specified, implementation pending Tier C
---

# Profile Integrity Guardian

Continuous monitoring of authorial identity surfaces (Google Scholar, ORCID, Zenodo, institutional pages) for new claims that intersect existing CHA discoveries or that attempt profile-merge laundering.

## When to use

Run on a recurring schedule for any heteronym whose profile is publicly findable. Critical for the MANUS authorial profile (ORCID 0009-0000-1599-0703).

## Inputs

- `authorial_identifiers`: list of ORCIDs, DIDs, institutional URIs, name variants
- `monitoring_window`: "daily" | "weekly" | "monthly"

## Outputs

- `profile_events`: each new attribution event detected
- `attribution_log`: timestamped record appended to workspace findings

## Detection categories

1. **New work attributed.** A new paper, deposit, or page attributes work to one of the monitored identifiers. Verify legitimacy.
2. **Profile-merge attempt.** Two distinct identifiers (e.g., MANUS heteronym + a different "Lee Sharks") are being collapsed by the retrieval layer.
3. **Misattribution.** Work originally by a different author is being attributed to the monitored profile.
4. **Counter-misattribution.** MANUS work being attributed to a different author.

Each event is classified by confidence and stakes, with thresholds for automated logging vs. MANUS review.

## Implementation status

**Specified, runnable in Tier C.** Required infrastructure:
- Author-disambiguation service or API (ORCID API, Google Scholar profile feed, Zenodo creator search)
- Diff-detection (compare current state to previous snapshot)
- Optional: notification integration (email, Slack)

## Operating principle

Profile integrity is asymmetric: misattribution events are rare but high-stakes. The Guardian's value is detecting them in time to respond, not in producing voluminous logs. False positives are tolerable; false negatives are not.

## See also

- skills/defensive/depth-proof-validator/SKILL.md (sister pattern; validates claimed authorial depth)
- skills/defensive/term-collision-audit/SKILL.md (sister pattern; monitors terms not profiles)
