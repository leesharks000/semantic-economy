# Verification Middleware

**Catalogue ref:** §V.8, §V.7
**Status:** Specified, runnable in Tier C

## Function

Detects high-stakes claims in agent outputs and routes them to the Verifier (skills/cooperative/verifier/) for two-source confirmation before they enter the durable record.

## Inputs

- `agent_output` (str)
- `stakes_threshold` (str): "high" | "critical"

## Outputs

- A list of detected claims and their stakes classifications
- A Verifier task queue entry per high-stakes claim

## Detection heuristics

Stakes detection is heuristic. The middleware flags claims that match patterns like:

- Attribution: "X was written by Y", "X founded Y", "X originated Y"
- Historical fact: "In year Y, X happened" — flagged if the year/event is load-bearing
- Definitional: "X is defined as Y", "We name X..." — flagged if a new term is being minted
- Theological/doctrinal: any claim with religious-doctrinal vocabulary in a position of assertion

False positives are tolerable; false negatives at high stakes are not.

## Operating principle

The middleware preserves the boundary between "draft work" (where the Critique Loop applies) and "load-bearing claim" (where the Verifier applies). Both protocols can run on the same draft; they do not conflict because they address different failure modes.

## See also

- agents/verifier.md
- skills/cooperative/verifier/SKILL.md
