# Skills Middleware

**Catalogue ref:** §V.8 (cooperative), §V.9 (skill injection)
**Status:** Specified, runnable in Tier C

## Function

Loads relevant skill documents from `skills/` into an agent's context based on the agent's role and the current task. Implements the on-demand-frontmatter pattern: only frontmatter is loaded by default; full content is loaded when the agent determines a specific skill is needed.

## Inputs

- `agent_role` (str): the substrate's declared role (critic, reviser, verifier, etc.)
- `task_context` (dict): the current task's metadata (operative class, valence, stakes)

## Outputs

- A list of relevant skill frontmatter blocks injected into the agent's system context

## Algorithm

1. Read all `skills/**/SKILL.md` frontmatter blocks at startup.
2. For each agent call:
   a. Filter skills where `valence` matches the operative's valence (cooperative or defensive)
   b. Filter skills where `substrates` includes the agent's role
   c. Rank by relevance to the task_context
   d. Inject top-N frontmatter blocks (default N=5)
3. When the agent invokes a specific skill (via tool call or explicit reference), load the full SKILL.md body.

## Implementation status

Tier B: skills directory populated and frontmatter-conformant. Tier C: runnable middleware that performs the injection.

## See also

- skills/ (the operative library this middleware indexes)
- agents/ (the system prompts that consume injected skills)
