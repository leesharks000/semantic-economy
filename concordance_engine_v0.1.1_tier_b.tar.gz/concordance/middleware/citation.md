# Citation Middleware

**Catalogue ref:** §V.8
**Status:** Specified, runnable in Tier C

## Function

Auto-injects DOI metadata when a deposit is referenced in any agent call. When an agent's draft cites `10.5281/zenodo.NNNNNNNN`, the middleware fetches the title, creators, and publication date from the Zenodo API and either prepends them as context or formats them as a structured citation.

## Inputs

- `agent_call_text` (str): the user message or draft content being processed
- `cite_format` (str): "inline" | "structured" | "footnote"

## Outputs

- Augmented agent_call_text with citation metadata resolved
- Or, structured citation block appended to the message

## Algorithm

1. Parse the input for DOI patterns: `10.5281/zenodo.\d+`, `https://doi.org/...`, `doi:...`
2. For each unique DOI:
   a. Check local cache (default 24h TTL)
   b. If not cached, GET `https://zenodo.org/api/records/{id}`
   c. Extract title, creators, publication_date
3. Format per `cite_format`:
   - `inline`: `[Title (Authors, Year)](https://doi.org/...)`
   - `structured`: prepend a `## Cited deposits` block
   - `footnote`: append `[^DOI]:` footnotes

## Implementation status

Tier B: specified. Tier C: runnable middleware.

## Operating principle

Eliminates the failure mode where an agent hallucinates a deposit's title or author. If the DOI resolves, the canonical metadata is used; if it does not resolve, the agent is alerted and the citation is flagged as unverified.
