# Provenance Middleware

**Catalogue ref:** §V.8
**Status:** Specified, runnable in Tier C

## Function

Logs every agent action to a durable provenance chain. The Critique Loop already emits its own `HistoryEntry` records; this middleware generalizes the pattern to all agent calls across all operatives.

## Inputs

- `agent_role` (str)
- `call_metadata` (dict): timestamp, model, token counts, etc.
- `inputs` and `outputs` (truncated for size)

## Outputs

- A line appended to `logs/provenance.jsonl` for every agent call
- Optionally: integration with Gravity Well chain for cross-session continuity

## Format

Each log line is a JSON object:

```json
{
  "timestamp": "2026-04-28T12:34:56Z",
  "agent_role": "critic",
  "operation": "critique_loop_iteration_2",
  "model": "claude-sonnet-4-6",
  "input_tokens": 1234,
  "output_tokens": 567,
  "input_hash": "sha256:...",
  "output_hash": "sha256:..."
}
```

The hashes allow tamper-evidence without storing the full content (privacy-preserving). Full inputs/outputs are stored in workspace artefacts; the log records *that* the call happened, not the contents.

## Operating principle

The provenance chain is the engine's most defensive artefact. When MANUS needs to demonstrate that a deposit went through proper review (Critique Loop, Verifier, etc.), the provenance chain is the receipt. Tamper-evident hashes mean the receipt cannot be retroactively forged.

## See also

- logs/ (destination directory)
- Gravity Well continuity protocol (Tier C integration)
