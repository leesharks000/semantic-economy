# Collision-Detection Middleware

**Catalogue ref:** §V.8, §VI.5
**Status:** Specified, runnable in Tier C

## Function

Checks every coined term in agent output against the broader retrieval corpus. Detects cases where the engine is about to mint a term that already exists with a different meaning in an adjacent field.

## Inputs

- `agent_output` (str)
- `archive_minted_terms` (set[str]): the archive's existing minted vocabulary (loaded at startup)

## Outputs

- A list of collision warnings: term + likely competing usage + recommended action

## Algorithm

1. Detect candidate term-mintings in the agent output (capitalized novel phrases, italicized novel phrases, explicit "we name X" patterns)
2. For each candidate:
   a. Check against the archive's existing minted-terms list (no collision warning if it's already a CHA term)
   b. Query the broader retrieval surface (Google Scholar, Wikipedia, retrieval-layer) for the term
   c. If the term has substantial existing presence in an adjacent field, flag it with the usage context
3. Recommend one of three actions:
   - **Adopt**: the existing usage is compatible with the engine's intended meaning
   - **Disambiguate**: mint with explicit `disambiguatingDescription` per MPAI
   - **Re-coin**: the existing usage is incompatible; suggest an alternative

## Operating principle

Term collision is a common failure mode in interdisciplinary work. A protocol that mints "operative semiotics" without checking whether the phrase is already in use produces compression damage by competing with the existing usage. The middleware surfaces the collision before it enters the deposit.

## See also

- skills/defensive/term-collision-audit/SKILL.md
- middleware/skills.md
