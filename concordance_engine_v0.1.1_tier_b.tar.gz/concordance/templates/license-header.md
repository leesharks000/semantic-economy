# License Header Template

For documentation, methodology, and operative documents (CC BY 4.0):

```markdown
**License:** CC BY 4.0 — <https://creativecommons.org/licenses/by/4.0/>
**Author:** Sharks, Lee — ORCID: 0009-0000-1599-0703 — Crimson Hexagonal Archive
```

For Python source code (MIT):

```python
# Copyright (c) 2026 Lee Sharks — Crimson Hexagonal Archive
# Licensed under the MIT License. See LICENSE-MIT for the full text.
```

## Note on the dual-license structure

The Concordance Engine deposit uses CC BY 4.0 for documentation and MIT for runnable code. This is deliberate:

- **CC BY 4.0** for documentation supports academic citation and is consistent with the rest of the CHA archive's licensing.
- **MIT** for code allows implementers to incorporate the Concordance Engine into projects with various downstream license requirements without forcing those projects to adopt CC BY.

When porting concordance code to a new project, retain the MIT copyright notice. When citing the methodology or operative documents, attribute under CC BY 4.0.
