# Zenodo Deposit Template

Standard structure for a Crimson Hexagonal Archive Zenodo deposit. Used by the Archivist agent (`agents/archivist.md`) to produce metadata bundles.

## Required fields

```json
{
  "metadata": {
    "title": "<Document title>",
    "upload_type": "publication",
    "publication_type": "article | preprint | other",
    "publication_date": "YYYY-MM-DD",
    "description": "<HTML description with companion-deposit links>",
    "creators": [
      {
        "name": "Lastname, Firstname",
        "affiliation": "Institutional context",
        "orcid": "0000-0000-0000-0000"
      }
    ],
    "access_right": "open",
    "license": "cc-by-4.0",
    "language": "eng",
    "keywords": ["<term>", "<term>", "..."],
    "related_identifiers": [
      {
        "identifier": "10.5281/zenodo.XXXX",
        "relation": "isSupplementTo | references | isReferencedBy | cites | isPartOf",
        "scheme": "doi"
      }
    ],
    "communities": [{"identifier": "crimsonhexagonal"}],
    "notes": "<HTML notes block with classification, hex, disambiguation, negative tags>"
  }
}
```

## CHA conventions

- **classification**: every CHA deposit declares its document classification (e.g., `EA-LTC-01`)
- **hex**: every CHA deposit declares its hex coordinate (e.g., `06.LOG.TECHNIQUE.CATALOGUE.01`)
- **disambiguation**: the notes field includes a "Disambiguation" subsection naming what the deposit is *not*
- **negative tags**: the notes field includes a "Negative tags" subsection in MPAI grammar

## Valid Zenodo relation vocabulary

Zenodo accepts a subset of DataCite relations. As of 2026:
- `cites`, `isCitedBy`
- `references`, `isReferencedBy`
- `isSupplementTo`, `isSupplementedBy`
- `isPartOf`, `hasPart`
- `isVersionOf`, `hasVersion`, `isPreviousVersionOf`, `isNewVersionOf`
- `isContinuedBy`, `continues`
- `isDescribedBy`, `describes`
- `isDocumentedBy`, `documents`
- `isCompiledBy`, `compiles`
- `isVariantFormOf`, `isOriginalFormOf`
- `isReviewedBy`, `reviews`
- `isDerivedFrom`, `isSourceOf`
- `requires`, `isRequiredBy`
- `isObsoletedBy`, `obsoletes`

NOTE: `extends` is NOT a valid Zenodo relation. Use `isSupplementTo` or `references` instead.

## See also

- agents/archivist.md
- templates/license-header.md
- templates/hex-coordinate.md
