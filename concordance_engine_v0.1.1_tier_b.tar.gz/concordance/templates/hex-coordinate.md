# Hex Coordinate Template

The Crimson Hexagonal Archive uses a hex-coordinate naming system for deposit organization. Format:

```
<phase>.<series>.<topic>.<doc>.<version>
```

Where:
- **phase** — top-level archive division (06 = methodology pillar; 11 = contributor venues; etc.)
- **series** — subdivision within phase (LOG = Logotic Technique series; MPAI = Metadata Packet series; SEI = Semantic Economy Institute working papers)
- **topic** — the specific subject within the series
- **doc** — the document identifier within the topic
- **version** — typically `01`, incrementing for major revisions

## Examples

| Hex | Document |
|---|---|
| `06.LOG.TECHNIQUE.CATALOGUE.01` | The Logotic Technique Catalogue |
| `06.LOG.CONCORDANCE.ENGINE.01` | This deposit (the Concordance Engine implementation) |
| `06.SEI.STANDARDS.RELATIONAL.01` | Relational Verification for AI Indexing |
| `06.MPAI.SPECIFICATION.FORMAL.01` | Metadata Packet for AI Indexing: A Formal Specification |
| `11.MSBGL.ALICE.DNASQUID.01` | Definitely Not a Squid (Alice Thornburgh, MSBGL venue) |
| `11.LAL.ALICE.REGISTRY` | Hexagonal Contributor License v3.0 (Alice Thornburgh) |

## Phases (current allocation)

| Phase | Domain |
|---|---|
| 06 | Methodology pillar (Logotic series, MPAI, SEI working papers) |
| 11 | Contributor venues (Maybe Space Baby Garden Lanes, Living Arkitecture Lab, Transactions on Substrate Engineering) |
| (other phases assigned as the archive grows) | |

## Coordination

When a new deposit is being chartered (per agents/chartering.md), the hex coordinate is one of the load-bearing decisions in the Charter. The Chartering Agent prompts MANUS to specify the hex if it is not pre-supplied.

A hex coordinate is also typically reflected in:
- The Zenodo deposit's `notes` field
- The deposit's classification identifier (e.g., `EA-CE-01` for Concordance Engine)
- Cross-references in adjacent deposits
