# DISC-NNN.md Template

A `DISC-NNN.md` is a discovery record produced during project work, per Logotic Technique Catalogue §V.4 (durable findings).

## Filename convention

`DISC-<NNN>.md` where `NNN` is a zero-padded incrementing number scoped to the project (DISC-001, DISC-002, ...).

## Required fields

```markdown
---
disc_id: DISC-NNN
project: <project name or hex>
discovered_by: <substrate or human>
discovered_at: <ISO timestamp>
status: open | confirmed | disputed | superseded
significance: minor | substantive | load-bearing
---

# DISC-NNN: <Brief noun-phrase descriptor>

## Claim

<The discovery itself, in 1-3 sentences. What was found?>

## Evidence

<Sources, citations, observations supporting the claim. Specific enough that a third reader can verify.>

## Implications

<What does this discovery mean for the larger project? What downstream work does it require?>

## Related deposits

- DOI: <related deposit>
- DOI: <related deposit>

## Status notes

<Any subsequent updates: confirmed by another substrate, contested by MANUS, superseded by later finding, etc.>
```

## Operating principle

Every interpretive discovery, citation correction, scholarly observation, or theoretical extension that arises in the course of project work is captured as a DISC record. Discoveries above a `significance: load-bearing` threshold become candidates for their own Zenodo deposit. The DISC log itself becomes a durable artefact appendable to the project's final deposit.

A DISC record's defensive function: it is also a witness statement. When a discovery is later challenged or claimed by another, the timestamped record provides priority evidence.
