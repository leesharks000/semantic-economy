# Sample Critique Session

This file shows the live terminal output of a Critique Loop run against `examples/sample_draft.md`.

It is included in the deposit so an implementer can see what the loop actually produces without needing to set up Anthropic API access first. The session below is illustrative of the loop's behavior — actual runs will produce different specific objections and revisions, but the structure (iteration, critique, revision, termination) is stable.

```
$ python -m concordance_engine.demo_critique_loop

══════════════════════════════════════════════════════════════════════
  CONCORDANCE ENGINE — CRITIQUE LOOP DEMO
══════════════════════════════════════════════════════════════════════
Input: examples/sample_draft.md
Length: 2156 chars

Critic: Substrate(role='critic', model='claude-sonnet-4-6')
Reviser: Substrate(role='reviser', model='claude-sonnet-4-6')
MANUS: SilentManus (non-interactive)

Max iterations: 5


══════════════════════════════════════════════════════════════════════
  ITERATION 1
══════════════════════════════════════════════════════════════════════

Critique severity: substantive
Objections found: 3

  1. The substrate-neutrality claim treats coordination shapes as
     transferable across domains, but does not address the embedded
     costs of transfer. A Verifier pattern calibrated for offensive-
     security stakes...

  2. The "technique is shape; paradigm is preposition" formulation
     is rhetorically powerful but elides the question of where
     prepositions come from. The draft assumes prepositions are
     freely chosen by operators, but in many cases the labeling
     regime imposes them...

  3. The closing argument that the engine "does not have to choose
     between the two valences" is structurally optimistic. In
     practice, an engine that hosts both cooperative and defensive
     operatives faces governance challenges — who decides which
     valence applies in ambiguous cases?

══════════════════════════════════════════════════════════════════════
  ITERATION 2
══════════════════════════════════════════════════════════════════════

Critique severity: minor
Objections found: 1

  1. The new paragraph on transfer costs is well-placed but introduces
     "substrate-calibration overhead" without defining it. The term
     deserves either a brief gloss or removal.

══════════════════════════════════════════════════════════════════════
  ITERATION 3
══════════════════════════════════════════════════════════════════════

Critique severity: minor
Objections found: 0
Critique: NULL — no further sincere objection.
Loop will terminate after this iteration.

══════════════════════════════════════════════════════════════════════
  LOOP TERMINATED
══════════════════════════════════════════════════════════════════════
Termination reason: no_further_critique
Total iterations: 3
Final manuscript length: 2891 chars

Deposit written: workspace/deposits/critique_session_20260428-130456.json
Revised draft written: workspace/drafts/revised_20260428-130456.md

∮ = 1
```

## Interpreting the trail

The session shows three iterations, each producing a different severity:
- **Iteration 1** (substantive): three load-bearing objections requiring substantive revision
- **Iteration 2** (minor): one minor objection requiring small clarification
- **Iteration 3** (null): the Critic finds no further sincere objection; loop terminates cleanly

The deposit JSON at `workspace/deposits/critique_session_*.json` contains the full provenance chain — every Critic response, every revision, every iteration's metadata. This is what makes the deposit R3: the cost of the critique is borne and visible; the work shows its work.

A typical full-deposit cycle costs ~$1.50–2.50 in API costs at current Claude Sonnet rates, depending on draft length and contention.

## What a non-terminating session looks like

If the Critic refuses to terminate (a known failure mode addressed in `agents/critic.md`), the loop runs to `max_iterations` and the deposit's termination reason is `max_iterations_reached`. This is not necessarily a failure — sometimes a draft genuinely needs more iterations than the default cap. But it is a signal to inspect:
- Is the Critic prompt's termination instruction being followed?
- Is the draft itself in a state where convergence is achievable?
- Should MANUS be running with `InteractiveManus` to take override decisions?
