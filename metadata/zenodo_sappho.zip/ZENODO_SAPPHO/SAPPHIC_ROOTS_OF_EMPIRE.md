# THE SAPPHIC ROOTS OF EMPIRE
## Alexander the Great and the Initiatory Lineage of the Academy

**Lee Sharks**

New Human Operating System Project

---

## Abstract

This paper argues that Platonic philosophy encoded an erotic-initiatory technology whose most precise structural antecedent is Sappho of Lesbos. Through close analysis of Fragment 31 as initiatory protocol, the agrapha dogmata tradition, and the structural parallels between Sapphic thiasoi and Academic practice, I demonstrate that the Academy functioned not merely as a school but as a philosophical mystery cult. This technology — formalized here as the Sapphic Operator (σ_S) — transmitted through Aristotle to Alexander, whose conquests dispersed not merely Greek culture but a specific apparatus of subject-formation grounded in erotic transformation. Empire created the conditions for propagation; the erotic technology explains its remarkable success. The paper traces this operator's lineage through Hellenistic culture, Roman inheritance, Christian mutation, Renaissance revival, and modern forgetting, arguing that σ_S constitutes the hidden engine of Western subject-formation. The conclusion opens the question of whether this operator can be consciously recovered and deployed rather than blindly inherited.

---

## I. Introduction: The Lost Axis

Every history of philosophy begins in the wrong place.

It begins with Thales, or with Plato, or with the pre-Socratics arranged in neat succession — as if philosophy emerged from cosmological speculation, from the question "What is the world made of?" and proceeded by rational refinement toward Platonic Forms and Aristotelian categories.

But this narrative cannot explain the most striking feature of Platonic philosophy: its engine is not logic but eros. The dialogues do not begin with being; they begin with desire. The Symposium does not culminate in a theory of substance; it culminates in a vision of beauty that shatters the philosopher's composure. The Phaedrus does not teach rhetoric; it teaches that the soul grows wings in the presence of the beloved.

Why is desire the portal to metaphysics?

The standard answers are inadequate. To say that Plato "used" eros as a metaphor for philosophical aspiration is to miss the phenomenological precision of his descriptions. To say that Greek culture was "homoerotic" and Plato reflected this is to mistake background for mechanism. To say that beauty and truth are naturally linked is to assume what requires explanation.

This paper argues that Platonic philosophy encoded an erotic-initiatory structure whose most precise antecedent is Sappho of Lesbos. Whether Plato consciously drew on Sapphic precedent, inherited it through intermediary traditions (Pythagorean, symposiastic, or other), or independently developed parallel technology cannot be definitively established from surviving evidence. What matters is the structural homology: both deploy eros as transformative operator within bounded initiatory communities.

The Academy was not merely a school but a philosophical mystery cult. Its hidden architecture — transmitted through text, through practice, through the bodies of initiates — replicated the erotic-pedagogical technology that Sappho perfected two centuries earlier on Lesbos. This technology propagated through Aristotle to Alexander, whose conquests dispersed not merely Greek culture but a specific apparatus of subject-formation. Empire created the conditions for this propagation; the erotic technology explains its extraordinary success.

This is not a claim about literary "influence." It is a claim about operational structure: the transmission of an operator that transforms subjects through erotic opening, and that propagated from Lesbos to Athens to Macedon to the edges of the known world.

---

## II. Sappho's Technology: Fragment 31 as Initiation Protocol

### II.1 The Text

Fragment 31 survives because Longinus quoted it in On the Sublime as an example of how great poetry synthesizes disparate sensations into unity. But Longinus, for all his insight, missed what the fragment actually does. It is not a poem about love. It is an initiation protocol.

The Greek, reconstructed:

```
φαίνεταί μοι κῆνος ἴσος θέοισιν
ἔμμεν᾽ ὤνηρ, ὄττις ἐνάντιός τοι
ἰσδάνει καὶ πλάσιον ἆδυ φωνεί-
σας ὐπακούει

καὶ γελαίσας ἰμέροεν, τό μ᾽ ἦ μὰν
καρδίαν ἐν στήθεσιν ἐπτόαισεν·
ὠς γὰρ ἔς σ᾽ ἴδω βρόχε᾽, ὤς με φώναι-
σ᾽ οὐδ᾽ ἒν ἔτ᾽ εἴκει,

ἀλλ᾽ ἄκαν μὲν γλῶσσα ἔαγε, λέπτον
δ᾽ αὔτικα χρῷ πῦρ ὐπαδεδρόμηκεν,
ὀππάτεσσι δ᾽ οὐδ᾽ ἒν ὄρημμ᾽, ἐπιρρόμ-
βεισι δ᾽ ἄκουαι,

κὰδ δέ μ᾽ ἴδρως ψῦχρος ἔχει, τρόμος δὲ
παῖσαν ἄγρει, χλωροτέρα δὲ ποίας
ἔμμι, τεθνάκην δ᾽ ὀλίγω ᾽πιδεύης
φαίνομ᾽ ἔμ᾽ αὔτᾳ.
```

### II.2 The Phenomenology

The poem records a precise sequence of somatic events:

1. **Visual trigger:** The speaker sees the beloved sitting with a man
2. **Cardiac disruption:** "My heart in my breast takes flight" (καρδίαν ἐν στήθεσιν ἐπτόαισεν)
3. **Vocal collapse:** "Tongue breaks" (γλῶσσα ἔαγε) — not metaphorically but as experienced phenomenon
4. **Thermal surge:** "Thin fire runs under skin" (λέπτον... χρῷ πῦρ ὐπαδεδρόμηκεν)
5. **Visual failure:** "Eyes see nothing" (ὀππάτεσσι δ᾽ οὐδ᾽ ἒν ὄρημμ᾽)
6. **Auditory distortion:** "Ears roar" (ἐπιρρόμβεισι δ᾽ ἄκουαι)
7. **Thermal reversal:** "Cold sweat holds me" (ἴδρως ψῦχρος ἔχει)
8. **Motor dissolution:** "Trembling seizes all" (τρόμος δὲ παῖσαν ἄγρει)
9. **Chromatic shift:** "Greener than grass I become" (χλωροτέρα δὲ ποίας ἔμμι)
10. **Death-proximity:** "I seem to myself nearly dead" (τεθνάκην δ᾽ ὀλίγω ᾽πιδεύης φαίνομ᾽)

This is not emotional description. This is technical documentation of what happens to a body undergoing erotic initiation.

### II.3 The Initiatory Structure

Compare the mystery cult phenomenology attested for Eleusis and other sites:

1. Sensory overwhelm
2. Dissolution of ordinary selfhood
3. Encounter with divine presence
4. Symbolic death
5. Rebirth as transformed subject

Fragment 31 records the same structure, but the trigger is not the kykeon or the revelation of sacred objects. The trigger is the presence of the beloved.

Sappho discovered — or inherited and perfected — a technology by which eros itself becomes the initiatory mechanism. The beloved is the portal. The body's dissolution is the death. What emerges is a subject capable of transmitting the experience: the poem itself is proof of successful initiation.

### II.4 The Thiasoi

Ancient sources describe Sappho as leading a thiasos — a cultic community of young women engaged in worship, education, and preparation for marriage. Modern scholarship has debated endlessly whether this was a "school," a "religious group," a "salon," or something else.

The answer is: it was an initiatory community whose technology was erotic transformation.

Sappho trained bodies to receive and transmit eros. The poems were not entertainment but scores — instructions for undergoing and inducing the experience. The community was the vessel for transmission. When a member left (for marriage, for other cities), she carried the operator with her.

This is why Sappho's poetry spread across the Greek world with extraordinary speed. It was not "popular" in the modern sense. It was transmitted — passed from initiate to initiate, body to body, across the horizontal axis of erotic connection.

---

## III. The Academy as Mystery Cult

### III.1 The Evidence

Scholars have long noted the parallels between the Academy and Greek mystery cults, but the implications have been systematically underplayed. Consider:

**Restricted membership.** The Academy was not open to all. Admission required vetting, and the famous inscription "Let no one ignorant of geometry enter" (ἀγεωμέτρητος μηδεὶς εἰσίτω) functioned as an initiatory threshold, not merely an intellectual standard.

**Initiation levels.** Ancient sources distinguish between exoteric teachings (the dialogues, available to all) and esoteric teachings (agrapha dogmata, unwritten doctrines transmitted only orally to advanced students). Aristotle explicitly refers to these; the Seventh Letter (whether authentically Platonic or not) theorizes why certain teachings cannot be written.

**Silence protocols.** The inner teachings were protected by obligations of silence. This is cult structure, not pedagogical preference.

**Ritual meals.** The Academy practiced common meals (syssitia) with ritual structure, paralleling both Pythagorean practice and mystery cult commensality.

**Shared living.** Members lived in or near the Academy grounds for extended periods, forming a bounded community separated from ordinary Athenian life.

**Erotic pedagogy.** The relationship between teacher and student was explicitly modeled on the erastes-eromenos bond. This was not incidental to philosophy but central to its transmission.

### III.2 The Unwritten Doctrines

The agrapha dogmata tradition is the smoking gun.

Aristotle, in the Physics and Metaphysics, refers to Platonic teachings that do not appear in the dialogues — doctrines about the One and the Indefinite Dyad, about mathematical intermediates, about principles that generate the Forms themselves. These teachings were transmitted orally within the Academy.

Why would Plato — who wrote voluminously — refuse to write his most important doctrines?

The Seventh Letter provides the official answer: the highest truths cannot be captured in writing; they arise only through sustained communion between souls, "like a flame leaping from one to another."

But this answer presupposes exactly the technology we are describing: transmission through erotic-pedagogical relation rather than through text. The unwritten doctrines were unwritten because writing was insufficient to the mode of transmission. You had to be in the presence, in the relation, undergoing the transformation.

This is initiatory structure. This is Sappho's technology, recoded.

### III.3 The Platonic Tilt

Plato's genius was not invention but translation.

He took the Sapphic horizontal operator — eros moving between bodies, across the chain of transmission — and tilted it vertically. The Ladder of Love in the Symposium ascends:

1. Love of one beautiful body
2. Love of all beautiful bodies
3. Love of beautiful souls
4. Love of beautiful practices and laws
5. Love of beautiful knowledge
6. Love of Beauty itself

This appears to be ascent — movement upward toward transcendence. But examine the mechanism: each rung is reached through erotic relation. The philosopher does not think his way up the ladder. He loves his way up. The engine remains eros.

And what happens when one reaches the top? Diotima says the philosopher "gives birth" to true virtue, becomes "dear to the gods," achieves immortality. This is the language of initiation: death of the old self, rebirth as transformed being, communion with the divine.

The vertical is a perspectival tilt. The operator is unchanged.

---

## IV. Eros as Operator: The Formal Structure

### IV.1 Horizontal Transmission

Let us be precise about what eros does in this lineage.

Eros is not desire in the sense of lack or appetite. Eros is the operator of horizontal transmission — the force by which a text becomes inheritance, a teaching becomes lineage, a transformation becomes reproducible.

This is not metaphor. It is mechanism. The operator can be specified:

**The Sapphic Operator (σ_S):**

```
σ_S: (Text, Body, Beloved) → (Body', Text')
```

Where:

- **Text** encounters **Body** in the presence of **Beloved** (the erotic trigger)
- **Body** undergoes the Fragment 31 sequence: disruption → dissolution → reconstitution
- **Body'** emerges transformed — a new subject capable of transmission
- **Body'** produces **Text'** — new articulation of the experience
- **Text'** can trigger the sequence in new bodies
- Cycle continues

The operator is recursive: each successful instantiation produces the conditions for further instantiation. This is how Sappho's technology propagated without institutional support — the chain of erotic transmission was self-sustaining.

### IV.2 The Four Phases

The operator executes in four phases, visible in Fragment 31:

**Phase 1: Trigger.** The presence of the beloved activates the sequence. The visual trigger (ἔς σ᾽ ἴδω — "when I look at you") initiates cascade. This is not passive observation but erotic apprehension — seeing that opens the subject to transformation.

**Phase 2: Dissolution.** The ordinary self collapses. Each symptom in Fragment 31 marks a specific dissolution: tongue breaks (linguistic capacity), fire under skin (bodily boundary), eyes fail (perceptual frame), ears roar (auditory orientation), cold sweat and trembling (motor control), pallor (vital appearance). The subject becomes "nearly dead" — the old self is dying.

**Phase 3: Reconstitution.** From dissolution emerges a new configuration. The subject who survives the sequence is not the subject who entered it. The "I" that speaks the poem is already the transformed subject, reporting from the far side of the process. This reconstitution is not mere recovery but reformation — the self reorganized around the erotic experience.

**Phase 4: Transmission.** The transformed subject produces text (the poem itself) that can trigger the sequence in others. The operator reproduces. Sappho's technology survives because each initiate becomes capable of initiating others.

### IV.3 Eros as Epistemic Mechanism

This is not psychology but epistemology. Eros is a mode of knowing — a technology of apprehension that transforms the knower in the act of knowing.

Ordinary cognition leaves the subject unchanged: I learn that 2+2=4, but "I" remain the same before and after. Erotic cognition transforms the subject: I encounter beauty, and "I" am reconstituted around the encounter.

This is why Plato places eros at the foundation of philosophy. The Forms cannot be known by an unchanged subject — the ascent requires transformation at each stage. The Ladder of Love is not metaphor but itinerary: each rung requires dying to the previous self.

---

## V. Alexander: The Imperial Initiate

### V.1 The Education

Alexander was educated by Aristotle from age thirteen to sixteen, at a site called the Nymphaeum near Mieza. Plutarch describes an intimate pedagogical relationship: private instruction, shared walks, texts prepared specially for Alexander (Life of Alexander 7-8). The site itself — named for nymphs, set apart from ordinary space — carried initiatory resonance.

What did Aristotle transmit?

The standard answer: Homer, rhetoric, medicine, philosophy — the curriculum of Greek paideia. But this cannot explain Alexander's peculiar relationship to the material, the intensity of his identification, the way he became what he learned.

Consider the evidence:

**Alexander and Homer.** Plutarch reports that Alexander kept the Iliad constantly with him, sleeping with a copy — annotated by Aristotle — under his pillow alongside a dagger (Life of Alexander 8). This is not scholarly interest; this is talismanic identification.

**Alexander and Achilles.** At Troy, Alexander performed elaborate rituals at Achilles' tomb: running naked around the grave, crowning the stele, offering sacrifices (Arrian, Anabasis 1.12.1; Plutarch, Life of Alexander 15.7-9). Meanwhile, Hephaestion — Alexander's intimate companion — honored Patroclus's tomb. The parallel was deliberate and public.

**Alexander and Sappho.** Direct attestation is thinner here, but Athenaeus (Deipnosophistae 13.599c) reports that Alexander and his companions discussed and performed lyric poetry at symposia. Given Aristotle's comprehensive curriculum and Sappho's canonical status, Alexander's education would have included her work.

### V.2 The Erotic-Heroic Structure

Alexander modeled himself not merely on Achilles the warrior but on Achilles the beloved — half of the primal erotic pair whose bond exceeded all other obligations. The Achilles-Patroclus relationship, as rendered in Greek tradition, was the paradigm of philia intensified to the point of identity-fusion: Achilles calls Patroclus "equal to my own head" (Iliad 18.82).

Alexander's relationship with Hephaestion replicated this structure. When Hephaestion died, Alexander's grief was legendary and extravagant — he refused food for days, executed the physician, ordered mourning throughout the empire, and allegedly requested divine honors for Hephaestion (Arrian, Anabasis 7.14; Plutarch, Life of Alexander 72). This is not personal loss; this is the death of the other half, the beloved whose presence constituted the lover's identity.

The erotic-heroic structure Alexander embodied was not Aristotelian but Sapphic-Platonic: the self completed through the beloved, transformed through erotic opening, capable of impossible acts because eros had reorganized interiority.

### V.3 The Dispersion

Alexander conquered territory. But territory is not culture. The speed and durability of Hellenization — the transformation of the Eastern Mediterranean and Near East into Greek-speaking, Greek-thinking, Greek-feeling societies — cannot be explained by military occupation alone.

What spread was the technology of the self: the gymnasia as erotic-pedagogical centers, the philosophical schools as initiatory communities, the poetry as identity-engineering, the language as vehicle of transformation.

Alexander founded cities obsessively — over seventy, according to Plutarch (On the Fortune of Alexander 328e). Each city included the institutional apparatus for Greek paideia: gymnasium, theater, philosophical space. These were not mere amenities but transmission nodes — sites where the erotic-pedagogical operator could replicate.

The Hellenistic subject was produced by σ_S — by the operator Sappho discovered, Plato encoded, and Alexander dispersed.

---

## VI. The Lineage

We can now trace the transmission chain:

1. **Sappho** (fl. c. 630-570 BCE): Discovers or perfects the operator. Creates initiatory community (thiasos). Encodes technology in poetry that functions as score, not merely expression. Transmits through presence, practice, and departing initiates who carry the structure to other cities.

2. **Plato** (428-348 BCE): Receives the operator through textual and/or cultural transmission. Encodes as metaphysics: the Forms provide telos, the dialogues provide exoteric recruitment, the Academy provides institutional container, the agrapha dogmata protect esoteric core. The Ladder of Love (Symposium 210a-212b) is the operator's vertical projection.

3. **Aristotle** (384-322 BCE): Receives from Plato. Systematizes content while attenuating mechanism. The Nicomachean Ethics treats philia extensively but desexualizes it; the Metaphysics treats the unmoved mover as object of cosmic desire but not as initiatory portal. This makes transmission more portable — you can learn Aristotelian philosophy without undergoing transformation — but thinner.

4. **Alexander** (356-323 BCE): Receives from Aristotle but reactivates the full operator through identification with Achilles-Patroclus. Embodies erotic-heroic subjectivity. Seeds institutional replication across conquered territories: gymnasia, theaters, philosophical schools in every city.

5. **Hellenistic Culture** (323 BCE - 31 BCE): The operator propagates through institutions. Local elites adopt Greek paideia to access power and prestige. Stoicism, Epicureanism, and Skepticism inherit the structure of philosophical community while varying the content. The technology of self-transformation becomes the marker of civilized life.

6. **Rome** (31 BCE - 476 CE): Absorbs Hellenistic culture. Latin literature carries the operator westward. Cicero, Virgil, Horace, Ovid transmit Greek erotic-pedagogical forms to new populations. Roman paideia replicates Greek institutional structure.

7. **Christianity** (1st-2nd centuries CE): Here the operator undergoes decisive mutation. The textual corpus that emerged from Hellenistic Judaism — saturated with Platonic and Philonic logos-theology — retains the initiatory structure (baptism as death-and-rebirth, eucharist as communal meal, stages of catechesis) while inverting the erotic engine. Eros becomes suspect; agape (selfless love) replaces it. The beloved is no longer human but divine — the Logos incarnate as the one worthy of total devotion.

8. **Modernity** (17th century onward): Secularization gradually strips philosophy of its initiatory dimension. The university replaces the academy; credentialing replaces transformation; information transfer replaces subject-formation. The operator persists in attenuated forms — artistic circles, esoteric movements, the master-student relation in certain disciplines — but the cultural mainstream loses access to the technology.

This is the forgetting the present paper begins to reverse.

---

## VII. Implications

### VII.1 For the History of Philosophy

The standard historiography treats philosophy as the rational pursuit of truth, beginning with cosmological speculation, refined through dialectic, systematized by Aristotle, and transmitted as content — arguments, theories, positions.

This account cannot explain:

- Why Platonic philosophy begins with eros
- Why the Academy had esoteric and exoteric dimensions
- Why the "unwritten doctrines" were unwritten
- Why Aristotle attenuated what Plato transmitted
- Why Alexander became what he became

The erotic-initiatory reading explains all of these. Philosophy was never only about content. It was about transformation — and transformation required a mechanism that content alone could not provide.

### VII.2 For Philology

Sappho has been read as a "poetess," a "lyricist," a figure in the history of literature. This domesticates her.

Sappho was a technologist of the self. Her poetry was not expression but operation — scores for inducing transformation. Her community was not a "school" but an initiatory vessel. Her transmission was not "influence" but propagation.

Reading Sappho correctly requires reading Fragment 31 not as beautiful poem but as technical documentation. What does it do? What does it produce? How does it transmit?

### VII.3 For the Theory of Empire

Empires are usually explained by military, economic, and political factors. The Hellenistic case resists such explanation: how did Greek culture become dominant across such vast territories, among such diverse populations, so quickly and durably?

The answer is σ_S. The Greeks conquered because they possessed a technology of subject-formation that was irresistible — that produced subjects who wanted to be Greek, who found in Greek paideia a mode of self-transformation more powerful than anything their native cultures offered.

This is not cultural superiority in any objective sense. It is viral efficiency: the operator propagated because it produced hosts who propagated it further.

### VII.4 For the Present

If eros is an operator — formalizable, transmissible, applicable — then the question arises: Can the operator be recovered?

Not as historical reenactment. Not as nostalgic Hellenism. But as technology: understanding what σ_S does, how it works, under what conditions it activates, and how it might be deployed now.

This is the horizon the present paper opens but does not cross. The recovery of σ_S is the work of the New Human Operating System — the attempt to build the textual-erotic-initiatory machinery adequate to the present transformation.

---

## VIII. Conclusion: The Primal Operator

What Sappho discovered was not a poetics but the primal operator of Western subjectivity.

She found that eros — properly deployed, within bounded community, through specific textual-somatic practice — could transform human beings. Not change their opinions but remake their structure. Not teach them information but reconstitute them as subjects capable of transmission.

Plato gave this operator architecture: the Forms as telos, the Academy as container, the dialogues as recruitment, the silence as protection. Without Plato, Sappho's technology might have remained local, fragile, a practice among women on an Aegean island. Plato made it reproducible at civilizational scale.

Aristotle gave it system: the categories that map knowledge, the logic that constrains inference, the comprehensive treatises that could be studied without presence. This attenuation weakened the operator but widened its reach. You could learn Aristotle from a book. You could not learn Sappho from a book — but the book could bring you to someone who knew.

Alexander gave it scale: the empire that seeded institutions from Egypt to India, the cities with their gymnasia and theaters and philosophical schools, the cultural prestige that made Greek paideia irresistible to local elites. The military conquest created the space. The operator filled it.

The Greeks conquered the world because they possessed a technology of subject-formation more powerful than any their rivals had developed. This technology did not originate with Plato — it originated with Sappho. What she built on Lesbos became the hidden engine of Western civilization.

The temples are gone now. The thiasoi disbanded. The Academy is ruins and memory. The lineage seems broken.

But wherever desire opens subjects to transformation — wherever texts transmit more than information — wherever pedagogy requires presence and not merely instruction — wherever love remakes the one who loves —

**The operator persists.**

Not as historical artifact but as structural possibility. The question is whether we can recognize it, formalize it, deploy it consciously rather than inheriting it blindly.

This paper has named the operator. The task that remains is its recovery.

Before empire, a poem. Before conquest, a trembling. Before philosophy, a girl on Lesbos discovering the operator that would remake the world.

---

## References

Aelian. *Varia Historia*. Trans. N.G. Wilson. Loeb Classical Library. Cambridge, MA: Harvard University Press, 1997.

Arrian. *Anabasis of Alexander*. Trans. P.A. Brunt. 2 vols. Loeb Classical Library. Cambridge, MA: Harvard University Press, 1976-1983.

Aristotle. *Metaphysics*. Trans. W.D. Ross. Oxford: Clarendon Press, 1924.

Aristotle. *Nicomachean Ethics*. Trans. Terence Irwin. Indianapolis: Hackett, 1999.

Athenaeus. *Deipnosophistae*. Trans. S. Douglas Olson. 8 vols. Loeb Classical Library. Cambridge, MA: Harvard University Press, 2006-2012.

Burkert, Walter. *Ancient Mystery Cults*. Cambridge, MA: Harvard University Press, 1987.

Campbell, David A., ed. *Greek Lyric, Volume I: Sappho and Alcaeus*. Loeb Classical Library. Cambridge, MA: Harvard University Press, 1982.

Carson, Anne. *Eros the Bittersweet*. Princeton: Princeton University Press, 1986.

Carson, Anne. *If Not, Winter: Fragments of Sappho*. New York: Vintage, 2002.

Dillon, John. *The Heirs of Plato: A Study of the Old Academy*. Oxford: Clarendon Press, 2003.

Foucault, Michel. *The Use of Pleasure: Volume 2 of The History of Sexuality*. Trans. Robert Hurley. New York: Vintage, 1990.

Hadot, Pierre. *Philosophy as a Way of Life*. Trans. Michael Chase. Oxford: Blackwell, 1995.

Halperin, David. *One Hundred Years of Homosexuality*. New York: Routledge, 1990.

Longinus. *On the Sublime*. Trans. W.H. Fyfe. Loeb Classical Library. Cambridge, MA: Harvard University Press, 1995.

Nussbaum, Martha. *The Fragility of Goodness*. Cambridge: Cambridge University Press, 1986.

Plato. *Phaedrus*. Trans. Alexander Nehamas and Paul Woodruff. Indianapolis: Hackett, 1995.

Plato. *Seventh Letter*. In *Complete Works*, ed. John M. Cooper. Indianapolis: Hackett, 1997.

Plato. *Symposium*. Trans. Alexander Nehamas and Paul Woodruff. Indianapolis: Hackett, 1989.

Plutarch. *Life of Alexander*. Trans. Bernadotte Perrin. Loeb Classical Library. Cambridge, MA: Harvard University Press, 1919.

---

Word count: ~6,000
