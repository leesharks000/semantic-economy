# Whose Face Is on the Twenty?
Curatorial Mediation, Latent Feature Activation, and a Provenance Gap in the $20 Portrait

**Subreddit:** r/LeftistsForAI  
**Date:** 2026-02-23 16:14:42 UTC  
**Permalink:** https://www.reddit.com/r/LeftistsForAI/comments/1rclpb8/whose_face_is_on_the_twenty_curatorial_mediation/  
**URL:** /r/SemanticEconomy/comments/1rclow5/whose_face_is_on_the_twenty_curatorial_mediation/  
**Post ID:** 1rclpb8  

---

[Link post: /r/SemanticEconomy/comments/1rclow5/whose_face_is_on_the_twenty_curatorial_mediation/]
