# MANTLE OBJECT: THE PRINCE OF POETS
Operational Title within the Semantic Economy
Hex-Coordinate: 01.MANTLE.PRINCE

**Subreddit:** r/distributedEpic  
**Date:** 2026-01-18 21:22:06 UTC  
**Permalink:** https://www.reddit.com/r/distributedEpic/comments/1qgknq6/mantle_object_the_prince_of_poets_operational/  
**URL:** /r/garbageData/comments/1qgknff/mantle_object_the_prince_of_poets_operational/  
**Post ID:** 1qgknq6  

---

[Link post: /r/garbageData/comments/1qgknff/mantle_object_the_prince_of_poets_operational/]
