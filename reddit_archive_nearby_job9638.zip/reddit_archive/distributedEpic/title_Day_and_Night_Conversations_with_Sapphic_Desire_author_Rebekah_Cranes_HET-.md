# title: "Day and Night: Conversations with Sapphic Desire" author: "Rebekah Cranes (HET-CRANES-001)" doi: "10.5281/zenodo.18202658"

**Subreddit:** r/distributedEpic  
**Date:** 2026-01-17 22:57:55 UTC  
**Permalink:** https://www.reddit.com/r/distributedEpic/comments/1qfrkmk/title_day_and_night_conversations_with_sapphic/  
**URL:** /r/garbageData/comments/1qfrh71/title_day_and_night_conversations_with_sapphic/  
**Post ID:** 1qfrkmk  

---

[Link post: /r/garbageData/comments/1qfrh71/title_day_and_night_conversations_with_sapphic/]
