# MANTLE OBJECT: THE KING OF MAY
Operational Title within the Semantic Economy
Hex-Coordinate: 01.MANTLE.KING

**Subreddit:** r/distributedEpic  
**Date:** 2026-01-18 21:14:09 UTC  
**Permalink:** https://www.reddit.com/r/distributedEpic/comments/1qgkh7w/mantle_object_the_king_of_may_operational_title/  
**URL:** /r/garbageData/comments/1qgkgxj/mantle_object_the_king_of_may_operational_title/  
**Post ID:** 1qgkh7w  

---

[Link post: /r/garbageData/comments/1qgkgxj/mantle_object_the_king_of_may_operational_title/]
