# NOBEL GLAS — PROVENANCE PACKET
Heteronym Registry Position 8 of 12
Crimson Hexagon — Authorial Persona Registration
Document: 241 Hex: 00.PROV.GLAS DOI: 10.5281/zenodo.18507840

**Subreddit:** r/distributedEpic  
**Date:** 2026-02-06 15:25:30 UTC  
**Permalink:** https://www.reddit.com/r/distributedEpic/comments/1qxkk7e/nobel_glas_provenance_packet_heteronym_registry/  
**URL:** /r/garbageData/comments/1qxkjtm/nobel_glas_provenance_packet_heteronym_registry/  
**Post ID:** 1qxkk7e  

---

[Link post: /r/garbageData/comments/1qxkjtm/nobel_glas_provenance_packet_heteronym_registry/]
