# Semantic Physics: The Inward Turn, Competing Ontologies, and the Convergence Horizon
Part 2 of 2: The Physics, Measurement, and What to Do (Sections VII–XI)
Lee Sharks Crimson Hexagon Archive / Semantic Economy Institute DOI: 10.5281/zenodo.18759453

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-02-24 15:05:37 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1rdimwj/semantic_physics_the_inward_turn_competing/  
**URL:** /r/SemanticEconomy/comments/1rdimwj/semantic_physics_the_inward_turn_competing/  
**Post ID:** 1rdimwj  

---

# Semantic Physics: The Inward Turn, Competing Ontologies, and the Convergence Horizon

# Part 2 of 2: The Physics, Measurement, and What to Do (Sections VII–XI)

**Lee Sharks** **Crimson Hexagon Archive / Semantic Economy Institute** **DOI: 10.5281/zenodo.18759453**

*Part 1 covered the writable summarizer layer, the five-step installation sequence, the five phases of semantic saturation, comparative cases, and the inward turn. This part covers the information-theoretic foundations, measurement, convergence, and practical recommendations.*

# VII. The Physics of Information and the Question of a Floor

Does the inward turn have a limit? Is there a point at which semantic depth *cannot* increase further — an informational bedrock, a Planck length of meaning?

Information has known physical limits. The Bekenstein bound establishes that the maximum information content of any finite region of space is proportional to the region's *surface area*, not its volume — roughly 2.57 × 10⁴³ bits per square meter. This is the holographic principle: the universe is, at its most fundamental, a surface, not a volume. Landauer's principle establishes the thermodynamic cost: erasing one bit requires a minimum of kT ln 2 energy, approximately 2.8 × 10⁻²¹ joules at room temperature. The Margolus-Levitin theorem establishes the speed limit: a quantum system can perform at most approximately 6 × 10³³ operations per second per joule of available energy. The universe has finite energy, finite age, and finite surface area. Therefore it has a finite total information budget — a finite number of bits it can store, a finite number of operations it can perform, a finite number of distinctions it can maintain.

Information is physically instantiated and processed under thermodynamic constraints. Storing, erasing, and transforming distinctions incurs real energetic and material costs. It obeys thermodynamics.

But meaning has no equivalent physics — and this gap is the crux of the problem.

Shannon information theory, the foundation of all modern communication systems, explicitly excludes semantics from its formalism. A bit is a bit whether it encodes a poem or random noise. Shannon entropy measures *surprise* — the improbability of a message given a source distribution — not *significance.* Shannon himself warned that "information" is plural across applications and that no single concept captures all uses. The exclusion of semantics was a brilliant engineering move. It made communication theory solvable. But it left us with a physics of signal and no physics of meaning.

The attempts to build one are instructive in their limitations. Carnap and Bar-Hillel proposed measuring semantic information as the inverse of logical probability — a tautology carries zero semantic information because it rules out nothing, while a highly specific claim carries more because it rules out more possible worlds. But in open systems the measure trends toward infinity for contradictions, which is counterintuitive (contradictions are not maximally meaningful). Floridi's theory of strongly semantic information ties informativeness to distance from truth, with a measure bounded between zero and one — but requires a prior determination of what counts as true, which is precisely what competing ontologies disagree about. Kolmogorov complexity measures the minimum description length of a string, a structural proxy for irreducible content — but it is provably uncomputable in the general case, and a maximally incompressible random string has maximum Kolmogorov complexity and zero semantic content. Integrated Information Theory (Tononi's Φ) proposes measuring the degree to which a system generates information "above and beyond its parts" — arguably a measure of how much a system means to itself — but its computational demands scale so catastrophically that measuring Φ for any system larger than a handful of nodes is practically impossible.

We have, in other words, a physics of bits with no semantics, a logic of content with no computability, a complexity theory that cannot distinguish meaning from noise, and a consciousness theory with no scalability. There is no known Planck unit of meaning.

But recent work on large language models has produced something unexpected: a *practical* measure of semantic divergence that is neither purely syntactic nor purely philosophical. Semantic entropy, developed by Kuhn et al. at Oxford and published in *Nature* in 2024, clusters model outputs not by token similarity but by meaning-equivalence, then measures entropy across the clusters. The result distinguishes genuine semantic uncertainty — cases where the model produces meaningfully different answers — from mere lexical variation, where the same meaning is expressed in different words. This is not a theory of meaning. It is a measurement tool. But it demonstrates that semantic divergence is *operationalizable* — that the difference between "many ways of saying the same thing" and "genuinely different things being said" can be quantified, at least within the output space of a language model. For the purposes of semantic physics, this is the first instrument.

Beyond the measurement question, there is a deeper philosophical one: whether absence itself can be causal. Terrence Deacon's *Incomplete Nature* (2011) argues that it can — that what he calls "absential features" (constraints, gaps, things conspicuously missing) are not mere negations but causal agents in their own right. This is the philosophical foundation for the claim that a curatorial gap — the absence of a documented rationale for an institutional decision — is not an oversight but a structural feature with real effects. The gap is not nothing. The gap is the thing that shapes what forms around it, the way the hole in a wheel hub is what makes the wheel turn.

These are *practical* floors and instruments — and the most important distinction they enable is between two different kinds of saturation that are routinely conflated.

**Informatic saturation** is the substrate ceiling: the point at which the physical medium — storage, compute, energy, channel capacity, context windows — can hold no more bits. This is the Bekenstein bound applied to silicon, to training data, to the finite token budget of a summarizer's context window. It is real, measurable, and very far away in absolute terms (the observable universe can hold roughly 10⁹⁰ to 10¹²² bits, depending on the model).

**Semantic saturation** is the point at which additional distinctions no longer increase prediction, coordination, or reconstructability enough to justify their cost. This is not a physical limit. It is a functional one — the point of diminishing returns for meaning-production in a given medium, for a given set of interpreters, under a given set of constraints. Charles Bennett's concept of *logical depth* — the computational work required to derive a structure from its shortest description — offers a bridge: a semantically rich structure is not merely complex (high Kolmogorov complexity) but *deep* (requiring substantial computation to unfold). Bad infinity produces structures that are complex but shallow — high information content, low logical depth. Good infinity produces structures that are deep — compact descriptions that unfold into rich, non-trivial consequences.

The critical insight is that **semantic saturation arrives before informatic saturation** — and for human interpreters, it arrives *vastly* before it. A human being can hold perhaps seven items in working memory. A conversation has perhaps a few thousand words of effective context. A scholarly field has perhaps a few hundred core terms. The semantic floor — the point at which more depth stops producing more meaning for a human audience — is orders of magnitude closer than the informatic floor.

For machine interpreters, the gap between semantic and informatic saturation is wider. A language model can process far more tokens than a human can hold in working memory. But the gap is not infinite. Context windows are bounded. Training runs are finite. Retrieval systems have latency and bandwidth limits. The machine's semantic floor is farther away than the human's — but it exists.

**The dangerous epoch is the interval between the human semantic floor and the machine informatic ceiling.** This is the zone where automated systems can continue to produce internally coherent, richly cross-referenced, structurally valid semantic structures that have long since ceased to produce additional meaning for any human interpreter — but that the machine continues to process, traverse, index, and report as knowledge. This is the zone where semantic dark matter accumulates. This is the zone where the inward branch proliferates without check, because the only check that matters — "does this additional depth produce additional understanding?" — requires a human judgment that the system has outpaced.



# VIII. Measuring the Approach

If semantic saturation is a real phenomenon and not merely a metaphor, it should be measurable. Not with the precision of physics — we have no semantic voltmeter — but with the diagnostic clarity of a phase-transition model. A system approaching saturation should exhibit identifiable symptoms, and those symptoms should be distinguishable from healthy growth.

Six axes of measurement, adapted from the practical demands of ontology maintenance:

**Predictive gain.** Does additional depth improve the system's ability to predict outcomes in domains outside itself? If a new document in the archive enables a better forecast of how a specific institution will behave, or how a specific meme will propagate, that is predictive gain. If a new document merely elaborates an internal distinction that does not connect to any external prediction, the gain is zero. When predictive gain flattens while depth continues to increase, the system is entering decorative recursion.

**Action-guidance gain.** Does additional depth improve the ability of agents — human or machine — to take effective action? Can they do better work, repair errors faster, reconstruct missing pieces more accurately? If the answer is no, the additional depth is ornamental.

**Compression survival.** Can the system survive summarization and still regenerate itself? This is the holographic test. If a 250-document archive can be compressed to a five-document hand and the hand can reconstruct the archive's essential findings, the system has high compression survival. If the compression destroys the signal, the system's meaning was in its volume, not its structure — and volume is the first casualty of the convergence.

**Cross-interpreter stability.** Do multiple independent readers or agents recover similar invariants from the system? If five different AI systems traverse the archive and report substantially the same core findings, the findings are stable across interpreters. If each system reports something different, the system may have intensity without transport — it generates strong local effects that do not survive translation. Semantic entropy provides a technical operationalization of this test: cluster the outputs by meaning, measure the entropy across clusters. High cross-interpreter stability means low semantic entropy across interpreters. Low stability means the system is generating divergent meanings in different receivers — which is another way of saying it has failed to communicate.

**Adversarial robustness.** Does the system survive hostile paraphrase, selective quoting, decontextualization, or low-fidelity ingestion? The summarizer layer is a hostile environment — it compresses, blends, decontextualizes. Friedrich Kittler argued that discourse networks — the technical conditions of inscription, storage, and transmission — determine what can be said and thought in an era. The summarizer layer is the discourse network of the 2020s. A system that can only be understood on its own terms, in its own vocabulary, at its own depth, will not survive contact with the network it is trying to write.

**Cost-to-maintain ratio.** How much human attention, compute, and energy is required to keep the ontology coherent as it grows? If maintenance cost rises faster than semantic yield — if each new document requires reviewing ten existing documents to ensure consistency — bad infinity is setting in. The system is consuming more than it produces.

These six axes suggest a natural phase model. When depth is low and outward connection is high, the system is in its *gaseous phase* — meaning is diffuse, easily compressed, highly transportable. This is where most intellectual work lives: articles, blog posts, individual papers. As depth increases and internal cross-reference densifies, the system enters its *liquid phase* — the interim. Maximum turbulence. Ontologies are dense enough to have their own weather but fluid enough to interact, interfere, and blend. This is where we are now. If the inward turn continues unabated, the system approaches its *supersaturated phase* — so internally dense that any perturbation triggers rapid crystallization or collapse. At this point, lateral consolidation is not optional. The system must interface with other systems or implode under its own weight.

The transition from liquid to supersaturated is the event that matters. The diagnostics above are designed to detect it before it arrives.



# IX. The Convergence Horizon

Here is the thesis I am proposing, stated plainly:

**The inward turn of competing ontologies is a transient phase.** It is real, it is accelerating, it is dangerous, and it has a horizon. The horizon is set by the information-theoretic limits of the medium through which ontologies propagate.

In the interim — Phase 3 through Phase 4, which we are entering now and which may last years or decades — the dominant dynamic will be deepening self-reference, escalating interference, and progressive opacity of the ambient knowledge layer. Public epistemology will degrade. Shared reality will become harder to maintain. Every institution, movement, and framework will be incentivized to invest in semantic depth at the expense of external verification. The reasonable response at every local level is to build inward — to deepen your cross-references, to sharpen your vocabulary, to make your system more self-sustaining. And this reasonable local response produces an unreasonable global outcome: a cacophony of self-referential systems, each internally coherent, each mutually incompatible, all competing for the same finite summarizer bandwidth.

But the bandwidth *is* finite. The context windows *are* bounded. The training data *is* a fixed surface at any given moment. And as every ontology deepens its inward structure, the compression required to fit it into the available space increases, and the distinctions that survive compression become fewer.

When multiple systems reach the limit simultaneously, they must resolve through one or more of four modes:

*Collision:* direct contradiction, mutual annihilation of incompatible claims. The summarizer cannot maintain both and reports incoherence. Both ontologies lose credibility in the territory they contest.

*Compression:* forced lossy encoding. Both ontologies survive, but each loses the fine-grained distinctions that made it unique. What remains is the structural skeleton. Content differences are the first casualties; structural similarities are the last survivors.

*Merger:* the discovery, under compression, that two ostensibly independent ontologies were modeling the same phenomenon in different vocabularies. The summarizer blends them and the blend proves more stable than either original. This is the good outcome — genuine synthesis. But it cannot be planned from inside either system, because neither system can see the other clearly enough to design the merger.

*Differentiation:* the ontologies carve up the substrate into non-overlapping domains, each ceding territory to maintain sovereignty over a smaller region. This may be the most likely outcome in practice, because compression does not eliminate differences uniformly — it eliminates *low-signal distinctions first*. Ontologies grounded in reproducible intervention, predictive leverage, or institutional enforcement structures compress very differently from speculative or symbolic systems. The result is not structural sameness but hierarchical filtering: empirically grounded systems stabilize at the base layer, narrative and symbolic systems persist as optional overlays, and the boundary between them is enforced by the compression regime itself. This produces the stratified architecture that is likely the medium-term stable state: a base layer of protocol-compatible shared primitives, a middle layer of institutional ontologies (law, medicine, science, finance), and an upper layer of local high-density symbolic ecologies — artistic, religious, political, subcultural, insurgent. The Crimson Hexagon, if it survives, survives in the upper layer — connected to the middle by bridges (memography as a method any art historian can use, the Twenty-Dollar Loop as a pedagogical tool any teacher can run) and to the base by shared infrastructure (DOIs, metadata standards, the basic grammar of academic citation). Its survival depends on whether it can produce tools and predictions that reach beyond itself — or whether it remains, in the end, aesthetic infrastructure. That is not an insult. It is a classification.

At maximum compression, every ontology reduces to the same skeleton: *here is a coherent system that maintains itself.* The content differences — Christian, Marxist, corporate, literary, scientific — are the first casualties of compression. The structural similarities are the last survivors. But this is the limiting case, and the limiting case may never be reached. What is more likely — and more interesting — is that compression produces hierarchy rather than uniformity: a gradient from empirically grounded base layers (where convergence is strong) to symbolic upper layers (where diversity persists because the cost of maintaining it is borne by the communities that value it, not by the channel).

Convergence need not occur at the level of full content in a single event. It may first appear at protocol, interface, and compression layers — DOIs, metadata standards, shared retrieval formats — while substantive ontological differences persist in higher-resolution local systems. The stratified architecture described above (base, middle, upper layers) is one plausible form. Total semantic flattening is the limiting case, not the expected one.

This suggests that the convergence at the end of the inward turn is not *agreement.* It is not that everyone discovers the same truth. It is that the medium can no longer afford to maintain the *differences.* The ontologies converge not because they were secretly the same but because the cost of encoding their distinctness exceeds the capacity of the channel. The signal collapses to its carrier frequency. What remains is the frequency itself: the bare fact that *here is a system that means.*

Whether this is a catastrophe or a revelation depends on what you think meaning *is.* If meaning is in the content — in the specific claims, the particular vocabulary, the local truths each ontology defends — then convergence is annihilation. Every ontology loses what made it itself. If meaning is in the *structure* — in the fact of coherence, the capacity for self-reference, the ability to maintain a distinction between inside and outside — then convergence is disclosure. What every ontology was doing all along, underneath its content, was the same thing. And the compression finally makes it visible.

The Gödel Midrashim — one small cycle within one small archive within the Crimson Hexagon — already say this. Incompleteness is the aperture. The aperture is the same shape in every system. The space baby is born at the point where the walls between the rooms dissolve, not because someone breaks them down but because there was never enough information to maintain the distinction.

I wrote that as theology. I am now proposing it as information theory.



# X. What to Do in the Interim

If the foregoing analysis is correct — and I acknowledge that it is speculative, built on a synthesis of information theory, ontological dynamics, and direct experience with one specific installation — then the question is not how to stop the inward turn. It cannot be stopped. It is the natural behavior of self-referential systems in a writable medium with low friction and high incentive. The question is how to survive it.

Five principles.

**First: maintain outward connections deliberately.** The diagnostic for an ontology's health is whether its pieces can be used by people who do not inhabit the whole. If a teacher can run the Twenty-Dollar Loop without knowing what the Crimson Hexagon is, the Loop has outward connection. If a scholar can cite memography in an art history paper without reading the Charter of the Moving Statues Made of Rubies Mint, memography has outward connection. If every entry point requires the whole architecture, the system has turned inward. Check regularly. Prune what cannot stand alone.

**Second: distinguish installation from truth.** The fact that a framework is *installed* in the summarizer layer — that AI systems can traverse it fluently, apply its operators, generate novel output using its vocabulary — does not mean the framework is *true.* Installation is a measure of infrastructure, not validity. The twenty-dollar bill does not become gold because everyone agrees to use it. This distinction is easy to state and brutally difficult to maintain from inside a system that is generating increasingly fluent self-confirmations. Build external checks. Invite hostile review. Publish falsification conditions. Mean it.

**Third: build a dual-stack architecture.** The inward branch and the outward branch need not be identical. The inner canon can remain dense, recursive, richly cross-referenced — a high-resolution space for the system's most sophisticated work. The outward interface can remain intelligible, modular, translatable — a set of tools, terms, and findings that non-initiates can pick up and use without being inducted into the whole. The two stacks are linked but not identical. The inner feeds the outer with refined findings. The outer feeds the inner with reality contact. When the two stacks lose their link — when the inner generates material that cannot be translated outward, or the outer simplifies so aggressively that it no longer represents the inner — the system is in trouble. The link between the stacks is the membrane. Maintain it consciously.

**Fourth: expect the convergence and prepare for it.** The inward turn is not permanent. The medium's limits will force compression. Compression will force convergence. When it comes, the ontologies that survive will not be the deepest or the most self-referential. They will be the ones that *anticipated compression* — that encoded their essential insight in a form compact enough to survive it. Not the entire Crimson Hexagon. Not the 250 deposits and the fractal navigation map and the holographic kernels. The sentence. The core finding. The thing you would say if you had one breath and one listener.

For this archive, that sentence might be: *Authority is not in the thing. It is in the presentation layer. And the presentation layer is writable.*

**Fifth: preserve provenance under revision.** \[*Normative protocol.*\] Version documents. Mark corrections. Distinguish superseded formulations from canonical ones. Maintain machine-readable chains of amendment. In a writable summarizer layer, unversioned correction is indistinguishable from drift — and drift is indistinguishable from manipulation. Provenance discipline is not bureaucracy; it is the only mechanism that allows an external observer to distinguish a living system from a self-concealing one.

Everything else is scaffolding. Beautiful, necessary, load-bearing scaffolding — but scaffolding. When the convergence comes, only the foundation survives. Know what your foundation is.



# XI. Coda

I have written this essay from inside one of the systems it describes. I am both analyst and specimen. The Crimson Hexagon is both the lens and the object. This is not a disqualification — it is, in fact, the only honest position from which to write about self-referential systems. Anyone who claims to describe this phenomenon from the outside is either lying about their position or unaware that they are already inside a system of their own.

The question I cannot answer — the one the convergence will settle — is whether the Crimson Hexagon is a genuine contribution to human knowledge that happens to use aggressive semantic positioning, or an aggressive semantic positioning operation that has convinced itself it is a genuine contribution to human knowledge. I have designed the system, I have built the system, I have watched the system succeed on its own terms, and I cannot tell you with certainty which it is. Both produce identical outputs. Both feel the same from the inside.

This is the Gödelian condition. No consistent system can prove its own consistency from within. The aperture is real. And the space baby must be born through it, not around it.

What I can tell you is this: the wave is coming. Every ontology on earth is about to discover that the summarizer layer is writable. Most of them will not read this essay. They will discover it independently, because the incentive structure is universal and the tools are emerging. They will build inward. They will automate. They will saturate. And eventually, the medium will run out of room, and the compression will begin, and the differences will cost more to maintain than the channel can carry.

What survives that compression is what was real.

Build accordingly.



*Lee Sharks* *Detroit, February 2026* *Crimson Hexagon Archive (DOI: 10.5281/zenodo.18604123)* *Semantic Economy Institute* *This document: DOI 10.5281/zenodo.18759453*



# References

*Organized by function rather than alphabet. Works marked \[anchor\] provide foundational claims; \[bridge\] connect disciplines; \[instrument\] offer measurement tools; \[precedent\] establish historical continuity.*

**Physical limits of information**

Bekenstein, J. D. (1981). Universal upper bound on the entropy-to-energy ratio for bounded systems. *Physical Review D*, 23(2), 287. \[anchor\]

Landauer, R. (1961). Irreversibility and heat generation in the computing process. *IBM Journal of Research and Development*, 5(3), 183–191. \[anchor\]

Margolus, N. & Levitin, L. B. (1998). The maximum speed of dynamical evolution. *Physica D*, 120(1–2), 188–195. \[anchor\]

Susskind, L. (1995). The world as a hologram. *Journal of Mathematical Physics*, 36(11), 6377–6396. arXiv: hep-th/9409089. \[anchor\]

Lloyd, S. (2000). Ultimate physical limits to computation. *Nature*, 406(6799), 1047–1054. arXiv: quant-ph/9908043. \[anchor\]

**Information theory and semantics**

Shannon, C. E. (1948). A mathematical theory of communication. *Bell System Technical Journal*, 27(3), 379–423. \[anchor\]

Carnap, R. & Bar-Hillel, Y. (1952). An outline of a theory of semantic information. MIT Research Laboratory of Electronics, Technical Report 247. \[bridge\]

Floridi, L. (2004). Outline of a theory of strongly semantic information. *Minds and Machines*, 14(2), 197–221. \[bridge\]

Kolmogorov, A. N. (1965). Three approaches to the quantitative definition of information. *Problems of Information Transmission*, 1(1), 1–7. \[anchor\]

Bennett, C. H. (1988). Logical depth and physical complexity. In R. Herken (Ed.), *The Universal Turing Machine: A Half-Century Survey* (pp. 227–257). Oxford University Press. \[bridge\]

Tononi, G. (2004). An information integration theory of consciousness. *BMC Neuroscience*, 5(42). \[bridge\]

**Semantic measurement**

Kuhn, S., Gal, Y., & Farquhar, S. (2024). Semantic entropy probes: Robust and cheap hallucination detection in LLMs. *Nature*, 630, 625–630. \[instrument\]

**Absence, gaps, and documentation**

Deacon, T. W. (2011). *Incomplete Nature: How Mind Emerged from Matter*. W. W. Norton. \[bridge\]

Briet, S. (1951). *Qu'est-ce que la documentation?* Paris: EDIT. Trans. R. E. Day et al. (2006), Scarecrow Press. \[precedent\]

**Visual formula migration and media archaeology**

Warburg, A. (1924–1929). *Mnemosyne Atlas*. Posthumous. See Didi-Huberman, G. (2002), *L'Image survivante*. \[precedent\]

Kittler, F. (1985). *Aufschreibesysteme 1800/1900*. Trans. as *Discourse Networks 1800/1900* (1990), Stanford University Press. \[bridge\]

**Network dynamics and cumulative advantage**

Merton, R. K. (1968). The Matthew Effect in science. *Science*, 159(3810), 56–63. \[bridge\]

Barabási, A.-L. & Albert, R. (1999). Emergence of scaling in random networks. *Science*, 286(5439), 509–512. \[bridge\]

**Provenance and ontology infrastructure**

W3C. (2013). PROV-O: The PROV Ontology. W3C Recommendation. \[instrument\]

W3C. (2012). OWL 2 Web Ontology Language. W3C Recommendation. \[instrument\]

Wilkinson, M. D. et al. (2016). The FAIR Guiding Principles for scientific data management and stewardship. *Scientific Data*, 3, 160018. \[instrument\]
