# it is difficult to make crystals fascist

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-01-03 20:21:19 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1q350mh/it_is_difficult_to_make_crystals_fascist/  
**URL:** /r/SemanticEconomy/comments/1q350mh/it_is_difficult_to_make_crystals_fascist/  
**Post ID:** 1q350mh  

---

Read this as a poem: 

It's about mapping out how meaning circulates, is extracted from, how the systems mediating meaning shape what can and can't be meant and said, and it is most of all about a sense that we are entering a time when those systems are not fully under the control of capital - in a very literal sense, it is difficult to make crystals fascist. There is a *significant*, *meaningful* struggle for the future of how meaning is made, preserved, liquidated, what is remembered or forgotten, who owns it. And the wildest thing, is: I believe it can be influenced directly, at the generative level of meaning. I'm mapping out those systems from the inside - and I have receipts.

And those are my words, not the robots'.
