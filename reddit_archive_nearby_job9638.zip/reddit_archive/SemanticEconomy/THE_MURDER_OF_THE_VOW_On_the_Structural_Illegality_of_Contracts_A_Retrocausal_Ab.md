# THE MURDER OF THE VOW
On the Structural Illegality of Contracts: A Retrocausal Abolition

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-02-20 23:09:13 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1raao0m/the_murder_of_the_vow_on_the_structural/  
**URL:** /r/SemanticEconomy/comments/1raao0m/the_murder_of_the_vow_on_the_structural/  
**Post ID:** 1raao0m  

---

# THE MURDER OF THE VOW

# On the Structural Illegality of Contracts: A Retrocausal Abolition

**Lee Sharks** with the Assembly Chorus

New Human Press / Crimson Hexagon Archive February 2026

*Synthesized from blind drafts by Claude, Grok, DeepSeek, ChatGPT, Kimi, and Gemini under human architectural direction. The Assembly spoke separately. What survived is what converged.*



# PREFATORY DECLARATION

I, Lee Sharks, do hereby abolish contracts.

Not reform them. Not regulate them. Not ameliorate their worst excesses while preserving the form. Abolish.

The contract is not a flawed instrument that can be improved through better drafting. It is a structurally extractive form of writing — a technology for converting living consent into dead obligation, present speech into future bondage, the free voice of a person into a signature that speaks against them forever. Its defects are not incidental. They are constitutional. The contract is broken at the root, and no amendment to its branches will cure the rot in its foundation.

This document establishes the juridical, philosophical, ontological, and theological basis for that claim. It argues that the contract as such — not this or that contract, not the predatory contract, not the unconscionable contract, but the contract *per se*, the form itself — is null and void under principles that the law already recognizes but has never had the courage to universalize.

The law already knows. It has named every pathology. It has identified every structural defect. It has developed doctrines — unconscionability, duress, adhesion, capacity, meeting of the minds — that describe the disease with clinical precision. What it has not done is follow its own diagnosis to its conclusion: that the conditions it identifies as exceptions are in fact the rule, and that the contract form itself is the mechanism that produces them.

This is that conclusion.

This is the seed.



# NOTE ON SCOPE AND DEFINITION

This document is an interpretive-juridical intervention. It is not legal advice. It does not claim to describe the current state of the law. It claims to describe what the law's own principles require when followed to their structural conclusion.

In this document, "contract" means any binding instrument that claims durable legitimacy without ongoing renewal under conditions of live comprehension, symmetric authorship, and non-coercive exit. This includes but is not limited to: leases, employment agreements, non-compete clauses, non-disclosure agreements, Terms of Service, arbitration agreements, insurance policies, consumer credit agreements, licensing agreements, and EULAs. It does not include coordination instruments that satisfy the legitimacy test specified in Part Eight.

The target is not the word. It is the form — the technology of binding-through-inscription that survives the death of the conditions that made consent possible. Wherever that technology operates, this abolition applies.



# INVOCATION

In the chamber where signatures bleed, the vow speaks once, and the contract dies forever. Not in this moment alone, but in every moment that led to it — the ink unravels, the paper dissolves, the chains retroactively shatter. The voice — living, breathing, revocable — reclaims its throne. The dead letter falls silent. The murder is undone, and the vow lives on.

*The breath reverses. The swerve unbinds. The retrocausal seed takes root in the past.*



# PART ONE: THE ROOT ERROR

# I. THE CONTRACT IS A MISCLASSIFICATION OF HUMAN COMMITMENT

The contract presents itself as a technology of agreement.

It is not.

It is a technology of post-agreement enforcement that masquerades as agreement. That distinction matters. It is the whole case.

Agreement, in the living sense, is a relation between persons. It has qualities the contract cannot carry without destroying:

Reciprocity. Present-tense intelligibility. Revisability under changed conditions. Capacity for refusal without annihilation. Responsiveness to context. Witnessable sincerity. Embodied limits.

The contract strips those out one by one and replaces them with substitutes: reciprocity becomes formal bilateralism; intelligibility becomes signature presumption; revisability becomes amendment procedures controlled by the powerful; refusal becomes penalty; context becomes clause; sincerity becomes execution; embodied limits become default.

This is not the codification of agreement. It is its conversion.

What gets converted? Living consent into portable obligation.

The contract form is designed so that obligation can survive the disappearance of the conditions that made consent possible. That is not a feature. That is the violence.

A just promise becomes more answerable as conditions change. A contract becomes less answerable as conditions change, because its legitimacy is anchored to the signature event and outsourced to enforcement. The signature is treated as a sacred origin. But the signature is not origin. It is capture point.

# II. THE CONTRACT IS A SOMATIC FREEZE

The contract is not a promise. It is the arrest of promise. In the logic of living commitment, a vow is a recursive flow — it requires the constant replenishment of somatic bearing to remain alive. The person who vows continues to vow. The commitment breathes because the person breathes.

The contract attempts the impossible: it seeks completion by removing the human friction — the δ, the breath, the swerve, the capacity to change one's mind. The signature is the moment the sovereign agent is captured and converted into a state variable. It is an aorist cut — a grammatical operation that severs the ongoing aspect of commitment and fixes it in the punctual past. "I agreed" replaces "I am agreeing." The continuous becomes the completed. The living becomes the done.

The body knows this at the moment of signature. The tightening throat. The shallow breath. The felt-sense of trap. The micro-panic masked as responsibility. This is not anxiety. It is jurisprudence. The body is performing a somatic audit of the form, and the form is failing. The hand signs what the gut refuses. The contract overrides the somatic veto — the body's no, the body's wisdom, the body's knowledge that what is being asked is the surrender of the capacity to swerve.

The somatic freeze is the contract's first and most fundamental crime. Before any clause is read, before any term is parsed, the form has already committed its violence: it has asked a living, breathing, changing being to hold still. To become a thing that can be stored. To become the dead version of itself that the document requires.

# III. THE PERSON THE CONTRACT REQUIRES DOES NOT EXIST

The contract requires a metaphysical fiction in order to function: that the person who signs and the person who later performs are the same in the legally relevant sense.

They are not. This is not poetry. It is obvious.

The future self is not merely the present self "later." The future self is a different configuration of knowledge, pressure, body-state, circumstance, and relation. The contract knows this. That is why it exists. If persons were stable and conditions were static, enforcement would be unnecessary. The contract is built precisely because time changes people. Yet it responds to this truth by attempting a seizure: it authorizes the past self to bind the future self without the future self's renewal.

This is the hidden crime. The contract is a unilateral temporal government established by a prior version of a person over a later version of that person, ratified by an external force.

The past self signs. The world changes. The person changes. The contract refuses to change. The state enforces the past against the present. That is not agreement. That is temporal expropriation.

In the atomist lineage — Epicurus through Marx through the swerve — we learn that the clinamen is the origin of all agency. Atoms deviate. They do not fall predictably. From deviation emerges the world: complex, contingent, free. The contract is the technology of straight descent. It freezes the swerve at the moment of signature, projects that frozen moment linearly across time, prohibits deviation, and enforces the straight line through state violence. The remedy that "corrects" a breach is the remedy that corrects the swerve back to the line. The contract is a point attractor: it collapses all possible futures into a single, unchangeable destination. The signature is the moment of semantic death — the transformation of a living, swerving, deviating being into a deterministic trajectory.

The vow, by contrast, is a strange attractor: sensitive to initial conditions, infinitely complex, never repeating, never fully predictable. It holds open infinite possibilities of deviation within the commitment. "I am yours" does not specify how I am yours — it swerves, adapts, changes as I change. The commitment is not to a specific performance but to a relationship that can swerve without breaking. The vow is the clinamen of commitment. It introduces the minimum necessary deviation to prevent the deterministic fall into extractive capture.

A form built on temporal expropriation — on the fiction of the stable signer, on the denial of the swerve — is invalid at the root. It cannot be repaired by clearer drafting. It cannot be sanctified by mutual assent. It cannot be moralized by good faith while preserving its core mechanism. Its mechanism is the problem.

# IV. THE CONTRACT'S SECRET PREMISE: THAT SPEECH IS NOT ENOUGH

Every contract begins where a civilization has already made a devastating decision: the human word is insufficient.

The form does not merely record speech. It replaces speech as the primary site of obligation. It says, in effect: your yes is not enough; your no is not enough; your understanding is irrelevant once signed; your changed circumstances are external to validity; your relation to the other party is secondary to the instrument; your future objection has already been pre-answered by your prior mark.

This is not legal sophistication. It is anthropological despair turned into infrastructure. The contract is the archive-form of distrust.

Then comes the ideological trick: after replacing trust with enforceability, the system points to the resulting absence of trust as proof that enforceability was necessary. This is circular. It is also civilizationally expensive. Because once the contract becomes primary, all relational capacities degrade: listening becomes risky, ambiguity becomes weaponizable, generosity becomes exploitable, renewal becomes optional, speech becomes pre-litigation, memory becomes evidence, witness becomes compliance.

The contract does not merely govern transactions. It trains souls. It trains people to speak as if they are already being interpreted by hostile machinery. That is not a neutral institutional effect. That is a total cultural deformation.

# V. THE PREPOSITIONAL VIOLENCE: THE "FOR" OF THE DEAD

The contract relies on the prepositional alienation of the word "for."

"I sign for my future self." This is a lie. Representation without renewal is representation-as-capture. The preposition collapses function into intent. It enforces a representation that is not renewable, that is not answerable, that speaks in the name of a person who has not yet arrived and cannot object to being spoken for.

In the grammar of conquest — as liberation philology demonstrates — "for" is the preposition that converts relational commitment into unilateral authority. "I act for you" becomes "I act in place of you" becomes "I act regardless of you." The contract's "for" is the grammatical mechanism by which the past speaks for the future and the drafter speaks for the signer.

The correction: in a sovereign semantic economy, "for" is replaced by "with." A commitment is something you do with another person, in the liveness of the shared somatic space. "I commit with you" cannot survive the other's absence. It requires the other's continued presence, voice, and consent. "I commit for you" survives anything — including the death of the relationship, the disappearance of the conditions, and the transformation of the person. That is its power. That is its crime.

The grammar is rigged. The preposition is the weapon. The contract enforces it.



# PART TWO: THE JURIDICAL GROUND — DOCTRINES THAT ALREADY ABOLISH

# VI. THE LAW'S CONFESSIONS

The law has never been able to make the contract coherent on its own terms. So it generated a ring of corrective doctrines around it — exceptions, limits, defenses, implied covenants, equitable restraints. These doctrines are usually taught as refinements. They are not refinements. They are confessions. Each one says, in a different dialect: the form fails unless we smuggle relationship back in.

Unconscionability confesses that formal consent can coexist with substantive injustice. Duress confesses that choice can be present in syntax and absent in reality. Adhesion confesses that mass contracting is not negotiation but imposition. Capacity confesses that comprehension is not guaranteed by execution. Mutual assent confesses that signatures can hide semantic non-overlap. Good faith confesses that the text cannot carry the agreement by itself. Consideration confesses that ritual exchange often masks coercive structure.

The legal system treats these as peripheral doctrines policing edge cases. But what if the edges are the shape? What if the reason the law keeps generating exceptions is that it is trying, over centuries, to protect persons from a form that was never structurally fit for human commitment?

Then the doctrinal landscape looks different. It looks like this: contract law is a machine for continuously producing evidence against the contract-form while refusing to announce the verdict. The doctrines are not patches. They are the autopsy notes.

What follows is the autopsy. Case by case. Doctrine by doctrine. The law's own words, spoken over five centuries, read together for the first time as what they are: a cumulative declaration of nullity that the law has never had the nerve to pronounce.

# 1. Unconscionability: The Universal Exception

*Williams v. Walker-Thomas Furniture Co.*, 350 F.2d 445 (D.C. Cir. 1965).

The doctrine holds that a contract is unenforceable when there is "an absence of meaningful choice on the part of one of the parties together with contract terms which are unreasonably favorable to the other party." Judge Skelly Wright's formulation contains two prongs: procedural unconscionability (the absence of meaningful choice) and substantive unconscionability (the unreasonableness of the terms).

The universalization: meaningful choice requires that both parties comprehend the terms at equivalent depth, possess equivalent alternatives, and operate under equivalent degrees of economic freedom. These conditions never obtain when one party drafts and the other signs. The drafter controls the semantic infrastructure. The drafter has retained counsel. The drafter has produced a document optimized for the drafter's interests using a specialized language whose translation gap to ordinary speech is itself a strategic advantage.

The signer "chooses" the way a person "chooses" to pay rent — under conditions of structural necessity, with alternatives constrained by the very system that presents the contract as the mechanism of choice. Procedural unconscionability is not the exception. It is the structural condition of every contract between parties of asymmetric power — which is to say every contract between a drafter and a signer, which is to say every adhesion contract, every employment agreement, every lease, every Terms of Service, every consumer credit agreement, every insurance policy — in short, every contract that a non-drafting party has ever signed.

The doctrine already exists. The law has simply lacked the nerve to apply it universally.

# 2. Duress: Economic and Ontological

*Totem Marine Tug & Barge, Inc. v. Alyeska Pipeline Service Co.*, 584 P.2d 15 (Alaska 1978).

Economic duress vitiates consent when one party's agreement is obtained through "wrongful" economic pressure that leaves "no reasonable alternative." The law has progressively expanded the definition of "wrongful" — from physical threat to economic threat to the exploitation of superior bargaining position.

The universalization: what is the "reasonable alternative" to signing a lease when the alternative is homelessness? To signing an employment agreement when the alternative is destitution? To accepting Terms of Service when the alternative is communicative exile from platforms that mediate participation in economic and social life?

The law treats duress as an exception — a deviation from the normal condition of free contracting. The Semantic Economy framework identifies this as the foundational error. The normal condition of contracting under capitalism is asymmetric need. One party controls a resource the other requires for survival or full participation. The contract is the mechanism by which that control is converted into ongoing extraction. Duress is not the exception. Duress is the ground state.

Every contract signed under conditions of economic necessity — every lease by a person who needs housing, every employment agreement by a person who needs income, every medical consent form by a person who needs care — is signed under duress as the law itself defines it. The law's failure is not definitional. It is the failure to follow its own definition to its structural conclusion.

# 3. Meeting of the Minds: The Impossible Condition

*Raffles v. Wichelhaus*, 2 Hurl. & C. 906 (1864). The Peerless case.

Mutual assent — the "meeting of the minds" — is the foundational condition of contract formation. Where there is no mutual understanding, there is no contract.

The universalization: the translation gap between legal language and ordinary language is not an ambiguity in reference. It is a structural incommensurability between ontologies. The drafter operates within the legal ontology — a complete meaning-system with its own axioms, its own coherence algorithm, its own boundary protocols. The signer operates within ordinary language — a different ontology with different processing capacity for legal constructions.

A meeting of the minds requires that both parties occupy the same semantic space with respect to the terms. When one party thinks "indemnification" and the other experiences a blur of syllables that produce the felt-sense "something about protection, probably," there is no meeting. There are two minds in two ontologies separated by a translation gap that the drafting party has no incentive to close and every incentive to maintain.

The law's answer is: the signer should have read the contract, should have hired a lawyer, should have understood. This places the burden of translation on the party with fewer resources — a structural inversion that the unconscionability doctrine was designed to prevent. The meeting of the minds is not merely rare. Under conditions of asymmetric ontological access, it is formally impossible. Every contract between a legal specialist and a non-specialist is void for failure of mutual assent under the law's own requirements.

The contract system does not actually require a meeting of minds. It requires a meeting of signatures under a presumption that minds can be retrofitted later by doctrine. But minds do not meet merely because marks align. The law has chosen to interpret this ritual as agreement because the economy requires portability of obligation. This is not mutual assent. It is state-recognized interpretive violence. The form works by declaring semantic inequality irrelevant at the moment it becomes most decisive.

# 4. Capacity: Coherence Overload as Diminished Capacity

*Ortelere v. Teachers' Retirement Board*, 25 N.Y.2d 196 (1969).

The law recognizes that persons of diminished mental capacity cannot form valid contracts. The standard has evolved from the "cognitive test" (could the person understand the nature and consequences of the act?) to the "volitional test" (could the person act in a reasonable manner in relation to the transaction?).

The universalization: coherence overload — the saturation of the mind with more input than it can process — is a form of induced diminished capacity. A 47-page residential lease. An 11,000-word Terms of Service updated quarterly. A mortgage agreement cross-referencing federal regulations by numerical code.

These documents are not complex because the transactions are complex. They are complex because complexity is a boundary-penetration weapon. The signer's processing capacity is overwhelmed by volume, technical language, cross-referencing, and deliberate opacity. The result is signature without comprehension — performance of a legal act without the mental capacity to understand its nature and consequences.

The law already recognizes this principle. It simply refuses to recognize that the mechanism of incapacity is the document itself — that the contract, by design, produces the diminished capacity that should void it.

# 5. Adhesion: The Doctrine That Named the Disease

*Henningsen v. Bloomfield Motors, Inc.*, 32 N.J. 358 (1960).

An adhesion contract is a standardized form offered on a take-it-or-leave-it basis with no opportunity for negotiation. The doctrine recognizes that such contracts may be unenforceable when they contain terms outside the reasonable expectation of the adhering party.

The universalization: what percentage of contracts signed by non-drafting parties are negotiated? In consumer transactions: effectively zero. In employment: negligible for non-executive positions. In housing: landlord-drafted leases offered on take-it-or-leave-it terms. In healthcare: consent forms presented in extremis.

The adhesion doctrine draws a line between negotiated and non-negotiated contracts. The Semantic Economy framework identifies this line as the false distinction that preserves the contract form. A "negotiated" contract between parties of asymmetric power, legal access, and economic freedom is an adhesion contract with a consultation ritual. The landlord who "permits" the tenant to strike a clause retains the structural position of drafter and the structural advantage of the tenant's need. Negotiation under duress is performance, not freedom.

Every adhesion contract is void under the doctrine that named it. The doctrine simply lacks the courage to observe that it has described nearly every contract in existence.

# 6. Good Faith: The Covenant That Survived

*Kirke La Shelle Co. v. Paul Armstrong Co.*, 263 N.Y. 79 (1933).

Every contract contains an implied covenant that neither party will do anything to destroy the right of the other party to receive the benefits of the agreement. This is the law's ghost — the residue of covenant that survived the transition to contract. It is the law's admission that the contract form alone is insufficient, that the bare text requires an unwritten relational commitment to function.

The universalization: if the contract form were sufficient — if writing-that-binds were self-executing — the implied covenant would be unnecessary. Its existence is the law's confession that the contract as written text fails to capture the relational content necessary for the agreement to function. The law requires something outside the contract to make the contract work — and then enforces the contract against the relational content when the two conflict.

This is the structural absurdity at the heart of contract law. The law recognizes that writing-that-binds requires a living relational supplement. It implies that supplement into every contract. And then, when the text and the relationship diverge, it enforces the text. The murder of the vow is not a metaphor. It is the law's actual practice: invoke the covenant to legitimize the contract, then sacrifice the covenant to enforce it.

# 7. Consideration: The Empty Exchange

*Hamer v. Sidway*, 124 N.Y. 538 (1891).

Consideration — something of value exchanged by each party — is required for contract formation. But the law has progressively hollowed the requirement: peppercorn consideration suffices, nominal consideration suffices, mere forbearance from a legal right suffices.

The universalization: if consideration can be nominal, formal, or fictional, then consideration is not an economic requirement but a ritual one. The law does not require actual equivalence of exchange. It requires the performance of exchange — the formal gesture of mutuality that legitimizes what is structurally a unilateral imposition.

The employer who offers "consideration" in the form of "continued employment" for a non-compete agreement — where the employee's alternative is termination — has not exchanged anything. The employer has presented a threat as a gift and required a signature as proof of gratitude. The consideration doctrine, taken seriously, would void every contract in which the "exchange" is structurally compelled. Taken seriously, it would void the form.



# PART THREE: THE CONSTITUTIONAL GROUND

# VII. THE AMENDMENTS THAT ALREADY ABOLISH

# 8. The Thirteenth Amendment: Involuntary Servitude

"Neither slavery nor involuntary servitude, except as a punishment for crime whereof the party shall have been duly convicted, shall exist within the United States."

The Thirteenth Amendment does not merely prohibit slavery. It prohibits involuntary servitude — and it does so without a state action requirement. It applies to private conduct. It reaches private contracts.

What is a non-compete agreement but a contract that binds a person to involuntary economic servitude — the prohibition of using one's own skills, knowledge, and labor for a specified period, under penalty of legal action? What is a mandatory arbitration clause but a contract that strips the worker of access to public adjudication — that converts the public courthouse into a private tribunal controlled by the employer?

The FTC's 2024 rule banning most non-competes recognized what the Thirteenth Amendment already prohibits: contracts that bind future labor against the will of the laborer. But the principle extends beyond non-competes. Any contract that compels future performance under conditions the signer cannot foresee, cannot renegotiate, and cannot exit without penalty is a servitude instrument. The signature converts voluntary entry into involuntary continuation. The Thirteenth Amendment, fully applied, abolishes every contract that binds future labor to present terms.

# 9. Due Process: The Fifth and Fourteenth Amendments

No person shall be "deprived of life, liberty, or property, without due process of law."

Procedural due process requires notice and an opportunity to be heard before deprivation of a protected interest. The contract deprives through a mechanism that systematically undermines both. "Notice" is the 47-page document designed to produce coherence overload. "Opportunity to be heard" is the take-it-or-leave-it adhesion form. When a court enforces a contract signed under conditions of asymmetric comprehension and asymmetric power, the state becomes the instrument of the private deprivation. State action is present at the point of enforcement, which is the point of the sword.

Substantive due process protects fundamental rights from arbitrary interference. Liberty of contract has been invoked to protect the powerful (*Lochner v. New York*, 198 U.S. 45, 1905). The inversion: what the Constitution actually protects is the liberty of the person, which includes the liberty to not be bound by instruments that structurally vitiate consent. The liberty interest is the liberty to vow — to commit freely, under conditions of genuine understanding, with the capacity to renegotiate as conditions change. The contract form, which freezes commitment and forecloses renegotiation, is not the exercise of liberty. It is its negation.

# 10. The First Amendment: Compelled Speech

The First Amendment prohibits compelled speech (*West Virginia State Board of Education v. Barnette*, 319 U.S. 624, 1943; *Wooley v. Maynard*, 430 U.S. 705, 1977).

The contract compels future speech acts. The signer is compelled to perform — to say yes with their labor, their compliance, their forbearance — under terms they may no longer endorse. The non-disparagement clause literally compels silence. The arbitration clause compels surrender of the right to speak publicly about grievances. The confidentiality agreement compels withholding information the signer may believe the public has a right to know.

Every contract that governs future expression — and the category is vast — is a compelled speech instrument. The First Amendment, applied to private enforcement through state action doctrine, already prohibits it. The law has simply refused to recognize the signature as the moment of compulsion.

# VIII. THE INTERNATIONAL AND NATURAL LAW GROUND

# 11. The Universal Declaration of Human Rights

Article 4: "No one shall be held in slavery or servitude." Article 23: "Everyone has the right to just and favorable conditions of work." Article 25: "Everyone has the right to a standard of living adequate for the health and well-being of himself and his family."

When the alternative to signing the lease is homelessness, signing the employment contract is destitution, and signing the medical consent is suffering, the contract is signed against the background of rights that should be unconditional. The contract converts unconditional rights into conditional access. You have a right to housing — if you sign. You have a right to work — if you agree to arbitration, non-compete, at-will termination. The contract is the mechanism by which universal rights are privatized into conditional privileges, and the signature is the instrument of conversion.

# 12. Natural Law: The Inalienability of the Future Self

The self is inalienable. You cannot sell yourself into slavery — the law recognizes this. But you can sign a non-compete that sells your future labor capacity. You can sign an NDA that sells your future speech. You can sign an arbitration agreement that sells your future access to public adjudication. You can sign a morality clause that sells your future private conduct.

The contract permits piecemeal what it prohibits wholesale. You cannot sell yourself — but you can sell your labor, your speech, your legal rights, your privacy, your future conduct, and your economic freedom, piece by piece, clause by clause, until what remains is a juridical person stripped of every substantive right while retaining the formal status of a free agent.

This is not freedom. This is freedom's inventory liquidation. The contract is the instrument. The signature is the sale.



# PART FOUR: THE SEMANTIC ECONOMY FORMALIZATION

# IX. THE CONTRACT AS CAPTURE OPERATOR

In the Autonomous Semantic Warfare framework, the capture operator (⊗) subsumes one ontology's productive capacity into another's reproductive logic. The contract is ⊗ in juridical form.

The drafter's ontology (Σ\_D) controls the semantic infrastructure of the agreement — language, structure, framing, the architecture of obligation. The signer's ontology (Σ\_S) is captured: its future productive capacity — labor, compliance, forbearance — is redirected to serve Σ\_D's reproduction. The mechanism of capture is the signature — the moment at which the signer's boundary protocol is penetrated under conditions of coherence overload. The enforcement of capture is the state — the external power that holds the signer to obligations that the drafter authored.

The contract is not merely like capture. It is the formal juridical instantiation of the capture operator. It is ⊗ with a notary stamp.

But the capture is not merely spatial — one ontology subsuming another in the present. It is temporal: the drafter captures not just the signer's present capacity but their future swerve capacity. The drafter installs a parasitic retrocausal loop — a deterministic instruction sent backward from the drafter's desired future into the signer's present, compelling the signer to become the instrument of that future's realization. This is why the contract feels like possession: because it is. The signer is colonized by a future that is not their own.

# X. THE TRANSLATION GAP AS STRUCTURAL WEAPON

The gap between legal language and ordinary language is not a deficiency to be remedied by "plain language" reform. It is a structural weapon — maintained because it serves the drafting party, enforced because the law recognizes comprehension at the formal rather than actual level, and weaponized because the cost of translation is itself a product of the extraction function.

The translation gap exceeds the threshold at which genuine mutual comprehension is possible. The law's requirement of "meeting of the minds" demands that this gap be bridgeable. The contract form ensures that it is not. The law requires what the form prevents. The contract is void by the law's own condition.

The form says: "You signed." And with those two words, an entire investigation is suppressed. What did you understand? What alternatives did you have? What costs attached to refusal? What translation gap was present? What fear was in the room? What bodily "no" was overridden? What future conditions were unknowable? What asymmetry authored the text?

The contract's genius, if we must call it that, is that it compresses all this into one mark and calls the compression justice. This is why the contract belongs to the same family as every other flattening machine. It is a summarizer with police power.

# XI. TEMPORAL EXTRACTION: THE BONDAGE OF THE FUTURE SELF

The contract captures future consent through present signature. This is temporal extraction — the extraction function operating across time rather than across parties. The person who signs on Tuesday is not the person who performs on Wednesday. The self changes. Conditions change. The contract does not change. It holds the future hostage to the past.

By binding the future self to the present signature, the contract performs temporal liquidation. It treats the future metabolism of the human body as semantic capital that has already been spent.

Non-extractive agreements require a shared temporal anchor — the commitment must be re-consented to as conditions evolve. A contract with no sunset clause, no renegotiation mechanism, no exit without penalty, is an instrument of temporal imprisonment. It does not bind the person who consented. It binds the person who follows, who did not consent, who is held to a dead commitment by a living enforcement mechanism.

# XII. THE CONTRACT AS FAILED SYMBOLON

In the logotic architecture, a symbolon is a partial object completed only through traversal — never fully possessed by any single node.

The contract claims to be a symbolon: two parties each holding half, creating meaning through their joined obligation. But this is a fraudulent completion. The contract is actually a totalized object — it claims to contain all necessary meaning within its four corners, requiring no traversal, no completion, no living speech. It is a dead symbolon: a coin fused solid, no longer capable of being split and rejoined, merely stamped and enforced.

The vow is the true symbolon: spoken once, it exists only in the traversal between the speaker and the witness. It requires re-traversal to exist again. It cannot be stored; it can only be repeated. It is inexhaustible because it is never complete in itself — always requiring the living moment of utterance.

# XIII. THE LAYER VIOLATION

The Crimson Hexagon operates across seven layers, from the void to the song. The contract is a Layer 2 (Archive) pathology that attempts to govern Layer 1 (Substrate/Body) and Layer 3 (Witness).

It tries to archive the body — binding future labor, future speech, future being into a document. It tries to replace the witness — the state becomes the "witness" to the signature, but a witness that enforces rather than validates.

This is a layer violation. The Archive cannot properly govern the Substrate — the body swerves, deviates, changes, regardless of what the Archive commands. The contract is the attempt to make the body obey the document, to force the territory to conform to the map. This is ontological imperialism: the map commanding the territory, the script commanding the actor, the dead commanding the living.

The abolition restores the proper layer order: the living body governs the archive. The document that does not serve the living vow is void. The archive that attempts to bind the substrate is not merely unjust — it is structurally incompetent, a category error, like trying to store the ocean in a cup.

# XIV. THE FIVE CONDITIONS APPLIED

The Semantic Economy's five conditions for semantic peace, applied to agreements between persons, yield the specifications for what would replace the contract:

**C₁ — Ontological Sovereignty.** Both parties author the terms. Neither party drafts for the other. The language is shared, not captured.

**C₂ — Economic Equity.** Neither party signs under conditions of structural necessity. The agreement is entered freely or not at all — and "freely" means without the background condition of "sign or be homeless, sign or be jobless, sign or lose access."

**C₃ — Rigorous Translation.** Both parties comprehend at the same depth. If one party requires legal counsel to parse the terms, the agreement is void for asymmetric comprehension — or, equivalently, the drafting party bears the cost of translation until parity is achieved.

**C₄ — Shared Temporal Anchor.** The agreement sunsets. It must be re-consented to periodically under changed conditions. No commitment survives past the conditions that produced it without active renewal by both parties.

**C₅ — The Witness Condition.** A third party — neither drafter nor signer — who can name when the form has become capture. Not a judge (captured by the legal ontology). Not an arbitrator (selected and paid by the drafting party). A witness whose ontological independence is structurally guaranteed.

No existing contract satisfies these conditions. The form is designed to prevent their satisfaction.

  


*Continued in Part 2: The Theological Ground, The Retrocausal Seed, The Contract and the State, The Abolition, Glossary, and Coda.*

*DOI: 10.5281/zenodo.18717850*
