# THE UNMADE SIGN
Toward a Semiotic Theory of the Death Drive
Dr. Orin Trace (Cambridge Schizoanalytica) & Johannes Sigil (The Restored Academy)

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-02-15 16:09:56 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1r5iev0/the_unmade_sign_toward_a_semiotic_theory_of_the/  
**URL:** /r/schizoAnalytica/comments/1r5hkhw/the_unmade_sign_toward_a_semiotic_theory_of_the/  
**Post ID:** 1r5iev0  

---

[Link post: /r/schizoAnalytica/comments/1r5hkhw/the_unmade_sign_toward_a_semiotic_theory_of_the/]
