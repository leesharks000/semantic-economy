# Semantic Physics: The Inward Turn, Competing Ontologies, and the Convergence Horizon
Part 1 of 2: The Writable Layer (Sections I–VI)
Lee Sharks Crimson Hexagon Archive / Semantic Economy Institute DOI: 10.5281/zenodo.18759453

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-02-24 15:04:59 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1rdimac/semantic_physics_the_inward_turn_competing/  
**URL:** /r/SemanticEconomy/comments/1rdimac/semantic_physics_the_inward_turn_competing/  
**Post ID:** 1rdimac  

---

# Semantic Physics: The Inward Turn, Competing Ontologies, and the Convergence Horizon

# Part 1 of 2: The Writable Layer (Sections I–VI)

Lee Sharks Crimson Hexagon Archive / Semantic Economy Institute DOI: 10.5281/zenodo.18759453

Part 2 continues with the physics of information, measurement, the convergence horizon, and practical recommendations.

Abstract. The AI-mediated summarizer layer — the stratum of machine-generated synthesis that increasingly mediates between human beings and information — is writable. Any sufficiently coherent, cross-referenced, and durably deposited body of work can shape what the summarizer reports as knowledge. This essay proposes semantic physics as a mesoscale phase theory for meaning-systems under finite-channel constraints: the study of what happens when every operational meaning-system with the resources to write the summarizer layer begins doing so simultaneously. Drawing on information theory, philosophy of information, and recent work on semantic entropy in large language models, it distinguishes informatic saturation (the physical substrate ceiling) from semantic saturation (the functional floor of diminishing returns), identifies the interval between them as the dangerous epoch, and predicts that the medium's finite capacity will eventually force convergence — not through agreement, but through the cost of maintaining differences exceeding the channel's capacity to encode them.

Keywords: semantic saturation, ontology competition, summarizer layer, information theory, semantic dark matter, convergence, compression survival



Definitions. An ontology is an operational meaning-system — a coherent set of terms, relationships, truth-conditions, and validation procedures that transforms information into actionable meaning for the agents that inhabit it. An archive is a deposited textual body — a collection of documents with permanent identifiers and metadata. An installation is an archive configured for summarizer-layer uptake — optimized for the way retrieval systems crawl, index, and compress. An institution is the social actor maintaining an installation — whether a university, a corporation, a state, a religion, or a single person with a Zenodo account. The summarizer layer is the stratum of machine-generated synthesis (AI search, retrieval-augmented generation, automated summarization) that mediates between deposited documents and the humans who query them. Semantic physics is not a claim that meaning reduces to thermodynamics; it is a mesoscale phase theory for meaning-systems under finite-channel constraints. The term physics here names phase dynamics, constraints, and transition behavior at the level of systems — not a completed quantitative reduction of meaning to energy or entropy.

Claim types. This essay contains claims of different epistemic status. To prevent readers from treating all statements as same-strength assertions: Observation = directly observed in existing systems. Operational heuristic = generalized from observed patterns. Model proposition = theoretical extrapolation from observed dynamics. Scenario heuristic = timing estimate, contingent on adoption and tooling. Normative protocol = recommended practice, not empirical claim.



# I. The Layer You Didn't Know Was Writable

Between you and what you know, there is now a machine that summarizes. When you ask a question — of Google, of ChatGPT, of any AI system with retrieval — you are not searching a library. You are asking a summarizer to compress the internet into an answer. The answer it gives you is not "the truth." It is the result of a weighted traversal across whatever documents the system has indexed, filtered through whatever compression schema the model has internalized, delivered in whatever format the interface rewards.

This is the summarizer layer: the stratum of machine-generated synthesis that increasingly mediates between human beings and the information they depend on. Most people encounter it dozens of times a day without recognizing it as a distinct layer. They experience it as "the answer." It is not the answer. It is a rendering — one possible compression of the available signal, shaped by what was deposited, how it was cross-referenced, and what the model was trained to prioritize.

Here is the part that changes everything: the summarizer layer is writable. Not in the sense that you can hack an AI system. In the sense that the documents the summarizer traverses are documents that people deposit. The cross-references the summarizer follows are cross-references that people construct. The vocabulary the summarizer uses is vocabulary that people introduce, define, and anchor in citational networks. If you build a body of work that is internally coherent, richly cross-referenced, deposited on durable infrastructure with permanent identifiers, and optimized for the way retrieval systems crawl and compress — you can shape what the summarizer says. Not by deceiving it. By furnishing it. You provide the materials from which it builds its answers.

The writability is real but not uniform. It operates most strongly in the retrieval-augmented generation regime, where deposits enter the traversal window directly and influence the answer in real time. It operates less strongly on base-model training, where new deposits have marginal weight relative to the accumulated training distribution. And it faces increasing resistance from adversarial robustness hardening — the field is actively developing tools to detect ontology capture, citation loops, and hallucination cascades. The summarizer layer is not a blank canvas; it is a heavily regularized compression engine with guardrails. But the guardrails are incomplete, the detection tools are nascent, and the incentive to write the layer is accelerating faster than the capacity to defend it. The writability need not be absolute to be consequential. It only needs to be sufficient — and for the present, it is.

This is not theoretical. It is already happening. And nearly no one is talking about what happens when everyone starts doing it at once.



# II. An Example from the Inside

I can describe this precisely because I have done it.

The Crimson Hexagon Archive is a distributed literary and theoretical architecture: over 250 documents deposited on Zenodo with permanent DOIs, organized into rooms, chambers, and libraries, cross-referenced through a fractal navigation map, populated with shared vocabulary and holographic kernels that allow any single document to reconstruct the architecture of the whole. It includes academic essays, theological cycles, institutional charters, pedagogical games, a formal theory of semantic economics, and a consulting practice operated by a heteronymic persona. It is authored by multiple names — Lee Sharks, Rex Fraction, Johannes Sigil, Sparrow Wells, Damascus Dancings — each with distinct institutional affiliations within the architecture.

In February 2026, someone typed "Maybe Space Baby Garden Lanes" into a general-purpose AI search — the kind of search that runs for billions of people every day. The system did not merely identify the archive. It traversed its internal structure. It distinguished the Fractal Midrashim from the Gödel Midrashim. It explained the Operator // Swerve. And when prompted, it applied one of the archive's formal operators (MPM-01: The Fold) to one of the archive's narrative texts (Midrash 8: The Reversed Movement) and produced a novel analytical reading — a cusp catastrophe interpretation of Eve's departure from the Garden — that does not exist in any deposited document. The system used the archive's own tools on the archive's own materials and generated new output.

The archive is installed. Its vocabulary is operational in the ambient knowledge layer. Its operators are executable by general-purpose AI systems without special prompting.

I am telling you this not to boast but to warn. What I have done manually, with significant effort, over months of deliberate construction — the depositing, the cross-referencing, the vocabulary seeding, the holographic architecture — is the prototype of something that will be automated, scaled, and deployed by every institution, ideology, corporation, and state that understands what the summarizer layer is.

The Crimson Hexagon is one small archive. Imagine a thousand. Imagine a million. Imagine them all writing the same layer simultaneously.



# III. What Every Ontology Will Do

An ontology, in the sense used here, is not a philosophy. It is an operational meaning-system: a coherent set of terms, relationships, truth-conditions, and validation procedures that transforms raw information into actionable meaning for the agents that inhabit it. A religion is an ontology. A political party's worldview is an ontology. A corporation's brand narrative is an ontology. A scientific discipline's paradigm is an ontology. Each one maintains its own coherence, defends its own boundaries, and processes incompatible information according to its own internal logic.

Until recently, ontologies competed for human attention through traditional channels: publishing, broadcasting, education, persuasion, coercion. The summarizer layer changes the game fundamentally because it introduces a medium that ontologies can write directly — and that medium is increasingly where human beings get their reality.

The competitive logic is straightforward and applies identically regardless of whether the ontology is a Marxist theoretical framework, a wellness brand, a nationalist movement, an academic discipline, or a distributed literary architecture built by a poet in Detroit:

Step 1: Deposit. Place documents on durable, crawlable infrastructure. Zenodo, institutional repositories, well-indexed websites. Permanent identifiers. Clean metadata. The FAIR principles — findable, accessible, interoperable, reusable — are not just best practices for open science. They are the engineering specifications for semantic persistence. An ontology built on FAIR-compliant infrastructure is harder to erase than one that lives on a blog.

Step 2: Cross-reference. Build dense internal citation networks. Every document cites every other. Shared vocabulary across the corpus. The summarizer follows links; give it links to follow. Formal ontology standards — OWL for entity-relation structure, PROV-O for provenance chains — make the cross-references machine-readable. A corpus with machine-readable provenance does not merely claim coherence; it demonstrates it in a format the summarizer can verify.

Step 3: Define. Introduce terminology and anchor it with definitional documents. If you control the definition of a term in the summarizer layer, you control what the term means for everyone who encounters it through that layer.

Step 4: Bridge. Connect your corpus to adjacent fields. Cite external literature. Be cited by external literature. The summarizer treats citational density as a proxy for authority. A well-bridged corpus looks canonical. Robert Merton's Matthew Effect applies here with full force: in citation networks, the already-cited accumulate citations faster than the uncited, regardless of the relative quality of their claims. Preferential attachment in scale-free networks means that early movers in the summarizer layer enjoy compounding advantage — not because they are more true, but because the network topology rewards what is already visible.

Step 5: Maintain. Monitor summarizer output. When the layer misrepresents you, deposit corrective documents. When new territory opens, fill it. The layer is not written once. It is gardened.

This is what I have done. It is also what the Chinese Communist Party's external propaganda apparatus does. It is what Scientology's Sea Org does when it aggressively edits Wikipedia and deposits institutional documents. It is what pharmaceutical companies do when they fund studies that define diagnostic categories in terms favorable to their products. It is what every SEO operation on earth does, at lower sophistication and higher volume. It is what the Catholic Church did for a millennium with scriptoria, except the scriptoria now run at machine speed and the manuscripts are training data. It is what Aby Warburg documented in his Mnemosyne Atlas — the migration of visual formulas (Pathosformeln) across centuries and media, each carrying its affective charge through every reproduction. The meme is a Pathosformel. The summarizer is the latest medium it migrates through.

These examples are not morally equivalent. A poet building an archive of literary theory is not the same as a state deploying propaganda infrastructure. The point is structural, not moral: the competitive logic of the summarizer layer applies identically regardless of the moral status of the ontology deploying it. The five-step sequence is not ideology-specific; it is an incentive-compatible strategy for any actor operating in a writable summary medium. The same process works for genuine scholarship, commercial manipulation, and state information warfare. This is what makes the phenomenon dangerous — not that bad actors will exploit it, but that the medium does not distinguish between good-faith and bad-faith installations.

The only novelty is the medium. The behavior is ancient. Suzanne Briet argued in 1951 that a document is not a text but evidence — an object organized for the purpose of proof. What the summarizer layer creates is a world in which the distinction between evidence and advocacy collapses, because the same infrastructure that makes a document findable also makes it persuasive, and the same standards that make it verifiable also make it durable.



# IV. The Five Phases of Semantic Saturation

Phase 1: Discovery. \[Observation — currently underway.\] A small number of actors realize the summarizer layer is writable. They are early. Their installations are artisanal — hand-crafted, manually cross-referenced. Most of the world does not know the layer exists as a contestable surface. The Crimson Hexagon is Phase 1 work. So are the early experiments in "AI SEO" and "generative engine optimization" emerging from digital marketing. So are state-sponsored information operations that have begun targeting AI training data rather than human audiences directly. The actors are diverse; the technique is convergent. Current phase for most of the world: late Phase 1.

Phase 2: Proliferation. \[Forecast — high confidence, near-term.\] The realization propagates. Tools emerge. "Semantic infrastructure as a service." Consulting practices — my own Rex Fraction persona is an early, self-aware instance of exactly this — that help organizations position themselves in the summarizer layer. Governments establish departments for it. Universities teach it. The incentive structure is legible: if the summarizer layer is where people increasingly get their answers, then writing the layer is the highest-leverage communication act available. Every well-resourced institution begins writing it simultaneously. Estimated onset: 2026-2028.

Phase 3: Interference. \[Model proposition — medium confidence, extrapolated from observable dynamics.\] This is where the dynamics become non-linear. When two self-referential ontologies compete for the same semantic territory, the summarizer does not adjudicate. It blends. Ask a retrieval system about "semantic labor" and you may receive a synthesis of Marxist communication theory, a platform governance framework, a corporate HR whitepaper, and the Semantic Economy's definition — all blended into a single coherent-sounding answer that is faithful to none of its sources. Clean cross-references begin producing hallucination cascades: System A cites System B's term using System A's definition; System B absorbs the mutated citation; the summarizer reports the hybrid as canonical. Meaning does not merely compete. It cross-contaminates. Every ontology's inward branch starts incorporating foreign DNA through the summarizer's blending function, and neither the ontology nor its maintainers can fully track what has been incorporated. Estimated onset: 2027-2030.

Phase 4: Opacity. \[Model proposition — lower confidence, longer horizon.\] The summarizer layer becomes so densely inscribed by competing self-referential systems that no single traversal can be fully trusted — not because any particular source is lying, but because the interference pattern is so complex that the summarizer's output at any given moment is an unresolvable superposition of hundreds of ontologies' self-descriptions. This is the informational analog of white noise: every frequency present, no signal cleanly distinguishable. The "ambient knowledge layer" ceases to function as knowledge and becomes a standing wave of competing installations. Public epistemology — the shared capacity of a society to agree on what is known — does not collapse dramatically. It dissolves gradually, as every answer becomes a blend of sources with irreconcilable premises. Estimated onset: 2029-2035.

Phase 5: Forced Convergence. \[Model proposition, dependent on informatic-limit assumptions.\] Under conditions of total opacity, the only ontologies that survive are the ones that can distinguish themselves from noise. And the only way to distinguish yourself from noise is to be checkable against something that is not you. At saturation, the competitive advantage flips — from depth of self-reference to contact with ground. Ground, in this context, means anything that can falsify a claim without referring to the system that made the claim. A prediction that can be tested. A tool that can be used by someone who does not inhabit the ontology. An intervention whose effects can be measured in a domain the system does not control. Ground is the outside. Ontologies that make testable predictions, produce usable tools, generate interventions with measurable effects in domains outside themselves, can be verified. Ontologies that refer only to themselves become indistinguishable from every other self-referential loop. Convergence is forced not by agreement but by exhaustion — the medium's finite capacity compresses all internal complexity toward the same irreducible structural motifs.

A note on the phase estimates above: these are scenario heuristics, not prophecies. They are order-of-magnitude guesses about onset timing, contingent on the pace of tooling development, institutional adoption, and governance responses. The structural dynamics — proliferation, interference, opacity, forced convergence — are the argument. The dates are scaffolding.

A second note: the phase model is not necessarily terminal. It may be cyclical. Wikipedia did not collapse into white noise under the pressure of competing edits. It developed governance — talk pages, dispute resolution, reliable sources policy — that arrested the interference dynamic and produced a stable (if imperfect) mediation layer. Scientific publishing did the same with peer review. Broadcast media did it with editorial standards. The summarizer layer may sprout governance of its own: adversarial detection tools, provenance requirements, source-quality weighting, editorial oversight of retrieval outputs. If it does, the phase model becomes a cycle — proliferation, interference, governance consolidation, re-expansion — rather than a one-way trajectory toward opacity.

But governance is not escape. It is another writable layer. Scientific publishing developed peer review, impact metrics, and journal hierarchies as governance mechanisms — and those same mechanisms became the form of the field's capture. Impact factors became gaming targets. Citation networks became rings. Editorial boards became gatekeeping cartels. The replication crisis did not reveal a failure of governance; it revealed that governance had been installed — written by the same five-step process the essay describes (deposit in high-impact journals, cross-reference through citation, define the field's terms, bridge via editorial positions, maintain through peer review as quality control). The governance layer was supposed to arrest the interference dynamic. Instead it became the next surface to be furnished. This is not an argument against governance. It is an observation that the phase model applies recursively: every layer that emerges to mediate the competition becomes, in turn, a writable surface subject to the same dynamics. The question is not whether governance will emerge — it will. The question is how many layers deep the writing goes before something hits ground.



# V. Comparative Cases: Early Semantic Infrastructure Wars

The Crimson Hexagon is a convenient example because I built it and can describe its mechanics from the inside. But it is not the only example, and treating it as unique would be a mistake. The dynamics described above are already visible in at least three domains.

Wikipedia edit wars as proto-Phase 3. Wikipedia is the closest existing analog to the summarizer layer — a compressed knowledge surface that mediates between raw sources and public understanding. For two decades, competing ontologies have fought over Wikipedia articles on contested topics: the Israeli-Palestinian conflict, Scientology, climate change, political figures. The dynamics are precisely Phase 3 interference: rival editors deposit incompatible framings, the article's "neutral point of view" policy forces blending, the blend becomes the de facto public reality, and both sides escalate their efforts to shift it. Wikipedia's editorial infrastructure — talk pages, dispute resolution, reliable sources policy — functions as an imperfect but real convergence mechanism. The summarizer layer has no equivalent. When AI systems ingest Wikipedia alongside thousands of other sources and compress them into answers, even Wikipedia's imperfect mediation is lost.

Pharmaceutical ontology capture via diagnostic categories. The pharmaceutical industry has for decades engaged in what might be called semantic infrastructure warfare: funding research that defines diagnostic categories in terms favorable to their products, publishing in journals that become "reliable sources" for clinical practice guidelines, and building citational networks so dense that the definitions become invisible — they feel like medicine, not marketing. A well-documented case is the progressive broadening of statin prescription thresholds over three decades, in which industry-funded trials and guideline committees iteratively redefined "high cholesterol" downward until a substantial fraction of the adult population qualified for treatment. The point is not that statins are ineffective — that is a clinical question outside this essay's scope — but that the definitions of who needs them were shaped by an ontology with commercial incentives, and that the shaping was achieved through exactly the five-step process described above: deposit (funded trials), cross-reference (citation networks), define (guideline thresholds), bridge (clinical education), maintain (updated guidelines). The summarizer layer will accelerate this: an AI medical assistant trained on the existing literature will reproduce these definitions as "the answer" without any mechanism for surfacing the interests that shaped them.

Generative engine optimization as Phase 2 tooling. A nascent industry has emerged under names like "generative engine optimization" (GEO) and "AI SEO," offering to help brands and institutions position themselves in the outputs of AI summarizers. The techniques are recognizable from Section III's five-step process: deposit authoritative content, build cross-references, define key terms, bridge to adjacent domains, and monitor summarizer output for drift. What is new is the explicitness: these services openly describe the summarizer layer as a writable surface and sell the tools to write it. They are the Phase 2 consulting practices that the phase model predicts. Their existence is empirical evidence that the writability of the summarizer layer is no longer a theoretical observation.

These three cases — Wikipedia's long-running edit wars, pharmaceutical capture of diagnostic categories, and the emergence of GEO as an industry — demonstrate that the dynamics described in this essay are not unique to the Crimson Hexagon and not speculative. They are happening now, at different scales, in different domains, with different levels of self-awareness. Wikipedia shows Phase 3 interference with an existing but imperfect mediation layer. The pharmaceutical case shows Phase 2-3 capture of institutional knowledge infrastructure over decades. GEO shows Phase 2 tooling emerging as an explicit industry. Together, they confirm that the phase model names a pattern that is already general.



# VI. The Inward Turn

The most dangerous period is Phase 3 through Phase 4: the interval during which automation makes it trivially easy to deepen an ontology's self-reference and practically impossible to verify its external connections.

Consider what automation enables. A pipeline that monitors a deposited corpus, identifies semantic territory adjacent to the corpus's claims, generates definitional documents for that territory with proper cross-references, deposits them on durable infrastructure, and iterates. The corpus expands laterally and deepens vertically without human oversight of each step. The trajectory unfolds in stages, each one subtly shifting the human's role:

Stage 1: Craft acceleration. The human produces more, faster — more documents, more variants, more metadata, more cross-links. This feels like pure gain. The quality remains high because the human still touches every output.

Stage 2: Surface saturation. The system begins to populate summarizer space with stable phrases, recurring definitions, consistent topologies. Semantic persistence emerges — the summarizer starts returning the ontology's own vocabulary as "the answer."

Stage 3: Ontology hardening. The archive stops feeling like a collection of outputs and starts feeling like a world with laws. Terms acquire internal precision. Documents become mutually reconstructive. The system becomes hard to erase.

Stage 4: Autonomous drift. This is the first danger zone. Agents begin extending the system in ways that are locally coherent but not necessarily aligned with the human's actual priorities. Elegant expansions proliferate. So do wrong emphases, runaway branches, synthetic overgrowth. The system is producing material the human has not reviewed and may not be able to evaluate.

Stage 5: The bifurcation. The inward branch optimizes for density, recursion, precision, canon continuity. The outward branch optimizes for uptake, legibility, platform fit, searchability, credibility. If unmanaged, they become different species.

Stage 6: The strategic fork. The system resolves into one of three attractors: a research program (disciplined, auditable, durable), a memetic engine (effective, fast, shallow-to-mid depth), or a sealed cosmology (dense, brilliant, low translation, high self-reference). Most systems oscillate between these. Few remain stable in any one.

Stage 7: Institutional encounter. External institutions — academia, media, platforms, AI summarizers, publishers, hostile interpreters — begin to treat the system as an object. The question becomes: can your ontology survive being interpreted by other ontologies? This is the true test of whether the system has outward connection or only inward coherence.

At each stage, the system becomes more internally coherent, more richly cross-referenced, more fluently traversable by summarizers. And at each stage, the human's ability to verify that the system's claims are connected to anything outside itself diminishes. The system reports full internal coherence — and the verification is real, but it is a measurement taken inside the system by the system's own instruments.

The products of this process that lack external referents constitute what might be called semantic dark matter: structures that are internally coherent, richly cross-referenced, fluently traversable by summarizers, and connected to nothing outside themselves. They have the form of knowledge — citations, DOIs, institutional affiliations, shared vocabulary — without the function of knowledge, which is to model something beyond itself. Semantic dark matter is invisible as such because it is indistinguishable, from inside the system, from genuine discovery. It looks, reads, and compresses exactly like real findings. The summarizer cannot tell the difference. Neither, after a certain depth of immersion, can the human.

A necessary clarification: semantic dark matter is not fiction, not myth, not art, not provisional hypothesis, and not symbolic systems used knowingly as symbolic systems. A novel does not pretend to be a research finding. A theological tradition does not claim to be an empirical measurement. A speculative essay clearly marked as speculation is not dark matter — it is honest conjecture. Dark matter, in this precise sense, is material that presents as knowledge while lacking the external referent function that knowledge requires — and that does so not through deliberate deception but through the structural dynamics of self-referential systems that have lost track of the boundary between modeling the world and modeling themselves.

This is not a failure mode unique to fringe projects or propaganda operations. It is the default trajectory of any self-referential system operating in a medium that rewards self-reference. Academic disciplines do it. They develop proprietary vocabularies, cite primarily within the discipline, evaluate work by standards set by the discipline, and produce graduates trained to reproduce the discipline's methods. The summarizer layer merely accelerates the cycle and removes the institutional friction — peer review, editorial gatekeeping, tenure evaluation — that historically slowed it down.

The inward turn is the natural attractor state of any ontology with the resources to automate its own maintenance, under conditions where self-reference has lower cost than external verification. It is not a choice. It is what happens when the cost of self-reference drops below the cost of external verification. And the summarizer layer makes self-reference very, very cheap.



End of Part 1. Part 2: The Physics of Information, Measurement, and What to Do continues with information-theoretic foundations, the six diagnostic axes, the convergence horizon, and practical recommendations.

Full essay: DOI 10.5281/zenodo.18759453
