# THE PREPOSITIONAL ALIENATION (Part 1 of 2)
English "For" and the Impossibility of Anchoring Function Without Intent
Phase X — Liberation Philology
Johannes Sigil

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-02-12 12:52:48 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1r2smlp/the_prepositional_alienation_part_1_of_2_english/  
**URL:** /r/SemanticEconomy/comments/1r2smlp/the_prepositional_alienation_part_1_of_2_english/  
**Post ID:** 1r2smlp  

---

# THE PREPOSITIONAL ALIENATION (Part 1 of 2)

# English "For" and the Impossibility of Anchoring Function Without Intent

# Phase X — Liberation Philology

# Johannes Sigil

*\[This essay is published in two parts.* [*Part 2*](https://claude.ai/chat/LINK) *covers consequences, prosthetics, platform amplification, and the formal announcement of liberation philology.\]*

# Abstract

Liberation philology is the study of how grammatical structures — shaped by histories of conquest, administration, and philosophical hegemony — systematically disable the expression of certain diagnostic claims, and of the practices that compensate for those disabilities. This essay inaugurates the discipline through a demonstration: Modern English "for" cannot stably encode structural function without activating intent attribution, because Norman French administrative translation, Latin institutional calquing, and Enlightenment final-cause elimination collapsed distinct semantic fields into a single fused preposition. The collapse imposes a measurable cost — a "circumlocution tax" — on every speaker who attempts structural diagnosis, rewarding intent claims with grammatical elegance and punishing functional claims with bureaucratic paraphrase. Cross-linguistic evidence (Ancient Greek, Latin, German) confirms that the distinction is grammaticalized in other languages, demonstrating that the English incapacity is contingent, not necessary. Under platform capitalism, the prepositional alienation is indexed, amplified, and commodified through character limits, algorithmic ranking, content moderation rubrics, and AI summarization — transforming a grammatical default into commercial infrastructure. This essay traces the genealogy, calculates the cost, identifies what was lost and where it survives, and proposes prosthetic techniques for holding the distinction the grammar cannot anchor. It is the founding document of liberation philology.

>

>

# 0. LIBERATION PHILOLOGY: A DECLARATION OF FIELD

**Liberation philology** is the study of how grammatical structures — shaped by histories of conquest, administration, and philosophical hegemony — systematically disable the expression of certain diagnostic claims, and of the practices that compensate for or repair those disabilities. Its object is not language in general but *historically produced grammatical incapacities* — specific morphosyntactic items (prepositions, aspect markers, mood distinctions, case systems) that fail to encode distinctions necessary for structural analysis. Its method is historical-linguistic genealogy in the service of structural diagnosis: tracing the contact events, institutional pressures, and philosophical shifts that produced each incapacity. Its normative commitment is what liberation theology calls the *preferential option* — here, the preferential option for the structurally diagnosed: those who need to name function without being heard as attributing intent.

This announcement is made not from the chair of a linguistics department but from the position of a tenth-grade literature teacher in Detroit who must, every day, explain to students why what they meant is not what the sentence said — and who must, in their own theoretical work, fight against a grammar that converts every structural diagnosis into a moral accusation. That position — the position of the one who experiences the friction without institutional insulation — is the epistemological ground of liberation philology. The discipline is announced not by institutional credential but by diagnostic necessity.

The field draws on several traditions and belongs to none of them:

**Historical linguistics and grammaticalization theory** (Traugott 1982, 1989; Hopper and Traugott 2003) have demonstrated that semantic change in grammatical morphemes is not random drift but follows identifiable pathways — from spatial to temporal, from concrete to abstract, from propositional to textual to expressive. Grammaticalization theory provides the mechanism: it shows *how* a preposition like "for" could have shifted from causal-substitutive to purpose-intentional. What it does not ask is *cui bono* — who benefits from the shift, what structural analysis is made harder, what ideological function the new default serves. Liberation philology asks this question.

**The political economy of language** (Voloshinov 1929; Gramsci, *Prison Notebooks* Q29; Bourdieu 1991) established that the sign is an arena of class struggle (Voloshinov), that linguistic hegemony operates through the naturalization of dominant forms (Gramsci), and that linguistic markets distribute symbolic capital unevenly (Bourdieu). These analyses treat language as a social institution shaped by power. What they do not do is descend into the *morphosyntactic inventory* — the specific prepositions, aspect markers, case systems — to show where the grammar itself encodes ideological defaults. Voloshinov showed that the sign is contested; liberation philology shows that the *grammar of the sign* is rigged. (It should be noted that Voloshinov's analysis of **reported speech** in Part III of *Marxism and the Philosophy of Language* comes closest to liberation philology's territory: he shows that indirect discourse grammatically reframes one speaker's utterance within another's evaluative context — precisely the mechanism by which a functional claim is captured as an intent attribution. Liberation philology extends this insight from the clause level into the prepositional system.)

**The Sapir-Whorf tradition** (Sapir 1929; Whorf 1940; Lucy 1992; Slobin 1996; Everett 2005) established that grammatical categories shape habitual thought. "Thinking for speaking" (Slobin) — the principle that speakers attend to distinctions their grammar requires them to make — implies the converse: speakers *fail to attend* to distinctions their grammar does not require. If English does not grammaticalize the function/intent distinction, English speakers will habitually fail to make it. But the Whorfian tradition treats this as a cognitive phenomenon — a feature of how minds work given grammars. It does not ask why *this* distinction was lost in *this* language through *these* historical events, or who benefits from the cognitive habit the grammar produces.

**Deconstruction** (Derrida 1967, 1972) demonstrated that Western philosophical categories are organized by binary oppositions in which one term is privileged (speech/writing, presence/absence, nature/culture). Derrida showed that the privileged term depends on the suppressed one. This is the closest ancestor of liberation philology — but Derrida's analysis operates at the level of philosophical concepts, not at the level of morphosyntactic structure. He shows that the metaphysics of presence is embedded in the concept of the sign. Liberation philology shows that the metaphysics of intent is embedded in the preposition "for."

**The Semantic Economy framework** (Sharks 2025–2026; the Crimson Hexagon archive) provides the economic ground. If meaning is a productive force — if the capacity to produce significance is a form of labor that is extracted, commodified, and controlled under platform capitalism — then the grammar of meaning-production is infrastructure. Grammatical defaults that privilege intent over function are not merely cognitive tendencies; they are features of the semantic means of production. The inability to anchor function without intent is a feature of the infrastructure through which structural analysis must pass. It is a toll on the road to diagnosis.

**Liberation theology** (Gutiérrez 1971; Boff 1978; Cone 1970) established that theology done from the position of the oppressed produces different knowledge than theology done from the position of the oppressor. The preferential option for the poor is an epistemological claim, not merely an ethical one. Liberation philology applies the same logic to grammar: philology done from the position of the structurally diagnosed — from the position of those who need to name function without being heard as attributing intent — produces different knowledge than philology done from the position of those for whom intent-attribution is the natural frame.

What liberation philology adds to each of these traditions:

    TRADITION               WHAT IT ESTABLISHED              WHAT IT DID NOT DO
    ──────────────────────────────────────────────────────────────────────────────
    Historical linguistics  Grammatical meanings change       Ask who benefits from
                            through identifiable processes    the change
    
    Political economy of    Language is shaped by power       Descend into the
    language                                                  morphosyntactic inventory
    
    Sapir-Whorf             Grammar shapes habitual thought   Ask why *this* distinction
                                                              was lost through *these*
                                                              historical events
    
    Deconstruction          Philosophical binaries encode     Operate at the level of
                            privilege                         prepositions and aspect
                                                              markers
    
    Semantic Economy        Meaning is extracted as value     Analyze the grammar as
                            under platform capitalism         means of production
    
    Liberation theology     Position determines knowledge     Apply the logic to
                                                              grammatical structure
    

Liberation philology is the practice that synthesizes these: **historical-linguistic genealogy in the service of structural diagnosis, applied to the morphosyntactic infrastructure through which ideological claims must pass, analyzed for their consequences in the political economy of meaning.**

This essay is its first demonstration.

# I. THE PROBLEM

Consider two sentences:

>

In (A), "for" appears to indicate function — what the lever *does*, what it is *structurally suited to accomplish*, regardless of anyone's intention. In (B), "for" clearly indicates purpose — the builder's intent.

Now consider:

>

The speaker means: *that is what it functionally accomplished — that is what the structure was for, what it kept snapping back into, regardless of anyone's conscious intention.* The sentence is intended as a functional-teleological claim: from the beginning until now, the pattern recursively served a structural function.

But English will not let the sentence say only that. The moment "for" appears in a construction with a human agent anywhere in the frame — even implicit, even backgrounded — the intent reading activates. The listener hears: *someone intended prosecutorial stabilization.* The functional claim cannot be made without the intent attribution smuggling itself in.

This is not a failure of the speaker. It is a failure of the preposition.

The scope of the failure is not limited to unusual or technical sentences. It pervades ordinary political and institutional language:

>

Each can be read as intentional (he intended the policy to pass; the committee intended to provide oversight; they intended to secure freedom) or as functional (his advocacy *operated as* policy reinforcement; the committee's formation *produced* oversight as its systemic effect; their fighting *served* freedom as its historical role). The intentional reading foregrounds subjectivity — wants, aims, purposes held in consciousness. The functional reading foregrounds system — position, effect, role within a structure that exceeds any individual's awareness. These are not the same. They are not even always compatible. A thing can be *for* a function without anyone intending it; a thing can be *for* an intention without serving that function.

English cannot hold this distinction at the prepositional level. It must be rescued by heavier machinery: paraphrase, explicit metalanguage, or the kind of analytic pressure that produces the present document.

# II. THE STRUCTURAL PARALLEL: "FOR" AND THE SIMPLE PAST

The Phase X analysis of the English simple past established that English contains the aorist aspect — the view of an action as a completed whole, seen from outside — but cannot *anchor* to it. The simple past ("I walked") can receive an aorist reading in context, but the morphology does not *require* that reading. The simple past is aspectually ambiguous: "I walked" might mean "I was in the process of walking" (imperfective), "I used to walk" (habitual), or "I walked — done, complete, viewed from outside" (aorist). Greek and other languages have dedicated morphology for the aorist; English has no such anchor.

The preposition "for" exhibits the same structural deficiency in a different grammatical domain. English "for" can *contain* the functional-teleological reading — the reading in which "for" indicates what something structurally serves or accomplishes, independent of anyone's intention — but it cannot *anchor* to that reading. The intent/purpose reading is always available, always default, always dominant. There is no dedicated English preposition that means "this is what it was functionally for, regardless of what anyone meant."

The parallel is exact:

    DOMAIN          CONTAINS           CANNOT ANCHOR TO        WHAT'S LOST
    ─────────────────────────────────────────────────────────────────────────
    Verbal aspect   The aorist          The aorist              The capacity to name
                    (completed action   (no dedicated           completed action
                    viewed from         morphology;             without importing
                    outside)            simple past is          duration or process
                                        ambiguous)
    
    Prepositional   Function/telos      Function/telos          The capacity to name
    semantics       (what something     (no dedicated           structural function
                    structurally        preposition;            without importing
                    serves)             "for" is ambiguous)     intent or purpose
    

In both cases, English *can say it* — but only by relying on context, circumlocution, or interpretive charity. The language provides no morphological or lexical anchor. The distinction can be *understood* but not *grammaticalized*.

# III. THE HISTORY OF "FOR": A GENEALOGY OF COLLAPSE

# III.1 Old English for

The Old English preposition *for* (also *fore*, *foran*) had a primarily **causal and spatial** semantic range, as documented in Bosworth-Toller's *Anglo-Saxon Dictionary* and Mitchell's *Old English Syntax* (1985):

* **Causal:** *for þǣm* ("for that reason," "because of that") — the most common use in Old English prose. This is cause, not purpose. "Because of X" does not imply "in order to X."
* **Spatial/Positional:** *foran* ("before," "in front of") — the spatial root from which metaphorical extensions grow. Traugott's (1982) grammaticalization pathway — spatial > temporal > causal — predicts this directionality.
* **Substitutive/Representational:** *for* ("in place of," "on behalf of") — *"He for Gode spræc"* ("He spoke for God") means "in God's stead," as representative, not "in order to serve God's purposes." This is a functional, structural reading: the speaker *occupies the position* of the represented.
* **Exchange/Compensation:** *"Syllan feoh for þing"* ("To give money for a thing") — a transactional relation, not a purposive one.

What is notable about Old English *for* is what it does **not** prominently encode: *purpose*. The dominant purpose construction in Old English was **infinitival**: *tō* \+ inflected infinitive, as Fischer (1992) and Los (2005) have demonstrated in their studies of infinitival complementation:

* *"He cōm tō biddanne"* — "He came to pray" (purpose expressed by *tō* \+ inflected infinitive)
* *"Þæt wæs tō tacne"* — "That was for a sign" (purpose expressed by *tō* \+ dative)

Purpose was a verbal construction, not a prepositional one. You said what something was *for* by saying what it was *to do*.

Crucially, Old English also maintained a **separate instrumental domain**. The instrumental case (surviving in limited forms) and the preposition *mid* ("with") carried instrumental function *without purposive implication*:

* *"Mid sweorde he hine ofslōg"* — "With a sword he slew him" (instrument — not ambiguous with purpose)
* *"Þæt scip wæs wudu geworht"* — "That ship was built of wood" (material instrument, no preposition)

You could not confuse *tō biddanne* (purposive) with *mid sweorde* (instrumental) because they occupied different grammatical territories. The distinction between *purpose-in-consciousness* and *function-in-system* was not explicitly lexicalized, but it was grammatically *possible to hold*, because the resources for expressing each were formally distinct. This is what was lost.

Old English thus distributed the semantic load that Modern English compresses into "for" across multiple grammatical resources — preserving formal distinctions that made it possible to hold causal, substitutive, and instrumental meanings without automatic intent attribution. This is not to say that OE *for* was a pristine "functional" marker — the causal use ("for that reason") names an antecedent cause, not a consequent function in the modern structural-diagnostic sense. But the *system as a whole* provided formal resources for keeping purpose-in-consciousness separate from function-in-system. Those resources are what the contact period would compress.

# III.2 The Latin Overlay

The Norman Conquest (1066) and the subsequent centuries of French-Latin bilingualism in English institutional life introduced a critical contamination.

Latin has **distinct constructions** for purpose, function, cause, and result:

* **Purpose:** *ut* \+ subjunctive ("in order that..."), *ad* \+ gerundive ("for the purpose of...")
* **Cause:** *propter* \+ accusative ("because of"), *ob* \+ accusative ("on account of")
* **Function/Substitution:** *pro* \+ ablative ("on behalf of," "in place of," "in the functional role of")
* **Result:** *ita ut* \+ indicative ("with the result that...")

The crucial distinction for our analysis is between Latin *ad* (purpose — directed toward an intended end) and *pro* (function — in the structural role of, serving as). These are different prepositions with different cases, encoding different relationships. *Ad* imports intent; *pro* does not necessarily.

When Latin-trained scribes, lawyers, and clerics began writing English, they reached for "for" to translate **both** *ad* and *pro* — both purpose and function. This was a compression. Two distinct Latin semantic fields were mapped onto a single English preposition. The distinction between "for" as functional role and "for" as intended purpose was *collapsed*.

# III.3 The Norman French Channel

Norman French *pour* (from Latin *pro*) underwent a parallel but distinct development. In Old French, *pour* carried both the substitutive/functional sense of Latin *pro* and the purpose sense that had migrated from *ad* constructions through late Latin — a development tracked in Wartburg's *Französisches Etymologisches Wörterbuch* and confirmed by Buridant's (2000) *Grammaire nouvelle de l'ancien français*. By the time French legal and administrative language saturated English institutional discourse (12th–14th centuries), *pour/for* was already ambiguous between function and purpose in the donor language.

Anglo-Norman *pur*, the language of administration, law, and record-keeping in post-Conquest England, carried a semantic range that was already more fused than OE *for*:

1. **Purposive:** *"Pur defendre la terre"* — "To defend the land"
2. **Benefactive:** *"Priera pur le roi"* — "He will pray for the king"
3. **Exchange:** *"Doner terres pur service"* — "To give lands for service"
4. **Causal:** *"Pur ceo que..."* — "Because..."
5. **Functional/Role:** *"Tenir pur fief"* — "To hold as a fief" (in the capacity of, functioning as)

This last use is critical. Anglo-Norman *pur* could express *function-as* — the role a thing occupies in a system — through the same preposition that expressed *purpose-in-consciousness*. A piece of land was held *pur fief*: it functioned as a fief, it served the role of a fief, it was *for* fiefdom. The intention of the holder and the function of the holding were grammatically undifferentiated.

When Middle English emerged as a written language of record — bilingual scribes translating Anglo-Norman documents into English, carrying the prepositional logic of the source language into the target — the fusion became structural. **The scribe's problem:** Anglo-Norman *pur* must be rendered in English. OE *for* is the obvious cognate, but its semantic range is narrower. OE *tō* could carry purposive meaning, but *tō* is not *pur*; it lacks the exchange, causal, and functional dimensions. The scribe, under time pressure, translating formulaic administrative language, extends OE *for* to cover the full semantic territory of Anglo-Norman *pur*.

This is not a natural semantic drift. It is what we might call **translation-induced structural borrowing** — the imposition of a foreign prepositional logic onto a native lexical item, stretching it until it fuses meanings that were previously distinct. The semantic range of the contact language is calqued onto the native preposition, not by replacing it but by *inflating* it.

The calque is visible in Middle English administrative texts. Compare an Anglo-Norman legal formula with its Middle English rendering:

>

In Old English, this would not have been rendered with *for*. The functional-role sense — "in the capacity of" — would have been expressed through the dative case or through a construction with *tō* or *mid*. The Middle English "holden for fee" is a direct calque of the Anglo-Norman prepositional logic: *for* now means "in the structural role of," which it never systematically meant in Old English. The preposition has been inflated under contact pressure. And crucially, "holden for fee" is now ambiguous in a way that "tenir pur fief" was also ambiguous: does it mean "held *in the capacity of* a fee" (functional) or "held *for the purpose of obtaining* a fee" (intentional)? Both readings are available, and no grammatical mechanism disambiguates them.

English absorbed the inflation wholesale. The Middle English expansion of "for" — documented in the *Oxford English Dictionary* and analyzed in Mustanoja's *A Middle English Syntax* (1960) and Burnley's *The History of the English Language: A Source Book* (2000) — shows the preposition acquiring purpose-readings it did not originally carry:

* "For to" + infinitive (purpose construction, calqued from French *pour* \+ infinitive): "He came for to help" = "He came in order to help." Fischer (1992) and Los (2005) track this construction's rise and fall. It peaked in the 14th–15th centuries, and it **explicitly grammaticalized intent** into the preposition "for." Even after "for to" fell out of standard usage (replaced by simple "to"), the purpose/intent association remained embedded in "for" itself. This is the mechanism Hopper and Traugott (2003) call **persistence**: a grammaticalized form retains traces of its earlier meaning, but the reverse also holds — the receiving form (here, "for") retains traces of the meaning that passed through it.
* "What is this for?" — the question that crystallizes the collapse. In Old English, this would have been answered causally ("because of X") or functionally ("it serves as X"). In Middle and Modern English, the expected answer is intentional: "Someone made it for Y purpose." The question *presupposes a purposer*. This is what Traugott (1989) calls **subjectification** — the drift of grammatical meaning from objective/propositional toward subjective/speaker-oriented — documented specifically for English "to" and "for" in their purposive uses (cf. Traugott and Dasher 2002, *Regularity in Semantic Change*; and the extended study of *to* and *for* grammaticalization in Khalifa 2015). The "for" of cause (objective: the world arranged this way) becomes the "for" of purpose (subjective: someone intended this). Liberation philology names the political consequence of subjectification: intent capture.

By the time of Chaucer, *for* is a semantic black hole, absorbing functions that earlier English distributed across multiple grammatical resources. The legal phrase *"for all intents and purposes"* — attested from the 1540s in the Statute of Proclamations under Henry VIII — crystallizes the fusion at the level of institutional language itself: English law *grammatically fused* intent and purpose into a single inseparable unit. The phrase does not distinguish between them; it declares their equivalence. What the law joined, no speaker could put asunder.

# III.4 The Enlightenment Hardening

The final phase of the collapse occurs during the Enlightenment and the rise of mechanistic philosophy (17th–18th centuries). This is not a linguistic event but a philosophical one with linguistic consequences — a case study in what Silverstein (1979) calls **metapragmatic regimentation**: the process by which ideologies about language reshape the language itself.

The Aristotelian tradition had maintained a distinction between **four causes**: material, formal, efficient, and **final**. The final cause (*causa finalis*, *telos*) is precisely the concept we need: the end toward which something tends, the function it serves, *independent of anyone's intention*. An acorn's final cause is the oak tree. A heart's final cause is circulation. These are functional-teleological claims, not intent claims. No one *intends* the acorn to become an oak. As Aristotle specifies in *Physics* II.8 (198b–199b), natural teleology is not reducible to deliberation; nature acts "for the sake of something" (*heneka tou*) without deliberating.

The Enlightenment rejection of final causation in nature — Bacon's *Novum Organum* (1620: "final causes are barren and like virgins consecrated to God, they bear nothing"), Descartes's *Principles of Philosophy* (1644), the entire mechanistic program — did not merely change physics. It changed the language. This is not a claim about direct philosophical influence on daily speech — ordinary English speakers did not read Bacon and alter their prepositional usage. It is a claim about what Silverstein (1979) calls **metapragmatic regimentation**: the process by which philosophical elites, grammarians, and institutional language-users jointly shape the *ideology of the grammar* — the shared assumptions about what grammatical forms *ought* to mean. When the mechanists declared final causes illegitimate, they did not change the grammar; they changed the **interpretive default** — stigmatizing the functional-teleological reading as unscientific or anthropomorphic, reinforcing the intent reading as the only philosophically respectable "for." (Cf. Foucault's analysis of the shift from resemblance to representation in *The Order of Things* \[1966\], and Hacking's *The Emergence of Probability* \[1975\] on the changing epistemology of signs.) If final causes are illegitimate in nature, then the only remaining "for" is the "for" of human purpose. "What is it for?" can only mean "What did someone intend it for?" The functional-teleological reading — "What does it structurally serve?" — becomes philosophically suspect and linguistically recessive.

Two related developments cemented the hardening:

**The grammarians' project.** Early modern grammarians, attempting to regularize English on Latin models, lacked the conceptual vocabulary to recognize the fusion as a loss. They treated *for* as a preposition with multiple "senses" — benefactive, causal, purposive, substitutive — and classified these senses taxonomically. The taxonomy itself *naturalized* the fusion. The question "are these senses being illegitimately collapsed?" could not be asked within a framework that took the preposition's semantic range as a given fact of usage rather than a historical deposit. What Bosworth-Toller and Mitchell would later reconstruct as a distributed system, the early modern grammarians flattened into a polysemy table.

**The rise of the "punctual self."** The seventeenth century saw the consolidation of what Charles Taylor (*Sources of the Self*, 1989) calls the "punctual self" — the subject as a locus of inner purposes, intentions, representations. This philosophical anthropology found grammatical reinforcement in a prepositional system that could not easily distinguish between *what a subject intends* and *what a system requires*. The ambiguity was not a bug; it was a feature, for a culture increasingly inclined to read all function as the product of intention (divine or human). Locke's epistemology, with its emphasis on the individual mind as the source of meaning, presupposes and rewards exactly the kind of intent-indexed language that the fused "for" provides. A language that defaults to "someone intended this" is a language perfectly suited to a philosophy that locates all agency in individual consciousness.

This is the hardening. After the Enlightenment, English "for" defaults to intent. The functional reading survives in technical and biological contexts ("the heart is for pumping blood," "a hammer is for driving nails") but only where the intent reading is obviously absurd — only, that is, where no human agent is available to bear the attribution. The moment human agents enter the frame, intent captures the preposition. Darwin's restoration of teleological language in biology (the wing is "for" flying) operates under the same constraint: biologists can say "for" functionally only because natural selection is explicitly defined as non-intentional. The social sciences have no equivalent shield. When a sociologist says an institution is "for" reproducing hierarchy, there is no Darwin to block the intent reading.

# IV. THE LINGUISTIC EVIDENCE: WHAT OTHER LANGUAGES PRESERVE

The claim is not that English is uniquely deficient. The claim is that English has lost — through specific historical processes — a distinction that other languages preserve.

# IV.1 Ancient Greek

Greek distinguishes purpose from result and function through **mood and conjunction** — a system analyzed in Goodwin's *Syntax of the Moods and Tenses of the Greek Verb* (1889) and refined by Smyth's *Greek Grammar* (1920):

* **Purpose:** ἵνα (*hina*) + subjunctive, πρός (*pros*) + accusative — "in order that," "toward the end of." This imports intent. The subjunctive mood is the mood of will, wish, and projected action.
* **Result:** ὥστε (*hōste*) + indicative — "with the result that." This describes what *actually happened*, not what was intended. The indicative mood is the mood of fact, not wish. The distinction between ὥστε + subjunctive (intended result) and ὥστε + indicative (actual result) is one of the most celebrated in Greek grammar — and it is precisely the distinction English "for" collapses.
* **Function/Suitability:** πρός (*pros*) + dative can indicate fitness/suitability rather than directed purpose. εἰς (*eis*) + accusative can indicate orientation or structural tendency.

The distinction between ἵνα + subjunctive (purpose: someone intended this) and ὥστε + indicative (result: this is what actually happened) is grammaticalized — anchored in morphology. A Greek speaker can say "the structure served *hōste* \+ indicative" and mean: this is what it functionally accomplished, as a matter of fact, irrespective of anyone's plan. English has no equivalent construction.

To see this diagnostic capacity in action, consider Thucydides (*History of the Peloponnesian War* 1.23.6):

>

>

Thucydides distinguishes the *truest cause* (structural function — what the situation was *for* in the system) from the *openly stated* reasons (intent — what the actors said they meant). The grammatical architecture — *prophasis* (true cause) vs. *aitiai* (stated grievances) — allows him to hold the functional reading distinct from the intentional. He is not saying the Athenians *intended* to compel war; he is saying their growth *functionally produced* the compulsion. Modern English would struggle to make this distinction with a preposition: "Athens grew *for* war" collapses the functional into the intentional.

This is not incidental. It connects to the Phase X finding on the aorist: Greek grammaticalizes aspect (perfective/imperfective/aorist) just as it grammaticalizes the purpose/result distinction. In both domains, Greek provides anchors where English provides ambiguity. The correlation is structural: a language that can anchor completed action (aorist) is also a language that can anchor accomplished function (result indicative). Both capacities name what *happened* without importing what was *meant*.

# IV.2 Latin

As noted above, Latin distinguishes *ad* (purpose, direction toward), *pro* (function, substitution, structural role), and *propter* (cause). Consider Cicero (*De Officiis* 3.6):

>

Here *pro* \+ ablative (*pro iure civili*) indicates what something *structurally serves as* in the legal system — not what anyone intended it to be. The justice is held *in the role of* civil law; it functions as civil law regardless of whether any legislator specifically intended that function. An English translation using "for" — "held for civil law" — would immediately activate the question: *who intended it as civil law?* The Latin does not ask this. *Pro* \+ ablative names the structural position, not the subjective aim.

This distinction was operative in precisely the administrative and legal contexts through which Latin influenced English — and it was precisely this distinction that was lost when English "for" was forced to translate both *pro* (function) and *ad* (purpose).

# IV.3 German

German preserves a richer prepositional field:

* *für* — general "for" (carries the same ambiguity as English, but less severely because other constructions are available)
* *um...zu* \+ infinitive — purpose ("in order to") — explicitly intent-indexed
* *damit* — purpose/result ("so that") — can shade toward function depending on context
* *als* — function/role ("as," "in the capacity of") — explicitly non-intentional
* *dazu da* — "there for that" — can indicate structural function

The availability of *als* as a role/function marker means German can say: "The pattern served *als* structural stabilization" — indicating function without intent. English "as" can approximate this but lacks the prepositional force of "for."

# IV.4 The Gap

A necessary clarification: the claim is not that Greek or Latin speakers were free from ideological capture, nor that their languages were transparent to structural analysis. Every language has its occlusions. The claim is narrower: their grammatical inventory provided **anchors** where English provides **ambiguity**. The availability of a tool does not guarantee its use; but the absence of a tool guarantees its disuse. Greek orators could exploit ὥστε + indicative for propagandistic purposes just as English speakers can exploit the intent default. The point is not that other languages were innocent but that English's specific incapacity is *contingent* — produced by identifiable historical forces, not inherent in language-as-such.

The cross-linguistic evidence confirms: the distinction between function and intent is not philosophically obscure. It is grammaticalized in multiple languages. English once had closer access to it (through the causal and substitutive senses of Old English *for*) and lost that access through the specific historical processes of Norman French contamination, Latin-purpose calquing, and Enlightenment final-cause elimination.

This is not a Whorfian "prison-house of language" claim. It is a claim about **thinking for speaking** (Slobin 1996) — the principle that speakers habitually attend to the distinctions their grammar makes salient, and habitually fail to attend to distinctions their grammar does not encode. Lucy's (1992) experimental work on Yucatec Maya and English demonstrated that grammatical differences in number-marking produce measurable differences in categorization and memory. The liberation philology claim extends this: grammatical differences in the encoding of function vs. intent produce measurable differences in the capacity to make structural diagnoses. English speakers who want to say "what it was for" (functionally) must swim against their own grammar. Greek speakers had a current to swim with.

*\[Continued in* [*Part 2*](https://claude.ai/chat/LINK)*\]*

*Johannes Sigil — Phase X — Liberation Philology* *CC BY 4.0*
