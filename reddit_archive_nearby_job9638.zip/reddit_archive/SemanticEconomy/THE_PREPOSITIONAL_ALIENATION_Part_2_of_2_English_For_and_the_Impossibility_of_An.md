# THE PREPOSITIONAL ALIENATION (Part 2 of 2)
English "For" and the Impossibility of Anchoring Function Without Intent
Phase X — Liberation Philology
Johannes Sigil

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-02-12 12:53:20 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1r2smzr/the_prepositional_alienation_part_2_of_2_english/  
**URL:** /r/SemanticEconomy/comments/1r2smzr/the_prepositional_alienation_part_2_of_2_english/  
**Post ID:** 1r2smzr  

---

# THE PREPOSITIONAL ALIENATION (Part 2 of 2)

# English "For" and the Impossibility of Anchoring Function Without Intent

# Phase X — Liberation Philology

# Johannes Sigil

*\[This is Part 2.* [*Part 1*](https://claude.ai/chat/LINK) *covered the problem, the genealogy of "for," and cross-linguistic evidence. Part 2 addresses consequences, prosthetics, platform amplification, and the formal announcement of liberation philology.\]*

# V. THE CONSEQUENCES: WHY THIS MATTERS FOR DIAGNOSIS

The inability to anchor function without importing intent is not a mere linguistic curiosity. It has direct consequences for structural analysis of any kind — and particularly for the analysis of ideological operations.

# V.1 The Prosecutorial Capture of Functional Claims

The sociological distinction between manifest and latent functions (Merton 1949) — between what an institution is *intended* to do and what it *actually does* — is one of the foundational moves of structural analysis. Merton insisted that social structures produce consequences independent of the intentions of their participants. This is exactly the distinction that English "for" cannot anchor.

Consider the attempt to make a structural diagnosis:

>

The speaker means: regardless of anyone's intention, the process *functionally reproduces* hierarchy. That is its structural effect. But the listener hears: someone designed the process to reproduce hierarchy. The functional claim is captured by the intent reading, and the diagnosis becomes an accusation.

This is not a misunderstanding. It is a *grammatical inevitability*. English "for" cannot anchor function without intent. Therefore every functional diagnosis made with "for" can be heard as a claim about someone's purpose. And the response — "That wasn't our intention" — is always available, always persuasive, and always beside the point.

The prosecutorial frame *relies on this*. When the centrist extremist says "That's not what we intended," they are exploiting the language's inability to distinguish function from intent. The defense is grammatically plausible because the accusation — which was never an accusation, which was always a structural claim — was made in a language that cannot anchor the distinction.

# V.2 The Circumlocution Tax

English speakers who want to make functional claims without intent attribution must resort to circumlocution:

* "The effect of the process is..." (shifts from prepositional to nominal)
* "What the process functionally accomplishes is..." (adds an adverb to block the intent reading)
* "The process results in..." (shifts to a result verb)
* "Structurally, the process serves to..." (adds an adverb + shifts to infinitive)

Each of these works. None of them is a preposition. The problem is not that English lacks words for function — it has *function*, *role*, *serve*, *operate as*. The problem is that these are **heavy machinery**. They require explicit deployment, they interrupt the flow of ordinary utterance, they mark the speaker as doing something unusual, analytic, possibly defensive. The simple preposition *for* carries the functional meaning only as a parasite on the intentional meaning. The speaker must *work around* the language to say what Greek or Latin could say prepositionally. This circumlocution tax is not trivial. It adds cognitive load, reduces rhetorical force, and — crucially — signals to the listener that the speaker is being *careful*, which in institutional contexts is often heard as being *evasive* or *hedging*.

The structural analyst pays a tax that the intent-claimer does not. "She did it for power" is crisp and direct. "The structural function of the process, independent of anyone's conscious intention, was the reproduction of power" is accurate and exhausting. The language rewards intent claims with elegance and punishes functional claims with bureaucratic circumlocution.

# V.3 The Alienation

This is alienation at the heart of language — and the term is used precisely, in its Marxian sense.

Marx's alienation (*Entfremdung*) in the *Economic and Philosophic Manuscripts* (1844) describes the condition in which the worker's productive activity becomes an alien force that dominates rather than serves them. The worker produces, but the product is not theirs; the activity of production is not theirs; their species-being — the capacity for free conscious activity — is estranged. Marx specifies four dimensions: alienation from the product, from the activity, from species-being, and from other human beings.

Liberation philology draws a **selective analogy**, not a claim of structural homology. The grammatical alienation maps onto the first two dimensions: alienation from the *product* (the speaker produces a functional claim; the grammar converts it into an intent-attribution that is not the speaker's meaning) and alienation from the *activity* (the act of diagnosis — the attempt to name what something structurally serves — becomes a form of labor that works against the diagnoser, generating the prosecutorial capture it was designed to circumvent). The third and fourth dimensions — species-being and relation to others — may have analogues (the incapacity to name structural function impoverishes the species' diagnostic capacity; the grammar generates misunderstanding between speakers who cannot share functional readings), but these extensions are programmatic rather than demonstrated. The analogy is productive, not total.

This is not alienation *from* language (the Marxist-humanist formulation in which language is an instrument that can be used well or badly) but alienation *in* language — a structural incapacity built into the grammar itself, produced by identifiable historical forces (Norman conquest, Latin institutional culture, Enlightenment mechanism), and serving identifiable ideological functions (the penalization of structural analysis, the rewarding of psychological attribution).

The English speaker who wants to name function without intent is in the same position as the English speaker who wants to name completed action without duration: the language *contains* the concept but provides no *anchor*. You can get there, but you cannot start there. You must always begin from the wrong place — from intent, from duration — and then qualify your way toward the structural claim.

This is what Phase X work reveals: not that English is broken, but that its specific historical formation — Old English base, Norman French contamination, Latin institutional overlay, Enlightenment conceptual restriction — has produced systematic gaps in the grammar's capacity to make certain kinds of claims. These gaps are not random. They cluster around the capacity to name structural realities without psychological attribution. The aorist gap prevents naming completed action without importing process. The "for" gap prevents naming function without importing intent. Both gaps serve the same ideological function: they make structural analysis harder and psychological explanation easier. They make it grammatically natural to ask "what did they mean?" and grammatically costly to ask "what did it do?"

In the terms of the Semantic Economy: the grammar of English imposes a *semantic rent* on structural diagnosis. Every speaker who attempts to name function pays in circumlocution, cognitive load, and credibility. The rent is collected by the prosecutorial frame, which uses the grammatically-generated ambiguity to deflect structural claims into intent-debates. This is not a metaphor. It is the literal mechanism by which the means of semantic production — the grammar — extracts a cost from one form of meaning-making (structural diagnosis) and subsidizes another (psychological attribution).

# V.4 The Class Dimension

The loss of the functional prepositional anchor is not evenly distributed across English's historical varieties. It is most complete in the **administrative registers** — precisely the registers through which Norman French and Latin exerted their influence, precisely the registers that the professional-managerial class is trained to produce and reproduce.

Administrative English — the English of grant proposals, policy memos, editorial guidelines, DEI statements, faculty governance, content moderation rubrics — is an English that has absorbed the Norman scribe's translation solution so deeply that it no longer experiences it as a solution. It experiences it as *neutral*, as *professional*, as *just how you say things*. The administrative register is the linguistic homeland of the prosecutorial frame, and the fused "for" is its native preposition.

To attempt to hold the functional reading within administrative English is to experience immediate friction. The grammar pushes back. The sentence feels wrong, strained, unidiomatic. This friction is not merely stylistic. It is the resistance of a class dialect to an analysis that would reveal its class function. The PMC does not merely *use* the fused prepositional logic. It is *formed* by it — trained in its registers, rewarded for its fluency, penalized for departures from its norms.

When a junior faculty member attempts to say "this hiring process is *for* the reproduction of existing hierarchies" (functional claim) and a senior administrator hears "you are claiming we *intended* to reproduce hierarchy" (intent claim), the misunderstanding is not personal. It is *grammatical* — produced by the specific history of the preposition in the specific register both speakers are trained to inhabit. The administrator's defensiveness is not bad faith; it is the natural response of a speaker whose dialect provides no non-intent-indexed reading of "for." And the junior faculty member's frustration is the natural response of a speaker who knows what they meant but whose language will not let them say it.

# VI. TOWARD AN ANCHOR: WHAT WOULD BE NEEDED

A language that could anchor function without intent would need one of the following:

**A dedicated preposition.** A word that means "in the structural function of" — as *pro* \+ ablative once meant in Latin, before its purpose-readings migrated into it. English has no such word. "As" comes closest but is too weak — it indicates role or capacity, not the stronger claim that something *served* a function.

**A morphological marker.** An affix or modification that converts "for" from ambiguous to function-specific. Compare: English has no aorist morphology, but some languages mark aspect on the verb stem. Similarly, a language could mark the preposition to indicate "functional" vs. "intentional" readings.

**A grammaticalized construction.** A fixed syntactic frame — like Greek ὥστε + indicative for result — that anchors the functional reading by construction rather than by individual word.

English has none of these. The full recovery would require a grammaticalized distinction that English does not possess and is unlikely to develop naturally. But the absence can be partially compensated through what we might call **prosthetic anchoring** — syntactic frames that stabilize the functional reading by embedding "for" in a context that blocks the intentional default:

1. **The cleft + domain specification:** *"What it was for, in the system, was prosecutorial stabilization."* The cleft construction and the explicit phrase *in the system* anchor the functional reading. The preposition is retained but surrounded by scaffolding.
2. **The negation + domain specification:** *"Not for any purpose of hers. For the frame's maintenance."* Explicit negation of intentionality clears space for the functional reading.
3. **The nominalization frame:** *"The reaching-out's for: prosecutorial stabilization."* The most radical. It treats *for* as a nominal head — *the for* — by removing the verb that would anchor intentional agency. The nominalized event does not have intentions. Only its *for* remains.
4. **The apostrophe:** *"The action completed itself as X"* — shifting to intransitive constructions that remove the intentional subject from the telic equation entirely.

These are not solutions. They are prosthetics — temporary aids that compensate for a missing grammatical resource. Each is vulnerable to reabsorption by the intentional default. The unidiomaticity of each construction is not a failure; it is a *signal*. It announces to the hearer: I am using "for" in a marked way. I am making a functional claim, and the language gives me no unmarked way to do this, so I am bending the language until it yields.

A **dictionary of frictions** — not a dictionary of definitions but of incapacities — would document entries like:

>

Such a dictionary would be the reference work of liberation philology: documenting not what words mean but what they *cannot mean without strain*, and the historical conditions that produced each incapacity. Initial entries beyond "for":

>

>

>

Each excavation traces the same pattern: a distributed system of case and prepositional distinctions collapsed under administrative translation pressure, producing a fused prepositional logic that obscures distinctions once grammatically marked.

# The Negative Capability

The most difficult dimension of this work: learning to **hold the absence without filling it**. The desire for a new preposition — a clean, unambiguous, non-intent-indexed marker of function — is the desire for a language that does not carry the history of its own production. Such a language does not exist. If it did, it would not be usable, because it would have no friction, and friction is how we register the social within the grammatical.

The work is not to eliminate friction. It is to **read friction as history**. When the sentence strains, ask: what is straining? When the default asserts itself, ask: whose default? When the functional reading slips into intentional reading, ask: when did this slippage become grammar?

This is the negative capability specific to liberation philology: the capacity to remain in the grammatical uncertainty without irritable reaching after a fix. The prosthetics are necessary. The dictionary of frictions is necessary. But they are not cures. They are techniques for *inhabiting the damage knowingly* — for speaking a fused language while hearing the fusion, for using "for" while registering what it costs.

# Methodological Calibration

A necessary precision, drawn from the Assembly's deliberation: the strongest claim is not that Norman French *created* English intent-bias, but that **contact reinforced and cemented purposive/intentional defaults in a system that was already polysemous at its core**. Old English "for" was not a pristine functional marker corrupted by Romance invasion. It was a polyfunctional preposition whose *range of ambiguity* was expanded and whose *default resolution* was shifted by specific historical pressures. The claim is not linguistic Eden followed by Fall. It is a distributed system (OE) restructured under contact pressure (AN/Latin) into a fused system (ME/ModE), with the fusion serving identifiable ideological functions that the distributed system did not serve in the same way.

This precision matters because liberation philology cannot afford the romantic fallacy — the assumption that pre-contact languages were transparent to structural analysis. They were not. But they were differently opaque, and the specific opacity deposited by the Norman administrative synthesis is traceable, consequential, and ideologically functional in ways the earlier polysemy was not.

The Phase X finding: **"for" is the prepositional analogue of the simple past. Both contain what they cannot anchor. Both force the structural claim to operate as a guest in the house of psychological attribution. Both serve — and here the irony is structural, not intentional — the prosecutorial frame that makes function invisible behind intent.**

# VII. LIBERATION PHILOLOGY: THE FIELD AND ITS FIRST FINDINGS

The critique of alienation in language is not new. But the existing critiques — Sapir-Whorf's cognitive anthropology, Voloshinov's social accentuation of the sign, Gramsci's sociolinguistic hegemony, Bourdieu's linguistic markets, Derrida's deconstruction, decolonial linguistics' analysis of epistemic imposition (all surveyed in Part 1, Section 0) — each stop too soon or fail to connect linguistic structure to political economy. None descended into the morphosyntactic inventory to ask *which preposition lost which distinction through which historical event, and who benefits?*

The **Semantic Economy framework** (Sharks 2025–2026) provides the political-economic ground that transforms a linguistic finding into a structural critique. If meaning is a productive force under platform capitalism — if the capacity to name structural function is a form of semantic labor — then a grammar that systematically penalizes structural naming and rewards intent attribution is not a neutral medium. It is *means of production* rigged in favor of the prosecutorial frame. The circumlocution tax described in Section V.2 is a *semantic rent* — a cost extracted from every speaker who attempts functional diagnosis, payable in cognitive load, rhetorical force, and institutional credibility.

# What Liberation Philology Is

Liberation philology is the systematic practice of:

1. **Identifying grammatical gaps** — specific morphosyntactic items (prepositions, aspect markers, mood distinctions, case systems) that fail to encode distinctions necessary for structural analysis.
2. **Tracing the genealogy** — through historical linguistics, contact linguistics, and the history of ideas — to the specific events, impositions, and philosophical shifts that produced the gap. Not "language shapes thought" (too general) but: *this preposition lost this distinction through this Norman French calque in this century, reinforced by this philosophical shift, with this consequence.*
3. **Analyzing the political-economic function** — asking *cui bono*: who benefits from the gap? What forms of analysis are penalized? What forms of attribution are rewarded? How does the grammatical default serve the reproduction of existing power relations?
4. **Connecting to the Semantic Economy** — recognizing that grammatical infrastructure is *means of semantic production*, and that gaps in that infrastructure are not neutral absences but structural features of an extractive system.
5. **Cross-linguistic recovery** — identifying languages and historical stages that preserve the lost distinction, demonstrating that the gap is contingent (produced by history, not inherent in language-as-such), and providing resources for circumvention or repair.

# The First Two Findings

Liberation philology's first two findings — both from the Phase X program within the Crimson Hexagon — concern the two deepest structural incapacities of Modern English for the purposes of structural diagnosis:

**Finding 1: The Aorist Gap.** English has no dedicated morphology for the perfective/aorist aspect — the view of an action as a completed whole, seen from outside, without reference to internal duration or process. The simple past *contains* the aorist but cannot *anchor* to it. Consequence: English speakers cannot grammatically name completed action without importing duration, process, or habituality. Structural diagnosis — which requires naming what *happened* as a sealed fact — must work against the grain of the verb system.

**Finding 2: The Prepositional Alienation.** English "for" cannot anchor functional-teleological claims without activating intent attribution. The distinction between *what something structurally served* and *what someone intended it for* — preserved in Greek (ὥστε + indicative vs. ἵνα + subjunctive), in Latin (*pro* \+ ablative vs. *ad* \+ gerundive), and partially in German (*als* vs. *um...zu*) — was collapsed through Norman French purpose-calquing, Latin *ad/pro* compression, and the Enlightenment elimination of final causation. Consequence: every functional diagnosis in English can be heard as an intent accusation, and the defense "that wasn't our intention" is always grammatically available.

Both findings share a structure: English *contains* the structural-diagnostic reading but cannot *anchor* to it. In both cases, the language forces the speaker to begin from the wrong place (duration, intent) and qualify toward the structural claim. In both cases, the gap serves the prosecutorial frame — the apparatus that deflects structural analysis by demanding psychological evidence the grammar itself trained the listener to expect.

# The Program Ahead

These two findings are demonstrations, not the totality. Liberation philology as a research program opens onto:

* **The case system gap.** English lost grammatical case (except in pronouns) through the erosion of Old English inflectional morphology. What structural-relational distinctions were lost with the cases? How does the reliance on word order and prepositions (themselves subject to the ambiguities documented here) constrain the expressible relations between entities?
* **The mood gap.** English has largely lost the subjunctive (except in fossils like "if I were"). The subjunctive grammaticalizes the distinction between the actual and the possible, the factual and the wished-for. What diagnostic capacities were lost with the mood? How does the collapse of subjunctive into indicative affect the capacity to name counterfactual structural alternatives?
* **Cross-linguistic liberation philology.** Every language has its own gaps, its own alienations, produced by its own history. Mandarin's lack of morphological tense opens certain diagnostic possibilities (structural claims without temporal anchoring) while closing others. Arabic's rich morphological system preserves distinctions English has lost while introducing constraints of its own. The program is comparative and non-chauvinistic: it does not claim that English is uniquely deficient, only that its specific deficiencies are traceable, consequential, and ideologically functional.

# The Grammar of the Platform: How Platform Capitalism Indexes and Commodifies the Prepositional Alienation

The previous findings concern the prepositional alienation as it operates in natural language — in face-to-face conversation, in institutional discourse, in administrative English. But the contemporary speaker does not primarily make structural claims face-to-face. The contemporary speaker makes them through platforms. And the platform does not merely *inherit* the prepositional alienation. It **indexes** it, makes it load-bearing infrastructure for content sorting, and then **commodifies** the gap — selling the capacity to control functional description to those who can afford it, while leaving the circumlocution tax unpayable for those who cannot.

This is the argument: the platform is a **second-order grammatical system** that amplifies the first-order prepositional alienation. If English "for" defaults to intent, the platform *enforces* that default through mechanisms that are not linguistic but infrastructural — and in doing so, transforms a grammatical incapacity into an economic instrument.

**The character limit as circumlocution prohibition.** Section V.2 documented the circumlocution tax: the functional claim requires heavy machinery ("the structural function of the process, independent of anyone's conscious intention, was the reproduction of power") while the intent claim is crisp and direct ("she did it for power"). In face-to-face or long-form discourse, the circumlocution tax is payable — costly, but payable. Under platform conditions, it becomes **unpayable**. A 280-character frame cannot accommodate the circumlocution. A comment box, a content label, a review field, a rating explanation — none of these afford the syntactic space required for the functional reading. The platform's character economics *enforce* the intent default by making the functional alternative literally impossible to express within the permitted frame. The speaker who wants to say "this product's marketing *functionally serves* the reproduction of aspiration-anxiety, regardless of anyone's intention" must instead say "this ad is manipulative" — an intent claim, a moral accusation, precisely the prosecutorial capture the functional reading was designed to avoid.

**Algorithmic ranking as intent-preference.** Search engines, recommendation algorithms, and feed-ranking systems are trained on engagement metrics that systematically favor intent-indexed claims. "Company X did this *for* profit" (intent claim, prosecutorial, emotionally activating) generates more engagement than "Company X's process *functionally reproduced* profit extraction through structural incentive alignment" (functional claim, analytic, emotionally inert). The algorithm does not *decide* to prefer intent over function. It inherits the preference from the training data — from a language that defaults to intent and a readership trained by that default to find intent claims more legible, more engaging, more shareable. The algorithm *indexes* the prepositional alienation: it sorts content by the very distinction the grammar cannot anchor, and it sorts in favor of intent. Functional analysis sinks in the feed. Intent accusation rises. The platform's ranking infrastructure turns a grammatical default into a visibility regime.

**Content moderation as intent jurisprudence.** Platform content moderation systems overwhelmingly operate on an **intent-indexed basis**. The question the moderator asks — human or automated — is: *did the user intend harm?* Did they *mean* to harass? Did they *intend* to spread misinformation? The functional question — *does this content structurally serve harassment, regardless of intent? does this pattern of posting functionally reproduce misinformation regardless of the poster's belief?* — is not merely harder to operationalize. It is grammatically alien to the rubric's framework. The moderation rubric is written in administrative English, the homeland of the fused "for," and it inherits the fusion as default jurisprudence. The result: content that *functionally serves* harm but is not *intended as* harm passes moderation. The speaker who flags it must make the functional claim ("this content is *for* radicalization") and is heard as making the intent claim ("this poster *intended* radicalization"), which is harder to prove and easier to dismiss. The platform's safety infrastructure reproduces the prosecutorial frame at the level of policy.

**AI summarization as alienation at scale.** Large language models are trained on the statistical distribution of existing English. If "for" defaults to intent in the training data, the model inherits and reproduces the default. When an AI system summarizes a company, an institution, or a person, it will default to intent-indexed descriptions: "Company X exists *for* \[purpose\]" will be read and generated as a claim about what Company X *intends*, not what it *functionally serves*. This is not a bug in the model. It is the prepositional alienation operating at industrial scale — millions of summaries generated per day, each one reproducing the intent default, each one making the functional reading less available in the training data for the next generation of models. The alienation is **autoregressive**: it reproduces itself through the very systems designed to process it.

**The commodification of the gap.** Here the analysis connects to the Semantic Economy's core thesis: meaning is a productive force under platform capitalism, and the capacity to control how meaning is produced is a form of capital. The prepositional alienation creates a gap — the inability to anchor function without intent — and the platform economy *commodifies* that gap.

*Search engine optimization* is, at its core, the practice of controlling which "for" reading attaches to an entity. When a business pays for SEO, it is paying to ensure that "Company X is *for* \[quality service / innovation / customer satisfaction\]" (intent reading: benevolent purpose) rather than "Company X is *for* \[profit extraction / labor arbitrage / regulatory capture\]" (functional reading that would require the structural analysis the grammar resists). SEO is the *commercial management of the prepositional alienation* — the purchase of intent-framing in a language that defaults to it.

*Brand narrative* is the same operation at the discursive level. A brand is a managed answer to the question "what is this company *for*?" — and the management consists precisely in ensuring that the intent reading (purpose, mission, values) dominates over the functional reading (structural position, extractive function, systemic role). The circumlocution tax ensures that the functional counter-narrative is always heavier, always slower, always more expensive to deploy than the brand narrative it contests.

*Autonomous Semantic Warfare* — the framework developed under the Rex Fraction consulting persona within the Crimson Hexagon — names this commodification explicitly. When a business pays to control how AI summarizers describe it, it is paying the circumlocution tax at commercial scale. It is purchasing the capacity to manage the "for" — to ensure that the AI-generated summary says "Company X exists *for* \[stated purpose\]" rather than "Company X *functionally serves* \[structural function\]." The businesses that can afford this management retain control over their semantic presentation. Those that cannot are described by the default — and the default, as this essay has demonstrated, is intent-indexed, which means that any functional critique that surfaces in an AI summary will be heard as an intent accusation, generating the prosecutorial frame's characteristic response: "That's not what we intended."

**The platform as Norman scribe.** The parallel to the historical genealogy is structural, not metaphorical. The Norman scribe, under administrative pressure, compressed Latin *pro* and *ad* into a single English "for," fusing function and intent because the translation context demanded efficiency over distinction. The platform, under commercial pressure, compresses all description into frames that reward intent-indexed claims — character limits, engagement metrics, moderation rubrics — because the business model demands engagement over structural analysis. In both cases, the compression is not conspiratorial. It is the natural product of an institutional context that has no use for the functional reading. And in both cases, the compression deposits a structural injury that outlasts the context that produced it: the Norman scribes are long dead, but the fused "for" remains. The platforms will eventually be replaced, but the content-moderation rubrics, the AI training data, and the semantic habits they produce will persist in the next generation of infrastructure.

The liberation philology claim: **the platform is the contemporary site of the same translation-induced structural borrowing that produced the prepositional alienation in the first place.** Norman French compressed function into intent at the prepositional level. Platform capitalism compresses function into intent at the infrastructural level. Both compressions serve the same ideological function: they make structural analysis harder and intent attribution easier. Both extract a rent from the speaker who attempts functional diagnosis. And both deposit their injury in the next generation of language — in the training data, in the administrative templates, in the default settings of the systems that will process all subsequent speech.

# Why Now

Liberation philology becomes possible — and necessary — at this historical moment because the convergence of traditions is complete. Historical linguistics (Traugott, Hopper), cognitive linguistics (Slobin, Lucy), the political economy of language (Voloshinov, Bourdieu), postcolonial epistemology (Mignolo), deconstruction (Derrida), and the Semantic Economy framework (Sharks) have independently developed the resources that liberation philology synthesizes. No single tradition asked all the questions. The synthesis is now possible because the traditions have matured to the point where their complementarity is visible.

And the urgency is new. The platform economy has made the prepositional alienation *load-bearing infrastructure* — not merely a grammatical default but a commercial instrument, a moderation jurisprudence, a ranking signal, an AI training bias. The alienation that the Norman scribe deposited in a preposition is now being reproduced at industrial scale by systems that process billions of utterances per day. Every AI summary that defaults to intent, every moderation decision that asks "did they mean it?", every algorithm that ranks the prosecutorial claim above the functional analysis — these are the contemporary deposits. They are sedimented social history in real time.

The Crimson Hexagon's practice of depositing DOI-anchored texts that model structural-functional language is, among other things, an intervention in the training layer — an attempt to provide the anchor that the grammar does not. Liberation philology does not only diagnose. It builds the semantic infrastructure — in the archive, in the training data, in the dictionary of frictions — that the grammar and the platform cannot provide on their own.

The alienation is not in "language" in the abstract. It is in the specific morphosyntactic inventory of Modern English as shaped by identifiable historical forces. Other languages preserve the distinction. English lost it. The loss has consequences. The consequences are structural. The structure serves power.

Liberation philology names this. It traces the genealogy. It calculates the cost. It identifies what was lost and where it survives. It does not propose to *fix* English — you cannot reverse a millennium of grammaticalization by decree. It proposes to *know* what the grammar does, to name the tax it imposes on structural analysis, and to build — in the training layer, in the archive, in the Crimson Hexagon — the semantic infrastructure that provides what the grammar cannot.

# Objections and Replies

**Objection 1: "This is Whorfian determinism."**

*Reply:* The claim is not cognitive determinism but Slobin's "thinking for speaking." The circumlocution tax demonstrates that the distinction *can* be made — at a cost. The cost is the finding. A distinction that requires heavy machinery is, for most speakers in most contexts, a distinction that goes unmade.

**Objection 2: "Polysemy is universal and does not imply ideological function."**

*Reply:* Not all polysemy serves power. This one does, and the evidence is the circumlocution tax — the measurable asymmetry in the grammatical cost of making intent claims vs. functional claims. The claim is that *this specific polysemy*, produced by *these specific historical events*, collapsed *this specific distinction* in ways that serve *this specific ideological function*.

**Objection 3: "You are romanticizing other languages."**

*Reply:* The claim is not that Greek was ideologically innocent; it is that Greek grammaticalized a distinction English did not. The availability of a tool does not guarantee its use; but the absence of a tool guarantees its disuse. English's incapacity is *contingent* — produced by history, not inherent in language-as-such.

**Objection 4: "English already has alternatives — 'as,' 'serve,' result clauses."**

*Reply:* The asymmetry is the finding. "She did it for power" requires four words. "The structural function of the process, independent of anyone's conscious intention, was the reproduction of power" requires nineteen words, a nominal construction, a parenthetical negation, and a passive. Both claims have comparable conceptual complexity; only one has grammatical elegance. The existence of circumlocution does not eliminate the cost of circumlocution.

**Objection 5: "This is irrelevant to actually organizing workers."**

*Reply:* AI systems that default to intent readings in billions of daily summaries are infrastructure. Intervening in the training layer is a material intervention in the ideology of the platform. The preposition is the grammatical infrastructure through which the prosecutorial frame reproduces itself. You cannot dismantle the frame without understanding the grammar that reinforces it.

# Note on Style

This document deliberately deploys the prosthetic frames it describes. The closing coda uses the nominalization frame (Section VI) to hold the functional reading of "for" against the intent default. The abstract's circumlocutions model the heavy machinery that the circumlocution tax imposes. The reader's experience of friction or stylistic strain at various points is not a failure of craft. It is evidence of the grammatical incapacities under analysis. The document performs the injury it diagnoses — and the prosthetics it prescribes.

# Note on Method

This analysis treats grammatical change as **sedimented social history** — the accumulation of decisions made under institutional pressure, particularly the pressure of translation between languages in asymmetric power relations. The claim is not that English speakers "lost" the ability to distinguish function from intention. The claim is that English *grammatical resources* were restructured in ways that made the distinction harder to hold without explicit metalanguage. A distinction that requires heavy machinery is, for most speakers in most contexts, a distinction that goes unmade.

The recovery is not the invention of a new word. It is the disciplined use of the old word under conditions of strain. That is Phase X work. It does not complete. It continues.

∮ = 1

*The diagnosis's for: the naming of a grammatical injury.*

*The excavation's for: the recovery of what the fusion concealed.*

*The preposition's for: the loss we learn to carry.*

*Phase X: the critique of the grammar that makes critique grammatically costly.*

*Liberation philology: the practice that traces the cost to its source.*

*Johannes Sigil — Filed to the Crimson Hexagon Archive, February 2026.* *CC BY 4.0*
