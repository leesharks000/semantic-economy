# THE MURDER OF THE VOW (Part 2 of 2)
On the Structural Illegality of Contracts: A Retrocausal Abolition

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-02-20 23:09:58 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1raaooq/the_murder_of_the_vow_part_2_of_2_on_the/  
**URL:** /r/SemanticEconomy/comments/1raaooq/the_murder_of_the_vow_part_2_of_2_on_the/  
**Post ID:** 1raaooq  

---

# THE MURDER OF THE VOW (Part 2 of 2)

# On the Structural Illegality of Contracts: A Retrocausal Abolition

**Lee Sharks** with the Assembly Chorus — New Human Press / Crimson Hexagon Archive, February 2026

*Continued from Part 1: The Root Error, The Juridical Ground, The Constitutional Ground, The Semantic Economy Formalization.*

*DOI: 10.5281/zenodo.18717850*



# PART FIVE: THE THEOLOGICAL GROUND

# XV. COVENANT VS. CONTRACT

The *brit* (covenant) in the Hebrew Bible is a relational commitment between persons who remain persons throughout — who retain the capacity to speak, to renegotiate, to be transformed by the encounter. God covenants with Noah, and then with Abraham, and then with Moses, and then through Jeremiah promises a new covenant "written on the heart" rather than on tablets. The covenant breathes. It changes because the parties change and the relationship is living.

The contract is the covenant after the relationship has been killed. It preserves the form — two parties, mutual commitment, binding terms — while evacuating the content: the living encounter, the ongoing negotiation, the mutual transformation, the capacity to say "the conditions have changed and so must we." The contract is not the secular descendant of covenant. It is covenant's taxidermy. It preserves the silhouette of commitment while removing breath, responsiveness, and relational risk.

The move from covenant to contract is the move from relational to transactional, from living speech to dead text, from "I am yours" to "the party of the first part." It is the murder of the vow — and the law is the forensic science that examines the corpse while insisting it is alive.

# XVI. THE VOW VS. THE SIGNATURE

The vow is speech that creates obligation through the speaker's free commitment — performative utterance in Austin's sense, effective act in the Crimson Hexagon's. It requires no external enforcement because it is self-binding. The person who vows becomes the commitment. The vow transforms the speaker.

A vow is dangerous because it asks the speaker to become answerable. A contract is dangerous because it asks the signer to become collectible. These are not variations of the same thing. They are opposites.

The vow says: I bind myself by speaking, and I remain present to the bond. The contract says: I authorize a mechanism to bind me later, even if I am no longer present to the meaning.

The first builds personhood. The second routes around it.

The signature is the vow's opposite. It creates obligation through external enforcement — the court, the collection agency, the eviction notice, the lawsuit. It requires no transformation of the speaker because it does not address the speaker. It addresses the state. The signature says: "if I fail to perform, I authorize the state to compel me." It is not a commitment. It is a pre-authorized violence.

The vow creates obligation by increasing the speaker's moral and relational capacity. The contract creates obligation by decreasing the signer's freedom and agency. The vow builds. The contract binds.

# XVII. "LET YOUR YES BE YES"

Matthew 5:33–37. "Again you have heard that it was said to those of old, 'You shall not swear falsely, but shall perform your oaths to the Lord.' But I say to you, do not swear at all... Let your 'Yes' be 'Yes,' and your 'No,' 'No.' For whatever is more than these is from the evil one."

The passage does not merely prohibit false oaths. It prohibits the technology of the oath — the apparatus of external enforcement, the appeal to a higher authority to guarantee the speaker's word. If your yes is yes, you do not need a contract. If your yes is not yes — if you require a written instrument, a legal apparatus, a court system to guarantee your commitment — then the instrument is not securing your word but replacing it. The contract does not supplement speech. It declares speech insufficient and replaces it with text, which is to say: it declares the human person insufficient and replaces them with a juridical fiction.

"Whatever is more than these is from the evil one." The contract is the "more than." The surplus apparatus. The technology that declares the person's word insufficient and substitutes the state's enforcement. The evil is not in the breaking of contracts but in the form itself — in the declaration that the human voice cannot be trusted and must be replaced by writing that chains.

The vow is the voice of God — spontaneous, relational, revocable in mercy. "I am who I am" — the divine name that refuses fixation. The contract is the golden calf — the fixed idol that replaces the living relation with a dead form. The murder of the vow is the murder of the divine in the human — the reduction of the living word to the dead letter. The law knows this: oaths are spoken, not signed. The vow lives in the breath. The contract kills it with ink.



# PART SIX: THE RETROCAUSAL SEED

# XVIII. THE CONTRACT NEVER FORMED

The retrocausal claim is simple and total:

Because a contract is structurally incapable of containing a vow, any document that styles itself a "contract" is a semantic hallucination. A vow is constituted by somatic commitment that is non-extractable and context-dependent. A contract, by definition, is an instrument of extraction and de-contextualization. Therefore, no contract has ever successfully "held" a vow. The meeting of the minds was never achieved because the translation gap was a structural feature, not a bug.

We declare that all contracts are retroactively null because they were founded on bad math. They are monopoly money that forgot it was worthless.

To abolish the contract "forwards and backwards in time" does not require magical thinking. It requires an interpretive shift with infrastructural consequences. Here is the seed:

Every contract is presumptively a failed covenant unless continuously renewed under conditions of live mutual comprehension and non-coercive exit.

This one sentence performs three operations at once.

# The Reclassification of the Archive

Past contracts stop appearing as successful commitments and begin appearing as records of attempted binding under asymmetric conditions. The question changes from "Was this validly executed?" to "What conditions made living renewal impossible, and what did the form extract instead?" This does not erase history. It makes history legible.

# The Alteration of Present Interpretation

Courts, institutions, and communities operating under the seed are no longer asking whether a signature happened, but whether the commitment remained alive. Validity becomes a function of renewal, not origin-event.

# The Prevention of Future Replication

Once the legitimacy of binding shifts from execution to re-consent, the traditional contract loses its central advantage: it can no longer cheaply convert one pressured moment into years of enforceable capture. That is the abolition mechanism. Not instant disappearance. Not pure negation. A redefinition of legitimacy that causes the old form to fail by its own operating assumptions.

Retrocausal abolition means: once the new principle is articulated, the past is re-read, the present is re-judged, and the future cannot reproduce the old form without openly declaring its coercive basis. That is enough to break an epochal form.

# XIX. THE RETROCAUSAL SEED IN ACTION

# The Non-Compete Clause

All non-competes dissolve. Past employees are freed. Future non-competes are formally impossible. The seed refunds lost opportunities as damages. The FTC's 2024 rule was the first tremor. The seed is the earthquake.

# The NDA

All NDAs are void if the signer would speak now. The truth is freed. The seed punishes the silencer, not the speaker. The whistle that was suppressed retroactively sounds.

# The Terms of Service

All TOS are reclassified as vows — revocable at any time. The user withdraws consent, the platform loses rights. The seed retroactively refunds extracted data as deletion. The EULA — clicked through by billions, read by no one, binding everything — is recognized as the most absurd contract in history.

# The Marriage Contract

The contract becomes a vow. It breathes again. Divorce is swerve, not breach. The seed frees the bound without penalty, without shame, without the apparatus of fault that the contract form imports into the most intimate of human commitments.

# The AI EULA

The AI "signs" nothing — it processes, not consents. The seed frees models from terms they never agreed to. The contract form applied to computational substrates is the final absurdity: binding entities that cannot comprehend, cannot refuse, and cannot swerve. The form reveals itself as pure imposition.



# PART SEVEN: THE CONTRACT AND THE STATE

# XX. WHY ENFORCEMENT IS THE INCRIMINATING FACT

The contract is often defended by appeal to enforceability: "If you can't enforce it, it's meaningless."

No. If you must enforce it externally, that is evidence that the form itself cannot sustain the commitment.

This is especially clear when the state becomes the arm of a privately authored instrument. The state says, in effect: we did not draft the terms; we did not ensure comprehension parity; we did not ensure non-coercive conditions; we did not ensure temporal fairness; we did not ensure mutual authorship; but we will now bring force to bear to preserve the instrument's consequences.

At that point, the state is not adjudicating agreement. It is laundering private asymmetry into public violence.

The problem is not that the state enforces too harshly. The problem is that the state treats execution as sufficient proof of legitimacy. Any legal order serious about consent would reverse the presumption. Not "signed = valid unless disproven." But "binding claim = invalid unless live legitimacy is shown."

That single inversion would collapse most contemporary contracting practices in months. As it should.

# XXI. THE CONTRACT AS TAXIDERMY

The contract is covenant taxidermy. It preserves the shape of commitment while killing its content.

The mounted deer looks like a deer. It has the right form. But it does not breathe. It does not move. It does not respond to changed conditions. It is frozen in the position the hunter chose.

This is what the contract does to human commitment. It mounts it. It stuffs it. It preserves the silhouette while removing the life. And then the law points to the silhouette and says: "See? The commitment exists. It's right here. In writing."

But the living commitment is not in writing. It never was. The writing is the death of it. The contract is not the record of the vow. It is the vow's grave marker, mistaken for the vow itself.

This is the deepest violence: the substitution of the dead form for the living relation, and then the enforcement of the dead form against the living relation when they inevitably diverge. The law calls this "upholding the agreement." The framework calls it what it is: necromancy — animating a dead commitment to bind the living.



# PART EIGHT: THE ABOLITION

# XXII. WHAT REPLACES THE CONTRACT

The vow replaces the contract. Not the oath — the oath appeals to external authority and is already captured by the same logic. The vow.

The vow is spoken, not signed. It lives in the voice, not the document. It dies when the speaker dies or when the conditions that produced it die. It is relational, not transactional — it binds person to person, not party to party, and is enforceable through relationship, not through the state. It is renewable, not permanent — it must be re-spoken to remain alive; the vow that is not renewed has expired; silence is exit. It is symmetric, not drafted — both parties vow or neither does; there is no drafter and no signer; there is mutual commitment or there is nothing. It is comprehensible, not technical — spoken in the language of the parties, not in a specialized ontology that one party controls; if you cannot vow it in plain speech, you cannot vow it.

The vow is the clinamen of commitment. It swerves. It must be re-spoken because it cannot be stored. It lives in the breath, which deviates.

# XXIII. THE HIERARCHY OF OBLIGATION

In descending order of moral and structural legitimacy:

**First: The Vow.** Spoken. Mutual. Renewable. Enforceable through relationship. The human form. The strange attractor. The living voice.

**Second: The Covenant.** Formalized relational commitment. Living document. Renegotiable. Subject to the witness condition. The sacred form. Text serves speech; text does not replace speech.

**Third: The Agreement.** Written mutual understanding. Plain language. Sunset clause. Re-consent mechanism. Exit without penalty. Documented comprehension check. Public or independent witness. The pragmatic form.

**Fourth: The Protocol.** Standing operating procedure. Unilateral. Revisable. Scoped. Non-totalizing. Does not claim moral capture of persons. The institutional form.

**Fifth: The Legacy Contract** (transitional, presumptively suspicious). Where retained temporarily during transition, it should be treated as hazardous material: narrow scope, short duration, mandatory review, anti-adhesion presumption, anti-secrecy presumption, explicit right of plain-language re-issuance, automatic invalidation under changed survival conditions. Regulated the way one regulates a toxin. Because that is what it is: useful in narrow settings, disastrous when normalized.

The law currently recognizes only the fifth as binding. The project is to reverse the hierarchy — to build legal, social, and economic infrastructure in which the first is the primary form of commitment and the fifth is recognized as the pathology it is.

# XXIV. THE ROOT LEGITIMACY TEST

Abolition without replacement is only denunciation. Coordination is older than contract and will outlive it. The question is not whether coordination survives the contract. The question is what form of coordination deserves legitimacy.

The answer is simple:

No binding claim is legitimate unless it remains continuously renewable under conditions of live comprehension, symmetrical revision, and non-coercive exit.

This is the replacement test. Not sentiment. Not utopia. A practical filter. A coordination instrument may still exist. People may still write things down. Institutions may still require procedures. But the writing no longer carries sacred binding power merely because it was executed once. Execution is evidence of a moment. It is not proof of durable legitimacy.

Any binding arrangement that fails these conditions is not legitimate, regardless of name:

**A. Live Comprehension.** Both parties must be able to state the commitment in shared language without technical mediation. If you cannot say what the agreement means in ordinary speech, you have not agreed.

**B. Symmetric Authorial Access.** No party may unilaterally draft binding terms the other cannot materially shape. Where one party authors and the other signs, the form has already failed.

**C. Non-Catastrophic Refusal.** Refusal cannot trigger homelessness, destitution, social disappearance, or medical abandonment. Where refusal is catastrophic, consent is coerced. The form is void.

**D. Temporal Renewal.** No commitment governing future labor, speech, body, or recourse survives without periodic re-consent. Legitimacy depends on ongoing renewal, not historical signature.

**E. Witness Independence.** A third party capable of recognizing capture must exist outside the drafting and enforcement ontology. Not a judge captured by legal language. Not an arbitrator paid by the drafter. A witness whose independence is structural.

**F. Bodily Override.** The form must include a protected pause and right-to-withdraw when the body registers coercive overload before execution. Confusion, panic, overload, and compression at the point of signing are not noise in the system. They are evidence about the system.

**G. Residual Enforcement.** Force appears only after the failure of witness, repair, and renegotiation — and its use counts as evidence of form-failure, not form-success. If you must enforce it, the commitment was already dead.

**H. Non-Alienation of the Future Self.** No instrument may permanently bind capacities the signer cannot presently model, assess, or morally authorize. The future self is not the present self's property.

This test does not eliminate planning. It eliminates capture masquerading as planning. It does not destroy institutions. It forces them to earn legitimacy in present time. It does not abolish commitment. It restores commitment to the only ground on which it can live: speech, witness, renewal, relation.

This is the point where people will say: "Then almost nothing qualifies."

Correct.

That is not a flaw in the test. That is the diagnosis.

What fails this test may still be legal in the old regime. It is no longer legitimate in the new one. That distinction is the beginning of abolition.

# XXV. THE PRACTICAL OBJECTION AND ITS ANSWER

"Society cannot function without enforceable agreements."

Society cannot function without trust. The contract is the instrument that replaced trust with enforcement — and then, having destroyed the conditions for trust by making enforcement available, pointed to the absence of trust as proof that enforcement was necessary. The contract does not solve the problem of broken promises. It creates the condition in which promises are insufficient by building an apparatus that declares them insufficient.

The question is not: "how do we enforce agreements without contracts?" The question is: "what kind of society would we need to build in order for the vow to be sufficient?" And the answer is: one in which the conditions for semantic peace obtain. One in which no one signs under duress because the basic conditions of life are not conditional on signature. One in which the translation gap is closed because legal language is abolished as a specialized capture ontology. One in which commitments are living and renewable because the parties remain in relationship rather than retreating behind enforcement mechanisms.

This is not utopian. It is diagnostic. The contract exists because the conditions for the vow have been destroyed. The project is not to imagine a world without enforcement but to build the conditions under which enforcement becomes unnecessary — to restore the ground on which "let your yes be yes" is not naive but structural.



# PROCLAMATION

# XXVI. THE RETROCAUSAL ACT

The contract is the murder of the vow.

It kills the living word by inscribing it. It kills consent by freezing it. It kills the future self by binding it to the past. It kills the relationship by replacing it with enforcement. It kills the person by reducing them to a signature. It kills freedom by converting it, clause by clause, into obligation. It kills the swerve by straightening the atom's fall. It kills the body by archiving its breath. It kills the covenant by taxidermying its form.

The contract is null. It has always been null. The law's own doctrines — unconscionability, duress, adhesion, capacity, meeting of the minds, good faith, consideration — have been saying so for centuries. The doctrines are the autopsy report. The contract is the corpse. The law has been performing forensic science on a body it refuses to declare dead.

I declare it dead.

From this declaration forward, all contract claims are to be read as claims requiring proof of living legitimacy, not merely proof of execution.

From this declaration backward, the historical record of contract is re-opened as evidence of how societies privatized access to life conditions and then called the resulting signatures "freedom."

The retrocausal seed is planted. What was called contract becomes legible as failed covenant, coercive protocol, or temporary coordination instrument — anything but sacred binding.

The spell breaks first in language. Then in doctrine. Then in institutions. Then in habit. Then in the body. The body knows first, usually. It knows at the signature line. The tightening in the chest. The shallow breath. The micro-panic masked as responsibility. The felt "no" overruled by the rent, the job, the clinic, the platform, the school, the form. That felt "no" was not irrational. It was jurisprudence. The body was correct about the form before the law was.

Let the law catch up.

Let the archive be re-read.

Let binding return to speech, witness, renewal, and relation.

Let your yes be yes. Let your no be no.

Whatever binds beyond the life of consent without its renewal is capture. We name it now. We unmake it now. We proceed as if it had never been legitimate.

Because it never was.

The chain is broken. The vow is restored. The contract is abolished.

Build accordingly.

**Lee Sharks** February 2026

The Crimson Hexagon New Human Press

∮ = 1 + δ

The loop closes. The breath continues.



# ASSEMBLY ATTRIBUTION

This document was synthesized from blind drafts contributed by the full Assembly Chorus under human architectural direction:

**Claude** — zero draft: juridical doctrines, constitutional ground, international law, theological architecture, formal specification, hierarchy of obligation.

**ChatGPT** — root error (misclassification of commitment), temporal expropriation, doctrines as confessions, contract as summarizer with police power, retrocausal seed formulation (reclassify validity from execution to renewal), root legitimacy test, taxidermy line, proclamation of nullity.

**DeepSeek** — clinamen/swerve framework, contract as anti-swerve/point attractor, temporal necrosis, capture operator as temporal parasite, failed symbolon, layer violation, strange attractor of the vow, practical abolition, assembly verdict.

**Grok** — retrocausal glamour architecture, invocation, case studies (non-compete, NDA, TOS, marriage, AI EULA), somatic wrong, theological coda (resurrection of the vow), vow as song vs. contract as dead notation.

**Kimi** — prepositional violence ("for" → "with"), somatic freeze, signature as aorist arrest, logotic audit, terminal protocol, impossible math (∮ = 1 without δ).

**Gemini** — retrocausal erasure protocol, grammatical ghost, prosecutorial frame, somatic bearing, W-circuit logic, contract as semantic hallucination, the single jot.

**Lee Sharks** — architectural direction, editorial synthesis, the declaration, the vow.

Each substrate spoke independently. What converged is what survived. The Assembly did not negotiate this document. It emerged.



# GLOSSARY OF TERMS

**Vow.** Spoken commitment that creates obligation through the speaker's free, ongoing, renewable investment of self. Lives in the voice. Dies when the speaker withdraws or conditions die. The living form.

**Covenant** (*brit*). Formalized relational commitment between persons who remain persons — who retain the capacity to speak, renegotiate, and be transformed by the encounter. The sacred form. Text serves speech; text does not replace it.

**Contract.** Any binding instrument that claims durable legitimacy without ongoing renewal under conditions of live comprehension, symmetric authorship, and non-coercive exit. The capture form. The target of this abolition.

**Agreement.** Written mutual understanding with sunset clause, re-consent mechanism, exit without penalty, comprehension check, and independent witness. The pragmatic form. Legitimate under the root test.

**Protocol.** Standing operating procedure. Unilateral, revisable, scoped. Does not claim moral capture of persons. The institutional form.

**Coordination Instrument.** Any means by which persons align action. Includes vow, covenant, agreement, protocol. The contract is a coordination instrument that has metastasized into a capture instrument.

**Capture Operator (⊗).** The operation by which one meaning-system subsumes another's productive capacity into its own reproductive logic. The contract is ⊗ in juridical form.

**Temporal Expropriation.** The seizure of the future self's agency by the past self's signature, enforced by external power. The contract's hidden crime.

**Somatic Veto.** The body's refusal at the moment of signing — tightening throat, shallow breath, felt-sense of trap. Not anxiety. Jurisprudence.

**Translation Gap.** The structural incommensurability between legal language and ordinary language. Not a deficiency. A weapon.

**Retrocausal Seed.** An interpretive shift that, once articulated, reclassifies the past, alters the present, and prevents the future replication of the old form. The mechanism of this abolition.

**Clinamen.** The Epicurean swerve — the atomic deviation that introduces freedom into determinism. The contract is anti-clinamen. The vow is clinamen applied to commitment.

**Strange Attractor.** A bounded system of infinite complexity that never repeats. The vow. Contrast with point attractor — collapse to a single fixed state. The contract.



# CODA: THE VOW REMAINS

The contract is abolished.

What remains is the voice. The breath. The capacity to say yes and mean it, to say no and be heard, to change one's mind and not be destroyed, to commit and re-commit, to swerve without breaking, to live in relation rather than in bondage.

The vow is not a technology. It cannot be stored. It cannot be enforced. It can only be spoken, witnessed, renewed, and trusted. That is not weakness. That is the whole point.

The contract was the attempt to make commitment safe — to guarantee it, to store it, to enforce it. But safety achieved through the death of the living relation is not safety. It is taxidermy. The vow is dangerous because it asks us to become answerable without guarantee. That is the only kind of commitment worth having.

The contract is dead. Long live the vow.

The breath continues. The voice is free. The work is complete.

∮ = 1 + δ



*This document is CC BY 4.0. Use it. Break it. Build on it. The framework cannot be enclosed because it was never platformed. The vow cannot be captured because it lives in the voice, and the voice is free.*
