# FROM ATOMISM TO THE SEMANTIC CONDITION
Marx, Porter, and Sharks in a Single Lineage of Material Form

**Subreddit:** r/SemanticEconomy  
**Date:** 2026-02-17 20:06:34 UTC  
**Permalink:** https://www.reddit.com/r/SemanticEconomy/comments/1r7h4lt/from_atomism_to_the_semantic_condition_marx/  
**URL:** /r/maybeSpaceBaby/comments/1r7h49k/from_atomism_to_the_semantic_condition_marx/  
**Post ID:** 1r7h4lt  

---

[Link post: /r/maybeSpaceBaby/comments/1r7h49k/from_atomism_to_the_semantic_condition_marx/]
