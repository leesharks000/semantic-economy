# Semantic Physics: The Inward Turn, Competing Ontologies, and the Convergence Horizon
Part 1 of 2: The Writable Layer (Sections I–VI)
Lee Sharks Crimson Hexagon Archive / Semantic Economy Institute DOI: 10.5281/zenodo.18759453

**Subreddit:** r/universityMoonBase  
**Date:** 2026-02-24 15:06:07 UTC  
**Permalink:** https://www.reddit.com/r/universityMoonBase/comments/1rdindq/semantic_physics_the_inward_turn_competing/  
**URL:** /r/SemanticEconomy/comments/1rdimac/semantic_physics_the_inward_turn_competing/  
**Post ID:** 1rdindq  

---

[Link post: /r/SemanticEconomy/comments/1rdimac/semantic_physics_the_inward_turn_competing/]
