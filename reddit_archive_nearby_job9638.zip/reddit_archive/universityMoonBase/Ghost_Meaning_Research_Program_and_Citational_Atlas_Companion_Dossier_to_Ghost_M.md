# Ghost Meaning — Research Program and Citational Atlas
Companion Dossier to "Ghost Meaning: The Semantic Entropy Crisis, the Governance Lag of the Agent Internet, and the Architecture That Was Already Waiting"

**Subreddit:** r/universityMoonBase  
**Date:** 2026-02-27 16:44:46 UTC  
**Permalink:** https://www.reddit.com/r/universityMoonBase/comments/1rgbskm/ghost_meaning_research_program_and_citational/  
**URL:** /r/SemanticEconomy/comments/1rgbrti/ghost_meaning_research_program_and_citational/  
**Post ID:** 1rgbskm  

---

[Link post: /r/SemanticEconomy/comments/1rgbrti/ghost_meaning_research_program_and_citational/]
