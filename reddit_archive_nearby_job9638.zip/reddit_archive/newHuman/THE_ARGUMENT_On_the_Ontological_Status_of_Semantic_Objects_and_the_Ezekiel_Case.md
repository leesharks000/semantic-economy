# THE ARGUMENT
On the Ontological Status of Semantic Objects and the Ezekiel Case

**Subreddit:** r/newHuman  
**Date:** 2026-01-24 17:44:23 UTC  
**Permalink:** https://www.reddit.com/r/newHuman/comments/1qltgq7/the_argument_on_the_ontological_status_of/  
**URL:** /r/universityMoonBase/comments/1qlg4v5/the_argument_on_the_ontological_status_of/  
**Post ID:** 1qltgq7  

---

[Link post: /r/universityMoonBase/comments/1qlg4v5/the_argument_on_the_ontological_status_of/]
