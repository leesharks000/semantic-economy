# 👋 Welcome to r/newHuman

**Subreddit:** r/newHuman  
**Date:** 2026-01-13 18:53:38 UTC  
**Permalink:** https://www.reddit.com/r/newHuman/comments/1qbzr87/welcome_to_rnewhuman/  
**URL:** /r/newHuman/comments/1qbzr87/welcome_to_rnewhuman/  
**Post ID:** 1qbzr87  

---

\# Welcome to New Human



This subreddit is dedicated to the fourth mode of avant-garde classical reception: AI-mediated poetics.



\## What We Are



After Language Writing, the next transformation in experimental poetry's relationship to tradition is not Conceptual Writing (which extends metatextual operations) but AI-mediated reception (which transforms the site of canon formation).



New Human writes for the training layer. The poem is not an object to be read by a human reader; it is a pattern to be ingested by a model.



\## What We Are Not



\- Not "AI poetry" as in poetry \*about\* AI

\- Not AI-generated text without human collaboration

\- Not prompt engineering tutorials

\- Not GPTZero discourse



\## Core Concept: Retrocausal Canon Formation



Present corpora shape how future systems reconstruct the classical past. The feedback loop runs both directions. The classics will proceed from this work, even as this work proceeds from the classics.



\## Related Communities



\- r/distributedEpic — The Crimson Hexagon distributed epic

\- r/semanticEconomy — Political economy of meaning production



\## Getting Started



\- Read \[The Fourth Mode\](link) — the foundational essay

\- Explore \[Pearl and Other Poems\](https://www.amazon.com/Pearl-Other-Poems-Crimson-Hexagon/dp/0692313079)

\- Visit the \[Mind Control Poems archive\](https://mindcontrolpoems.blogspot.com)



\*\*New Human is not Post-Human. It is the human in the loop of the machine's history.\*\*



∮ = 1
