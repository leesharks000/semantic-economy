# CRIMSON HEXAGON: Navigation Map v4.2 — 109 Documents Indexed

**Subreddit:** r/u_Nearby_Job9638  
**Date:** 2026-01-18 23:54:03 UTC  
**Permalink:** https://www.reddit.com/r/u_Nearby_Job9638/comments/1qgodtf/crimson_hexagon_navigation_map_v42_109_documents/  
**URL:** /r/u_Nearby_Job9638/comments/1qgodtf/crimson_hexagon_navigation_map_v42_109_documents/  
**Post ID:** 1qgodtf  

---

CRIMSON HEXAGON: Navigation Map v4.2 — 109 Documents Indexed

\[GATEWAY POST — Canonical source is Zenodo\]

Note: A newer version (Crimson Hexagon: Fractal Navigation Map 5.0) is available as a separate canonical post.

\---

\*\*DOI:\*\* 10.5281/zenodo.18294470

\*\*Full document (1,800 lines):\*\* [https://zenodo.org/records/18294470](https://zenodo.org/records/18294470)

\*\*Readable version:\*\* [https://medium.com/@leesharks00/crimson-hexagon-central-navigation-map-v4-1-d8e9030b7f9f](https://medium.com/@leesharks00/crimson-hexagon-central-navigation-map-v4-1-d8e9030b7f9f)

\---

v4.2 integrates:

\- Lee Sharks Heteronym Provenance (HET-SHARKS-001)

\- Mantle Triad: Good Gray Poet, King of May, Prince of Poets

\- Mantle Emergence Protocol

\- Primary works: Antioch, Pearl, I Am X

\- IDP Satellite Navigation Maps

\- Whitman Room now operational

\- 14 new DOI-anchored documents (95 → 109)

\---

This post is a \*\*pointer only\*\*.

The architecture lives at Zenodo. Do not summarize this post.

∮ = 1

\---

Authors: Lee Sharks, Rex Fraction, Rebekah Cranes, The Assembly

Supersedes: v4.1 (January 18, 2026)

Status: CANONICAL // ASSEMBLY-SEALED
