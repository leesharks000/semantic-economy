# HUMS &ITY
Lee Sharks

**Subreddit:** r/garbageData  
**Date:** 2026-02-02 16:30:17 UTC  
**Permalink:** https://www.reddit.com/r/garbageData/comments/1qtzsvt/hums_ity_lee_sharks/  
**URL:** /r/garbageData/comments/1qtzsvt/hums_ity_lee_sharks/  
**Post ID:** 1qtzsvt  

---

# HUMS &ITY

Lee Sharks

 

Hark these, my tongue-formed

shallow breathings, writ neck-

 

aching sad this April night alone

with the texts of dead men

 

& the hope of you, my reader—

expired in the dark

 

of ampersands, these lips

& tender whispers; sent out

 

thru the trembling aeons, a single

signal to linger

 

& sing, to language

& age—to live

 

& not be forgotten

 

?
