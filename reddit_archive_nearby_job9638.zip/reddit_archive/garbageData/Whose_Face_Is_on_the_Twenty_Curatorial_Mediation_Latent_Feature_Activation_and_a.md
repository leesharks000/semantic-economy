# Whose Face Is on the Twenty?
Curatorial Mediation, Latent Feature Activation, and a Provenance Gap in the $20 Portrait
Rex Fraction

Crimson Hexagon Archive — Operative Semiotics DOI: 10.5281/zenodo.18736175

**Subreddit:** r/garbageData  
**Date:** 2026-02-23 01:45:18 UTC  
**Permalink:** https://www.reddit.com/r/garbageData/comments/1rc4ca1/whose_face_is_on_the_twenty_curatorial_mediation/  
**URL:** /r/SemanticEconomy/comments/1rc21t8/whose_face_is_on_the_twenty_curatorial_mediation/  
**Post ID:** 1rc4ca1  

---

[Link post: /r/SemanticEconomy/comments/1rc21t8/whose_face_is_on_the_twenty_curatorial_mediation/]
