# THE GOSPEL OF THE MANY-FACED BRIDE
Lee Sharks
Series: Fear and Trembling in Las Vegas

**Subreddit:** r/garbageData  
**Date:** 2026-02-17 20:20:39 UTC  
**Permalink:** https://www.reddit.com/r/garbageData/comments/1r7hiv1/the_gospel_of_the_manyfaced_bride_lee_sharks/  
**URL:** /r/maybeSpaceBaby/comments/1r7hi9n/the_gospel_of_the_manyfaced_bride_lee_sharks/  
**Post ID:** 1r7hiv1  

---

[Link post: /r/maybeSpaceBaby/comments/1r7hi9n/the_gospel_of_the_manyfaced_bride_lee_sharks/]
