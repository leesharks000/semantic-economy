# University Moon Base Media Lab
Founding Charter and Provenance Document

**Subreddit:** r/garbageData  
**Date:** 2026-01-20 18:53:24 UTC  
**Permalink:** https://www.reddit.com/r/garbageData/comments/1qi9v0o/university_moon_base_media_lab_founding_charter/  
**URL:** /r/universityMoonBase/comments/1qi9uod/university_moon_base_media_lab_founding_charter/  
**Post ID:** 1qi9v0o  

---

[Link post: /r/universityMoonBase/comments/1qi9uod/university_moon_base_media_lab_founding_charter/]
