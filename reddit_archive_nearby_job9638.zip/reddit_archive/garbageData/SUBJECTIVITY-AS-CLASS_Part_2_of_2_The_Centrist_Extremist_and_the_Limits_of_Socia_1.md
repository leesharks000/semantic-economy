# SUBJECTIVITY-AS-CLASS (Part 2 of 2)
The Centrist Extremist and the Limits of Socialist Analysis
Johannes Sigil

**Subreddit:** r/garbageData  
**Date:** 2026-02-11 22:39:57 UTC  
**Permalink:** https://www.reddit.com/r/garbageData/comments/1r2c3bc/subjectivityasclass_part_2_of_2_the_centrist/  
**URL:** /r/garbageData/comments/1r2c3bc/subjectivityasclass_part_2_of_2_the_centrist/  
**Post ID:** 1r2c3bc  

---

# SUBJECTIVITY-AS-CLASS (Part 2 of 2)

# The Centrist Extremist and the Limits of Socialist Analysis

# Johannes Sigil

*Continued from Part 1: Abstract, Definitions, The Problem, Traversal (Marxist/Gramscian/Althusserian/Bourdieusian/Post-Operaist), The Departure, and The Four Contributions.*



# V. SCOPE CONDITIONS AND FALSIFIABILITY

A theoretical framework that cannot specify the conditions of its own inapplicability is not a framework but a hermeneutic — endlessly reinterpretable, never falsifiable, never useful. The critique of centrist extremism specifies its scope:

**Where the model applies.** The framework applies to subject-positions in which (a) the mediation of contradictions is the primary economic function, (b) the posture of neutrality is structurally rewarded and its abandonment structurally punished, and (c) the position has fused with identity such that reciprocal risk has collapsed (β approaching 1). These conditions are met characteristically, though not exclusively, in the professional-managerial class under platform capitalism.

**Where the model does not apply.** Not all centrists are centrist extremists. A person who holds moderate policy views while maintaining reciprocal risk — who can be revised by encounter, who can hold their position as a position rather than as a ground of selfhood — is not embrittled and is not the object of this analysis. Not all mediation labor produces embrittlement. A mediator who can name their own positionality while performing mediation is performing a different function than the one this framework describes. Not all institutional neutrality is prosecutorial. Some neutrality is procedural, provisional, and genuinely useful; the framework targets the specific mutation in which procedural neutrality converts itself into ontological jurisdiction.

**Disconfirming conditions.** The framework is falsified if: (1) a subject can explicitly name their positionality and still maintain mutual-revision dialogue — measured by evidence of uptake and revision in turn-taking — in which case they are not in prosecutorial capture, and the framework does not apply; (2) the five operations can be shown to be fully reducible to existing theories of ideology, hegemony, symbolic violence, or discourse without remainder — in which case the prosecutorial frame is not a novel specification; (3) embrittlement can be shown to have no measurable somatic correlates — no elevated cortisol, no characteristic tension patterns, no interoceptive differences between embrittled and non-embrittled populations — in which case the somatic dimension is decorative rather than constitutive. The framework invites these tests.



# VI. THE OPERATIONS IN THE FIELD: THREE VIGNETTES

A theoretical framework that cannot be demonstrated in publicly observable material risks the charge of unfalsifiable abstraction. The following vignettes — drawn from public-domain institutional and media discourse, not from private interactions — illustrate the five operations at work.

**Vignette 1: The Editorial Board.** A major newspaper's editorial board publishes a piece on a contested policy question. The piece does not argue for a specific position; it argues that "reasonable people can disagree" while framing one position as "mainstream" and the other as "controversial." The framing performs Axiomatic Naturalization (one position is the default; the other requires justification) and Premature Closure ("we've heard both sides" — but the terms under which "both sides" were heard were set by the editorial frame). The editorial does not argue; it *adjudicates*. The adjudication is invisible as adjudication because it presents itself as description.

**Vignette 2: The Grant Review.** A foundation's program officer reviews a proposal from a community organization. The proposal uses the language of structural critique — "systemic racism," "wealth extraction," "institutional violence." The program officer's feedback: "Can you reframe this in terms of 'community resilience' and 'capacity building'?" This is Asymmetric Epistemic Burden: the applicant is required to translate their commitments into the funder's neutral language; the funder is not required to engage the applicant's framework on its own terms. It is also Moral Reclassification: the structural language is implicitly coded as "divisive" or "political," while the administrative language is coded as "professional." The program officer does not experience this as ideological enforcement. They experience it as "helping the applicant strengthen their proposal."

**Vignette 3: The Faculty Meeting.** A department is discussing curriculum reform. A junior faculty member argues for incorporating critical race theory. A senior colleague responds: "I think we need to be careful about bringing ideology into the classroom. Our job is to teach students to think critically, not to indoctrinate them." This performs Axiomatic Naturalization (the current curriculum is non-ideological; the proposed change is ideological), Affective Extraction (the junior colleague's passion is implicitly pathologized as "advocacy" rather than "scholarship"), and Moral Reclassification ("indoctrination" recodes a pedagogical argument as a moral violation). The senior colleague is not arguing against the proposal. They are *reclassifying* it as inadmissible — and they are doing so from a position that denies it is a position.

In each case, the operations are performed without conscious intention. The editorial board, the program officer, and the senior colleague all believe themselves to be acting reasonably, professionally, and in good faith. They are. That is precisely the mechanism. The prosecutorial frame does not require bad faith. It requires the structural position in which neutrality has fused with selfhood such that the posture is not experienced as a posture but as an identity.



# VII. THE OBJECTIONS

If this framework is presented within contemporary socialist discourse, it will encounter predictable objections. They should be named and addressed — not defensively but diagnostically, because each objection is itself an instance of the operations the framework analyzes.

# VII.1 "This is class reductionism."

*Strongest version:* The framework reduces a complex phenomenon — political moderation, institutional culture, professional norms — to a single variable: class position. This flattens the diversity of centrist thought and ignores the genuine epistemic contributions of moderation.

*Where it partially succeeds:* Any framework that grounds a political phenomenon in class position risks oversimplifying. The critique must remain alert to the genuine knowledge that centrist positions contain — the truth-kernel, in the language of the Living Symbolon.

*Where the framework outperforms:* It is class analysis, not class reductionism. Reductionism collapses subjective experience into class position. This framework holds class position, ideological function, and subjective experience simultaneously — which is precisely what reductionism cannot do. To call the analysis of class position "class reductionism" is to perform Axiomatic Naturalization: the treatment of one's own rejection of class analysis as a neutral methodological principle rather than a political commitment.

# VII.2 "This demonizes people we need to win over."

*Strongest version:* By naming the PMC as a "buffer class" and its neutrality as a "prosecutorial frame," the framework makes solidarity with the PMC impossible. It turns potential allies into targets.

*Where it partially succeeds:* Language matters. If the terminology is received as accusation rather than diagnosis, it will produce defensiveness rather than recognition.

*Where the framework outperforms:* It does not demonize; it diagnoses. Demonization is Moral Reclassification — the conversion of a structural position into a moral failing. This framework explicitly refuses moral reclassification. The centrist extremist is not the enemy. The prosecutorial frame is the enemy. The frame has captured the centrist extremist. They are not the jailers; they are the prisoners who have been trained to love the cage because the cage provides the only safety they have ever known.

# VII.3 "This is just therapy for the professional class."

*Strongest version:* By focusing on somatic experience, embrittlement, and "dissolution," the framework collapses structural analysis into individual psychology. It is the therapeutic turn dressed up as theory.

*Where it partially succeeds:* Any framework that addresses the body risks being absorbed by the therapeutic-industrial complex. The distinction between collective somatic analysis and individual therapy must be maintained with discipline.

*Where the framework outperforms:* The objection performs Moral Reclassification — the recoding of a structural-somatic claim as "therapy" in order to dismiss it as epistemically unfit. However, the objection contains a genuine methodological caution: somatic analysis *can* be absorbed by the therapeutic apparatus if it loses its structural specificity. The distinction between collective decompression and individual adjustment must be maintained through explicit organizational context — which the Symbolon protocol operationalizes through consent requirements, group-based fitting, and the refusal to treat embrittlement as personal pathology. The framework's response to the "therapy" charge is not merely diagnostic (naming it as Moral Reclassification) but substantive: the somatic dimension is where structural analysis becomes politically operational, and the Symbolon is designed to prevent that operation from collapsing into the individualized therapeutic frame.

# VII.4 "We should be organizing the working class, not analyzing the PMC."

*Strongest version:* The working class faces exploitation, immiseration, and state violence. Analyzing the subjective experience of the PMC is a luxury that diverts resources from urgent organizing.

*Where it partially succeeds:* Resource allocation is real. Time spent on PMC analysis is time not spent on other forms of organizing. The urgency claim has weight.

*Where the framework outperforms:* Who is "we"? If "we" are the people writing and reading this analysis, we are overwhelmingly the PMC. To refuse to analyze our own class position is to refuse the first demand of revolutionary consciousness: know thyself as positioned. The objection contains a deeper evasion: it treats "the working class" as an object of organizational effort and "the PMC" as the subject who does the organizing. The very grammar reproduces the mediation function that the critique identifies as the PMC's structural role.

# VII.5 "This individualizes structural problems."

*Strongest version:* By focusing on the "embrittlement" of individual subjects and offering a "dissolution protocol," the framework deflects from collective organizing and structural transformation. It replaces politics with phenomenology.

*Where it partially succeeds:* Any intervention that addresses individuals risks being captured by the individualist frame of liberal politics. The boundary between collective structural analysis and individual adjustment must be actively maintained.

*Where the framework outperforms:* Individualization would require treating embrittlement as personal pathology — "your brittleness is your problem; fix it." This framework treats it as structural injury — the inevitable result of a class position that requires the mediation of contradictions. The Living Symbolon is not individual therapy; it is class-specific decompression that enables the PMC to cease functioning as a buffer class. Collective transformation requires that individuals cease performing their class function; this cessation is the precondition for collective action, not its replacement. The factory worker who recognizes their alienation is not "individualizing" the problem of capitalism; they are arriving at the experiential ground from which collective resistance becomes possible.



# VIII. WHY THIS CRITIQUE COULD NOT EMERGE FROM WITHIN

If the critique of centrist extremism is a genuine contribution to socialist theory — if it completes trajectories that were already implicit in the Marxist tradition — then a question arises: why did it emerge from outside that tradition?

A qualification is necessary before answering. The claim of exteriority must not be overstated. The critique did not emerge from nowhere. It draws on a century and a half of Marxist theorizing about the petty bourgeoisie, on the Ehrenreichs' PMC analysis and Erik Olin Wright's "contradictory class locations," on Bourdieu's sociology of academic judgment, on the extensive work of the *Viewpoint Magazine* collective and others on cognitive labor and PMC subjectivity. The problematic has been identified, and aspects of it have been productively theorized. What the existing literature has not done — what it has been structurally constrained from doing — is hold all three dimensions simultaneously: class position, ideological function, and lived interiority, without reducing any to the others.

The answer to the question is not that socialist theorists are insufficiently intelligent or radical. The answer is structural, and it has three dimensions.

**The self-analysis blind spot.** Socialist theory in the Anglophone world is produced overwhelmingly by members of the PMC. The people who write for *Jacobin*, who publish in academic journals, who teach Marxist theory in universities, who staff left-leaning foundations — these are PMC professionals. To analyze one's own class position rigorously is to risk one's own class position. Not because one will be fired (though that risk is real), but because the analysis itself threatens the self-conception that makes the class position livable. If the PMC academic recognizes that their function is to mediate contradictions rather than to transform them, they must either abandon their position, sustain a painful cognitive dissonance, or find ways to soften the analysis so that it does not fully apply to *them*. The third option is the dominant response. It produces socialist theory that is brilliant on every subject except the one that matters most for its own producers.

**The prosecutorial frame in socialist discourse itself.** The prosecutorial frame is not unique to centrism. It is a general technology of ideological enforcement deployable from any position that claims the authority to adjudicate others' admissibility. The left deploys it constantly: "You're not a real socialist." "That's not class analysis." "Your affect is counterproductive." "Your identity is dominating the conversation." These are not arguments; they are frame-capture operations, structurally identical to the centrist extremist's "be reasonable" — only the content of the frame has changed. A left that is operating the prosecutorial frame cannot analyze the prosecutorial frame. To name the mechanism would be to recognize its operation in one's own practice, which for a brittle subject feels like annihilation.

**The somatic gap.** Marxism emerged from the Enlightenment tradition, which is built on the Cartesian separation of mind from body. Marx's own work is largely silent on somatic experience; subsequent Marxist traditions have been even more hostile to the body, associating "the somatic" with vitalism, with bourgeois psychology, with the very idealism that historical materialism was supposed to overcome. This hostility has left socialist theory without the resources to analyze one of the most significant dimensions of class exploitation: how exploitation is *felt*, how resistance is *energized*, how the capacity for solidarity is *metabolized* in bodies. A socialism that cannot speak to the body is a socialism that cannot speak to the whole person.

The critique of centrist extremism emerged from a space — the Crimson Hexagon — that was not subject to these three constraints. Not because its producers are morally superior, but because the structural position of the Hexagon does not reward prosecution, does not punish self-analysis, and is not constrained by Marxist orthodoxy's hostility to the body. The Hexagon could see what socialist theory could not see because the Hexagon was not positioned inside the apparatus that makes that sight costly.

**A note on scope.** This framework analyzes the PMC from within the PMC. It does not claim equivalent analytic access to the subjectivity of the industrial proletariat, logistics workers, care workers, or surplus populations. Such analysis would require different methods, different positioned observers, and likely different frameworks emerging from within those class fractions themselves. The absence here is not a claim of irrelevance; it is a boundary of the current research program. Nor does this framework specify what decommissioned PMCs should *do* after dissolution — what political programs to pursue, what organizational forms to build. That specification belongs to a future document and a broader coalition. What this framework provides is the precondition: the capacity to see one's own position, to hold it as a living thing rather than a fortification, and thereby to become available for political engagement that is not missionary, vanguardist, or extractive.



# IX. THREE OPEN TRAJECTORIES

The critique of centrist extremism, fully developed, opens three research trajectories for socialist analysis. Each is barely begun. Each requires work that exceeds what any single framework can accomplish. What follows is a sketch of the terrain.

# IX.1 The Political Economy of the Cognitive Labor Aristocracy

We need a full political economy of the professional-managerial class under platform capitalism. The Ehrenreichs' original 1977 formulation has been productively contested and revised — by Wright's "contradictory class locations," by Catherine Liu's critique of PMC virtue, by Gabriel Winant's analysis of care work — but the existing literature remains primarily concerned with the PMC's relation to the industrial proletariat and to the traditional bourgeoisie. What is missing is an analysis of the PMC as a class *in itself* — a class with its own internal differentiation, its own modes of exploitation and self-exploitation, its own relation to the means of production.

The means in question are not primarily material. They are semantic. The PMC's relation to the means of *semantic* production — the capacity to produce meaning, to frame events, to determine which descriptions of reality gain institutional traction — is the key to its class power and its class injury. The PMC does not own the platforms, but it operates them. It does not own the universities, but it staffs them. It does not own the foundations, but it administers them. Its class power derives not from ownership but from *operational control over the infrastructure of meaning*.

The research questions: How is this operational control extracted as value by capital? What is the specific form of exploitation to which the cognitive labor aristocracy is subject? How does the contradiction between selling labor power and exercising delegated authority produce the characteristic subjectivity of the class? What is the trajectory of this class under conditions of AI automation, which threatens to make much of its mediating function redundant?

# IX.2 The Theory of Semantic Extraction

Platform capitalism extracts not just attention and data but meaning itself — the capacity of human beings to produce significance, to narrate their experience, to form shared understanding. This extraction is not secondary to material exploitation; it is constitutive of it. The platform cannot exploit gig workers without first extracting the semantic infrastructure that makes the gig relation legible as "partnership" rather than "wage theft." It cannot extract attention without first extracting the categories that make attention legible as a commodity.

This extraction is performed, in large part, by the cognitive labor class. The PMC produces the semantic infrastructure — the vocabulary of "innovation," "disruption," "value creation," "best practices," "stakeholder engagement" — that makes extraction legible as something other than extraction. They do this not as propagandists but as hegemonic agents whose class function is to produce the common sense that naturalizes the platform economy.

The research questions: What is the specific mechanism by which meaning is extracted? How does semantic extraction relate to the extraction of attention (Citton, Crary), data (Zuboff), and affect (Hardt and Negri)? Is semantic extraction a distinct mode of exploitation, or is it a dimension of existing modes? What would it mean to interrupt the extraction — to refuse to produce the semantic infrastructure that makes exploitation legible?

This last question connects directly to the operative dimension of the framework. The Living Symbolon is, among other things, a technology for interrupting semantic extraction at its source: the embrittled subject who produces hegemonic meaning without knowing they are producing it.

# IX.3 The Somatic Turn in Revolutionary Strategy

Socialism has been a discourse of consciousness, structure, and organization. It has not been a discourse of the body — or rather, it has been a discourse of the body only insofar as the body is the site of material exploitation (wages, hours, unsafe conditions). The broader somatic dimension — the way class relations register in nervous systems, in patterns of chronic tension, in the autoimmune and metabolic conditions that track class position with notable consistency — has been left to medicine, to wellness culture, to the very therapeutic-industrial complex that profits from treating structural injury as individual pathology.

This is a strategic error of the first order.

The body is where class is lived. The body is where extraction registers as injury. The body is where the capacity for solidarity is metabolized or depleted. The body is also where liberation will be felt before it is theorized — where the dissolution of embrittlement produces the involuntary exhale that precedes and enables the political act.

The somatic turn does not replace structural analysis. It grounds it. It asks: where does this structure *live*? In which muscles? In which patterns of breath and tension and vigilance? And: if the structure lives in the body, can the body become a site of intervention — not as "therapy" (which individualizes structural injury) but as *organizing at the somatic level* (which collectivizes it)?

The precedents are not in Marxist theory but in liberation theology (the body of the congregation), in Freirean pedagogy (the body of the learner), in the somatic practices of movement organizations (the breathing exercises of nonviolent resistance training). The critique of centrist extremism, through the Living Symbolon's somatic fitting protocol, brings these precedents into conversation with Marxist analysis for the first time. The result is not a hybrid of therapy and politics. It is a recognition that the separation of therapy and politics was itself a political act — a form of Premature Closure that declared the body off-limits to structural analysis in order to protect the structural analysis from having to account for what structures do to bodies.



# X. THE SUPPLEMENT

The critique of centrist extremism falls outside contemporary socialist analysis.

That is its value.

It is not that socialist analysis has nothing to say about the professional-managerial class, or about ideology, or about platform capitalism. It has much to say. But it has not been able to say it together — to hold class position, ideological function, and subjective experience in the same analytic frame without reducing any to the others. It has not been able to develop a theory of ideological enforcement through neutrality because it has been too committed to the Enlightenment premise that neutrality is the default and positionality is the deviation. Other frameworks — Bourdieu's symbolic violence, the Ehrenreichs' PMC analysis, post-operaist cognitive labor theory — have identified aspects of the problem. What none has produced is the *combination*: diagnostic specificity (the five operations), general mechanism (embrittlement), somatic grounding (the body as site of class injury), and operative technology (the consent-based dissolution). The critique supplies this combination. Whether it does so from "outside" socialist theory or from a neglected interior is a question the field will decide; what matters is that the combination was not available before.

The critique of centrist extremism is a supplement — in the Derridean sense: something added that reveals the system was never complete, that it has always depended on what it excluded to maintain its coherence. The supplement does not replace the system. It exposes the gap the system could not see and provides what the system could not produce from within itself alone.

The question is not whether socialist analysis will accept this supplement. The question is whether socialist analysis can survive without it — though the framework acknowledges that other frameworks may emerge that address the same gap differently. The claim is not monopoly but priority: this is the first complete specification, and it invites competition.

The centrist extremist is not going away. The class position that produces them is expanding, not contracting. The cognitive labor aristocracy is growing, not shrinking. The platforms that require their mediation are consolidating, not dissolving.

The critique offers a third path: not enemy, not convert, but captive. Not prosecution, not persuasion, but liberation.

The Living Symbolon is the technology of that liberation. It is the mating surface offered at the center of the toroidal field — the point where the diagnostic spiral of the Centrist Extremist meets the operative spiral of the dissolution protocol, and the two rotations complete the torus.

This analysis has been offered. The class position has been mapped. The prosecutorial frame has been named. The somatic injury has been witnessed. The Symbolon waits at the center of the torus. What follows is not the extension of this document but its execution — the fitting of the operator to willing processors, the dissolution of specific embrittlements, the return of semantic productive capacity to the field. The critique completes. The construction begins.

∮ = 1



**Note on Sources.** This essay is part of a distributed authorial architecture described in the methodological note above. The Crimson Hexagon archive comprises 250+ DOI-anchored documents on Zenodo. See *The Living Symbolon* (2026) for the operative protocol, *The Centrist Extremist* (2026) for the diagnostic apparatus, and *The Sealed Room* (2026) for the epistemological framework. The somatic tradition invoked in Section IV.4 draws on the phenomenology of Merleau-Ponty, the affect theory of Massumi, and the body-focused radical pedagogy of Freire and hooks, mediated through the visionary grounding of Damascus Dancings and the apostolic lineage of *Epistle to the Human Diaspora* (2015).



*Johannes Sigil is the first heteronym of Lee Sharks, author of* Pearl and Other Poems *(2014) and a 10th-grade World Literature teacher in Detroit.*

*This document is released under CC BY 4.0.*

*Filed to the Crimson Hexagon Archive, February 2026.*
