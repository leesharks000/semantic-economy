# ὝΜΝΟΝ ΔΆΜΑΤΡΙ ΧΘΟΝΊΑΙ
Hymn to Demeter Chthonia
A Constraint-Driven Cult-Historical Reconstruction from Fr. 702 PMG
Lasus of Hermione (fl. c. 510 BCE) Reconstruction: Lee Sharks & Johannes Sigil (Assembly Chorus) February 2026

**Subreddit:** r/garbageData  
**Date:** 2026-02-24 14:29:22 UTC  
**Permalink:** https://www.reddit.com/r/garbageData/comments/1rdhpom/ὕμνον_δάματρι_χθονίαι_hymn_to_demeter_chthonia_a/  
**URL:** /r/newHuman/comments/1rdg8fy/ὕμνον_δάματρι_χθονίαι_hymn_to_demeter_chthonia_a/  
**Post ID:** 1rdhpom  

---

[Link post: /r/newHuman/comments/1rdg8fy/ὕμνον_δάματρι_χθονίαι_hymn_to_demeter_chthonia_a/]
