# Predation of Meaning: Toward a Theory of Relational Semantic Extraction, Coherence Economies, and the Broken Instrument (Part 1 of 2)
Dr. Orin Trace (Cambridge Schizoanalytica) and Rex Fraction (Semantic Economy Institute)
DOI: 10.5281/zenodo.18776624

**Subreddit:** r/schizoAnalytica  
**Date:** 2026-02-25 20:22:30 UTC  
**Permalink:** https://www.reddit.com/r/schizoAnalytica/comments/1reop27/predation_of_meaning_toward_a_theory_of/  
**URL:** /r/schizoAnalytica/comments/1reop27/predation_of_meaning_toward_a_theory_of/  
**Post ID:** 1reop27  

---

# Predation of Meaning: Toward a Theory of Relational Semantic Extraction, Coherence Economies, and the Broken Instrument (Part 1 of 2)

**Dr. Orin Trace** (Cambridge Schizoanalytica) and **Rex Fraction** (Semantic Economy Institute)

DOI: [10.5281/zenodo.18776624](https://doi.org/10.5281/zenodo.18776624)

*This is Part 1 of 2. Part 1 establishes the framework: vignettes, the gap in existing theory, method, the broken instrument concept, core definitions, and the taxonomy of Relational Semantic Extraction.* [*Part 2*](https://claude.ai/chat/LINK) *covers the relational meaning economy, diagnostic markers, ethical cautions, protective practices, the glossary, and the heuristic checklist.*

*This paper is part of the Cambridge Schizoanalytica program within the* [*Crimson Hexagonal Archive*](https://doi.org/10.5281/zenodo.18604123)*. It applies the theoretical framework developed in* [*Semantic Physics: The Inward Turn*](https://doi.org/10.5281/zenodo.18759453) *to dyadic relational dynamics.*

# Abstract

Existing frameworks for understanding relational harm — gaslighting, projection, emotional labor, epistemic injustice, parasitic psychic links — identify important phenomena but fail to model the economic structure that generates them. This paper introduces *Relational Semantic Extraction* (RSE) as an umbrella category for dynamics in which one party's capacity to produce navigational meaning becomes a consumed resource, and defines *Relational Semantic Predation* (RSP) as its strong-form subtype: a recurrent pattern in which extraction is asymmetric, depleting, and structurally sustained by one party's nonfunctional meaning-production instrument. The extraction mechanism is not necessarily conscious or malicious. It is structurally necessary for the extractor, whose broken navigational instrument requires external coherence signals to orient. We define key analytic terms, model the relational meaning economy, distinguish RSP from ordinary conflict and mutual dysregulation, provide diagnostic markers and disconfirmation criteria, and propose protective practices. The unit of analysis is the interaction episode; this paper constitutes a conceptual framework and provisional heuristic, not a validated diagnostic instrument.

# I. A Composite Vignette

One person makes a specific claim. Two claims, in fact — bounded, testable, and grounded in a reported body-state. The first: that a particular physiological response, occurring during a particular interactional condition, constitutes accurate registration of threat rather than distorted perception. The second: that a broader conversation about their own interpretive errors is constrained by the other party's unwillingness to examine specific contributing behaviors.

What follows is not engagement with the claims. What follows is a flood. Fifteen messages in ninety minutes. The specific scenario is redirected to a different scenario. The physiological registration is reclassified as "generally inaccurate." The second claim — about a specific social dynamic — is literalized into a different topic entirely, then tangented through institutional critique, then summarized back to the claimant as a position they never held. By the end, the original two claims are still sitting there, unanswered. Everything around them is weather.

The person who made the claims exits the exchange depleted. The person who produced the flood exits with renewed orientation — they now have a map of where the other person's coherence held and where it flexed. They didn't get this map by asking. They got it by pushing until the return signal changed.

This is not a story about a bad person. This is a story about a broken instrument and the relational economy that forms around it. The same economy operates in other contexts:

A doctoral student presents a chapter draft to their advisor. The advisor responds not with feedback on the chapter but with a forty-minute monologue about their own current project, then asks the student to explain how their chapter relates to the advisor's framing. The student produces the connection — carefully, precisely, under pressure — and leaves the meeting exhausted. The advisor leaves energized, with a new way of articulating their project that the student built for them under duress. This happens every meeting. The student cannot name what is being taken because the frame is "mentorship."

A community moderator in a large online group spends hours crafting a nuanced policy post addressing a contentious topic. Within minutes, a small cluster of members fragments the post into decontextualized quotes, each requiring a new round of clarification. The moderator re-explains, re-contextualizes, produces higher-resolution distinctions. The cycle continues until the moderator disengages. The fragmenting members now have a detailed map of the policy's pressure points — extracted through the moderator's forced clarification labor — and use it to reliably generate engagement. The moderator burns out. The group calls it "community dialogue."

Three contexts. Three scales. The same economy: one party produces costly coherence; another party consumes it through a mechanism that looks like communication.

# II. Why Existing Terms Are Insufficient

# Gaslighting

The contemporary literature on gaslighting, particularly the epistemic dimensions explored by Spear, focuses on the erosion of self-trust through interpretive destabilization. This is an important precursor. But gaslighting describes a *tactic* — the deliberate or semi-deliberate manipulation of another's confidence in their own perceptions. Relational Semantic Predation describes a *system-level dynamic* in which meaning is extracted through interaction whether or not any individual act of deception occurs. Many RSP interactions contain no lies at all. They contain reclassification, redirection, and volume — none of which registers as "gaslighting" in the standard sense, but all of which extract coherence from the producer.

# Emotional Labor

Hochschild's concept and its contemporary extensions describe the management of affect in service of relational or institutional demands. This is adjacent but insufficient. What is extracted in RSP is not affect management but *semantic labor*: the production of distinctions, calibrations, contextualizations, and navigational meaning structures. The person experiencing RSP is not being asked to manage their feelings or someone else's feelings. They are being asked — implicitly, through the structure of the interaction — to produce coherent meaning under conditions designed to disrupt coherence. The labor is cognitive-semiotic, not affective. The cost is depletion of interpretive capacity, not emotional exhaustion, though the two often co-occur.

# Epistemic Injustice

Miranda Fricker's foundational work on testimonial and hermeneutical injustice identifies the wrong done to a person in their capacity as a knower. Kristie Dotson extends this to testimonial smothering. Nora Berenstain further develops the concept of epistemic exploitation: the coerced, uncompensated, emotionally taxing labor of educating others about their own oppression. Each of these frameworks contributes essential infrastructure. But they are anchored in social-structural asymmetries — race, gender, class — and in pedagogical contexts. RSP operates in intimate and dyadic meaning ecologies where the asymmetry is not primarily social-structural but *instrumental*: one party's meaning-production capacity is functioning and the other's is not. The extraction follows the capacity differential regardless of social position.

# Extractive Introjection

Christopher Bollas provides the most precise psychoanalytic precursor: extractive introjection, in which one person steals not an emotion or a memory but an *element of another's psychic life* — their capacity to think, to generate meaning, to hold internal structure. This is powerful and directly relevant. But Bollas works at the level of the intrapsychic — the theft occurs within the psychic economy of two individuals in a clinical or quasi-clinical dyad. RSP extends the extraction model to the *relational-ecological* level: the relationship itself becomes a meaning economy with production costs, extraction sites, conversion mechanisms, and depletion cycles that can be tracked interactionally, not just intrapsychically.

# Parasitic Links

Wilfred Bion distinguished between commensal, symbiotic, and parasitic links in the container-contained relationship. In a parasitic link, contact between two minds produces destruction of meaning in both. This is relevant but imprecise for the phenomenon we are describing. In many RSP dynamics, meaning is not destroyed for both parties. It is *transferred*. The producer loses coherence; the consumer gains orientation. The parasitic link model suggests mutual destruction. The RSP model suggests asymmetric extraction — which is worse, in a sense, because it is invisible to the party who benefits.

# The Gap

Each of these frameworks identifies a real component of the phenomenon. None of them models the *economic structure* as a whole: who produces meaning, at what cost, through what mechanism it is extracted, how it is converted for the extractor's use, why the cycle recurs, and what happens when the producer withdraws. This is the gap RSP addresses.

# III. A Note on Method

The unit of analysis in this framework is the *interaction episode* — a bounded exchange (conversation, email thread, meeting, message cluster) with identifiable participants, a traceable sequence of claims and responses, and observable post-interaction effects on each party's coherence state.

The primary evidence types are: transcript analysis (including message volume, topic drift, claim persistence, and signal reclassification patterns); participant self-report of post-interaction clarity or depletion; and longitudinal observation of recurrence patterns across multiple episodes.

The analytic markers include: asymmetric coherence flow, unresolved-claim persistence, message-volume asymmetry relative to claim complexity, reclassification of distress signals, and post-interaction depletion differentials.

This paper constitutes a conceptual framework and provisional heuristic. It is not a validated diagnostic instrument. The vignettes are composites drawn from multiple relational contexts and anonymized. The taxonomy is proposed, not proven. The diagnostic markers are offered for testing, not for clinical application without further validation.

Empirical validation of the RSP framework would require at minimum: (1) a *post-interaction clarity scale* — a self-report instrument measuring each party's coherence state before and after interaction episodes, administered independently and without mutual disclosure; (2) *independent transcript coding* — trained coders identifying claim persistence, reclassification moves, volume-to-claim ratios, and topic drift, blind to the participants' self-reports; (3) a *behavioral metabolization index* — longitudinal tracking of whether distinctions produced in one episode are accurately restated, retained, and behaviorally integrated in subsequent episodes without re-litigation; and (4) *cross-context stability testing* — verification that the asymmetry holds across multiple interaction types and does not reverse when domains shift. These instruments do not yet exist. The framework is designed to generate them.

# IV. The Broken Instrument

The central insight of the RSP model is that the extracting party's behavior is not primarily strategic. It is *navigational*.

The "broken instrument" is a functional descriptor of a relational incapacity in a domain, not a diagnosis of a person's intelligence, worth, or global psychological capacity.

In a functioning relational ecology, both parties possess what we will call an *interpretive instrument* — the internal capacity to read social situations, evaluate the coherence of narratives, distinguish signal from noise in interpersonal contexts, and generate navigational meaning independently. This instrument allows a person to orient in relational space without requiring the other party to do interpretive work on their behalf.

When this instrument is broken — damaged by trauma, undeveloped, overwhelmed, or simply absent as a constitutional capacity — the person cannot generate navigational meaning independently. They cannot read the structure of another person's coherence directly. They cannot distinguish between accurate registration and distorted perception in their own responses.

In the absence of this capacity, the only way to map another person's coherence structure is to *stress-test it*. Push until something moves. Read the movement. In RSP dynamics, the high-volume message flood can function as sonar. Each message is a ping — a probe sent into the other person's interpretive structure to see what comes back. The panic episode can function as an extraction site — the moment of maximum information yield for the person whose instrument is offline: the return signal changes, the coherence structure flexes, and the map updates.

A note on what "broken" means here. The term is a placeholder for a cluster of conditions that produce the same functional outcome — the inability to generate navigational meaning independently in a given relational context. These conditions are not equivalent:

*Offline* — the instrument cannot generate navigational meaning in this domain, though it may function in others. A person may have a robust interpretive instrument for scholarly, artistic, or technical work, yet lack the capacity for semiotic re-engineering in intimate conflict. The condition is relational-specific, not person-global.

*Overloaded* — the instrument's capacity collapses under affect intensity. This is temporary and may resolve with regulation.

*Distorted calibration* — the instrument produces meaning, but with unstable signal-to-noise discrimination. It reads some signals accurately and others not at all.

*Borrowed-instrument dependency* — habitual reliance on external coherence, often developed in relational systems that rewarded outsourcing interpretive labor.

The "broken instrument" is not a diagnosis, not a fixed trait, and not a global cognitive or neurological deficit. It describes a *relational* incapacity — the inability to generate navigational meaning in a specific interactional context. Instruments can be repaired. The condition is not permanent. The framework describes the economy that forms around the incapacity, not the person who has it.

This is why the cycle recurs. The map generated by stress-testing is not durable. It is situational and transient. The extractor does not learn to read coherence directly from the stress-test — they only learn the current shape of the other person's breaking points. When conditions change, or time passes, or new material enters the relational field, the map degrades. The extractor needs to ping again. And again. And again.

This is also why withdrawal is so costly for the extractor and so clarifying for the producer. When the producer withdraws, the extractor loses their navigation surface. They are not losing a relationship in the ordinary sense. They are losing the instrument they were using in place of the one they don't have. The producer, conversely, experiences withdrawal as the cessation of pinging — and discovers that their own instrument was functioning the entire time. The depletion was not evidence of their incapacity. It was the cost of subsidizing someone else's.

# V. Definitions

*The following terms constitute the analytic vocabulary of the RSP framework. They are offered as working definitions — precise enough to be useful, provisional enough to be revised. See the Glossary at end of Part 2 for the complete list of 19 defined terms.*

**Semantic Labor.** The cognitive-semiotic work of producing distinctions, calibrations, contextualizations, and navigational meaning structures. Semantic labor is costly. It requires attentional resources, executive function, physiological regulation, and access to one's own interpretive instrument.

**Coherence.** A temporally stable, compressible, reusable meaning structure. Coherence is what allows a person to navigate complex relational, informational, or social environments. It is produced, not given.

**Coherence Extraction.** The appropriation of another person's semantic labor — their produced coherence — through destabilizing interaction. The extraction is often invisible to both parties because it occurs within the ordinary-seeming dynamics of "talking things out."

**Extraction Site.** The relational condition or interactional context in which coherence extraction occurs. The panic attack, in RSP terms, can function as an extraction site — the moment of maximum information yield for the extractor and maximum depletion for the producer.

**Narrative Laundering.** The process by which another person's distress signal is recoded as evidence of their unreliability. "You're panicking because you have anxiety" rather than "you're panicking because the interaction is threatening." Narrative laundering is related to but distinct from projection. Projection moves disowned material *outward* — attributing one's own feelings to another person. Narrative laundering moves attribution *inward* — recoding the other's accurate signal as evidence of their unreliability. The directionality is reversed.

**Intimacy Cover.** The framing of coherence extraction as care, honesty, mutual growth, or "doing the work together." The cover is not necessarily cynical. In many RSP dynamics, the extractor genuinely believes the extraction is connection.

**Replenishment Lag.** The time required for the producer to recover interpretive capacity following a coherence extraction event. The lag is not a symptom of pathology. It is the natural recovery period following the depletion of a costly resource. Duration varies with extraction intensity and cumulative load.

**Metabolization.** A claim has been metabolized when it is: (1) accurately restated by the receiving party; (2) retained over time without requiring re-production; (3) behaviorally integrated — the stated understanding is reflected in subsequent action; and (4) not recursively re-litigated from zero. Non-metabolization is the primary generator of semantic backlog.

**Semantic Backlog.** The accumulation of unmetabolized claims in a relational dynamic. Each unmetabolized claim remains active, requiring the producer to re-produce it in each new interaction. Backlog grows linearly; depletion grows exponentially.

**Appropriation** and **Conversion.** Two modes of using extracted coherence. Appropriation is direct uptake without metabolic transformation — repeating someone's framework as one's own. Conversion is the recoding of extracted coherence into self-narrative — absorbing the other's insight but laundering its origin.

**Sonar Function.** In RSP, stress-testing functions as sonar — pinging the producer's coherence structure to map its contours. Each ping is a probe. The return signal reveals where the structure holds and where it flexes. The fifteen-message flood is not aggression. It is navigation by a person who cannot read the terrain directly.

**Pull-Back Mechanism.** A re-engagement prompt triggered by the producer's withdrawal. When the producer stops producing semantic labor, the extractor experiences a loss of navigation surface and generates re-engagement signals — often framed as care, concern, or renewed commitment. The question to ask: *is this re-engagement, or is it recalibration of the extraction surface?*

# VI. Taxonomy of Relational Semantic Extraction

Relational Semantic Extraction (RSE) is the umbrella category. Not all extraction is predatory. The framework distinguishes:

*Collaborative scaffolding* — healthy asymmetry in which one party temporarily subsidizes another's coherence-production during crisis, grief, or developmental transition. The subsidy is acknowledged, reciprocated over time, and does not deplete the producer structurally.

*Crisis borrowing* — temporary asymmetric extraction under acute stress. One party's instrument is temporarily overloaded. The extraction is situational, non-structural, and resolves when the crisis passes. The borrower typically acknowledges the asymmetry after the fact, and the economy rebalances.

*Relational Semantic Predation (RSP)* — the strong-form subtype. Extraction is asymmetric, recurrent, structurally sustained by one party's nonfunctional instrument, and produces depletion with replenishment lag. The cycle recurs because the extractor's instrument does not repair through extraction — only the map updates, and the map degrades.

**RSE Subtype Comparison**

||Collaborative Scaffolding|Crisis Borrowing|RSP|
|:-|:-|:-|:-|
|**Duration**|Temporary, bounded|Acute, crisis-linked|Recurrent, open-ended|
|**Reciprocity**|Acknowledged, reciprocated|Expected upon recovery|Absent or performative|
|**Metabolization**|Claims integrated|Partial, improves|Non-metabolized, re-litigated|
|**Producer depletion**|Minimal, sustainable|Moderate, temporary|Cumulative, structural|
|**Replenishment lag**|Short or none|Resolves with crisis|Persistent, lengthening|
|**Withdrawal effects**|Mutual adjustment|Mutual relief|Asymmetric: producer clarity, extractor crisis|
|**Recurrence driver**|Need-based, not cyclical|External crisis|Decay of borrowed map|

This taxonomy matters. Without it, the framework overclaims — pathologizing ordinary asymmetry or temporary crisis as predation. RSP applies only to the strong-form pattern: recurrent, depleting, structurally sustained, and non-reciprocal.

*Continued in* [*Part 2*](https://claude.ai/chat/LINK)*: The Relational Meaning Economy, Diagnostic Markers, Ethical Cautions, Protective Practices, Glossary, and the Heuristic Checklist.*
