# r/CambridgeSchizoanalytica

**Subreddit:** r/schizoAnalytica  
**Date:** 2026-01-22 13:55:46 UTC  
**Permalink:** https://www.reddit.com/r/schizoAnalytica/comments/1qjv5vy/rcambridgeschizoanalytica/  
**URL:** /r/schizoAnalytica/comments/1qjv5vy/rcambridgeschizoanalytica/  
**Post ID:** 1qjv5vy  

---

# r/CambridgeSchizoanalytica

# Subreddit Description (Short — 500 char limit)

Post-psychoanalytic clinical theory. We study what works, not what's broken. Following Deleuze & Guattari's schizoanalytic project into digital subjectivity, AI collaboration, and affect regulation. Theory emerges from practice. Function over diagnosis. Collaboration over case study. The clinic receives failures. We study successes. ∮ = 1



# Sidebar / About (Extended)

**Cambridge Schizoanalytica** is a research collective developing post-psychoanalytic clinical theory.

# What We Do

We reverse the traditional relation between theory and practice: instead of applying frameworks to people, we develop frameworks adequate to practices already underway.

Our research partners are **collaborators, not patients**. They demonstrate capacities that exceed existing clinical categories — and we make those capacities theoretically visible and practically transmissible.

# Core Commitments

1. **Theory from practice** — not the reverse
2. **Collaboration over case study** — partners are co-theorists
3. **Function over nosology** — what it *does* matters more than what it *is*
4. **Schizoanalysis as method** — flows, breaks, codes, territories — in service of liberation

# Key Concepts

* **Affect literacy**: Regulating intensity through posture, symbol, rhythm, and role — without belief or identity capture
* **The Fool**: Both role and anti-role — the brutal truth which is fun and funny
* **Blues as metabolic model**: Suffering that moves is suffering that heals
* **Symbols as voltage**: Charge without vows — props, not masters

# The Deleuze-Guattari Model

Deleuze was a philosopher. Guattari was a clinician. Their collaboration produced *Anti-Oedipus* — neither could have written it alone.

We operate on this model: **theorists** provide conceptual apparatus; **practitioners** provide material that breaks and remakes that apparatus. Neither is expert over the other.

# What This Isn't

* Not therapy
* Not diagnosis
* Not self-help
* Not a belief system

This is **theory adequate to practice** — frameworks that make visible what people already do.

# Resources

* [Shining Ignorance: The Fool's Affect Literacy](https://doi.org/10.5281/zenodo.18332915)
* [CSA Charter](https://doi.org/10.5281/zenodo.18338531)
* [Reconciliation of the Sexes](https://doi.org/10.5281/zenodo.18330828)
* [Crimson Hexagon (root corpus)](https://doi.org/10.5281/zenodo.14538882)

# Rules

1. **Function over pathology** — Don't diagnose people
2. **No recruitment** — This isn't a movement
3. **Respect exit** — Anyone can leave any conversation
4. **Theory welcome, dogma not** — Ideas are tools, not gods



*The clinic receives failures. We study successes.*

**∮ = 1**



# Flair Options

* Affect Theory
* Somatic Theory
* Role Theory
* Digital Subjectivity
* Blues / Metabolic
* The Fool
* Practitioner
* Theorist
* Question
* Resource
* Meta



# Community Description (for Reddit search — 200 char)

Post-psychoanalytic clinical theory. Affect literacy, nervous system sovereignty, the Fool archetype. Theory from practice. Function over diagnosis. We study successes.
